%% Model coefficients for the conditional probability of exceedance for
%% distributed ruptures

% It is based on the equation:
% d/MD (or AD) = coeff1 * exp(-coeff2 * r)

% that is generally used to evaluate the conditional probability of d 
% exceeding the treshold d_0, that is usually referred to a specific
% percentile.

% The models are here organized in a structure as follow:
% -------------------------------------------------------------------
% NORMAL
%   [1] Youngs et al. (2003) - d/MD, (a) coefficients for 85th and (b) for
%   95th percentile
% STRIKE-SLIP / REVERSE
%   [2-3] Takao et al. (2013) - (a) d/MD and (b) d/AD
%   [4] Takao et al. (2014) - d/AD
% REVERSE
%   [5-6] Moss et al. (2022) - d/MD (that is used to scale the hazard curve
%   instead) for (a) simple and (b) complex rupture [from GIRS-2022-05_REV_2024]

%% WARNING: for Petersen et al. (2011) models, see directly the 
%% function P_exceedance_DR

function Pexc_DR_models = Pexceedance_DR_models()

Pexc_DR_models = struct();

Pexc_DR_models(1).name = 'YEA03_a';
Pexc_DR_models(1).coefficients = [0.35 -0.091; % [coeff1 coeff2] HW 
                                  0.16 -0.137]; % [coeff1 coeff2] FW 
Pexc_DR_models(1).percentiles_coeff = [2.5 4.058]; % 85th percentile
Pexc_DR_models(1).range = [5.5, 7.4];
Pexc_DR_models(1).maxdist = 15; % in km
Pexc_DR_models(1).kinematics = 'N';
Pexc_DR_models(1).dtype = 'MD';

Pexc_DR_models(2).name = 'YEA03_b';
Pexc_DR_models(2).coefficients = [0.35 -0.091; % [coeff1 coeff2] HW 
                                  0.16 -0.137]; % [coeff1 coeff2] FW 
Pexc_DR_models(2).percentiles_coeff = [2.5 5.535]; % 95th percentile
Pexc_DR_models(2).range = [5.5, 7.4];
Pexc_DR_models(2).maxdist = 15; % in km
Pexc_DR_models(2).kinematics = 'N';
Pexc_DR_models(2).dtype = 'MD';

Pexc_DR_models(3).name = 'TEA13_a';
Pexc_DR_models(3).coefficients = [0.55 -0.17]; % [coeff1 coeff2]  
Pexc_DR_models(3).percentiles_coeff = [2.5 4.617]; % 90th percentile
Pexc_DR_models(3).range = [5.7, 7.4];
Pexc_DR_models(3).maxdist = 25; % in km
Pexc_DR_models(3).kinematics = 'R-SS';
Pexc_DR_models(3).dtype = 'MD';

Pexc_DR_models(4).name = 'TEA13_b';
Pexc_DR_models(4).coefficients = [1.9 -0.17]; % [coeff1 coeff2]  
Pexc_DR_models(4).percentiles_coeff = [2.5 4.617]; % 90th percentile
Pexc_DR_models(4).range = [5.7, 7.4];
Pexc_DR_models(4).maxdist = 25; % in km
Pexc_DR_models(4).kinematics = 'R-SS';
Pexc_DR_models(4).dtype = 'AD';

Pexc_DR_models(5).name = 'TEA14';
Pexc_DR_models(5).coefficients = [0.644 -0.17]; % [coeff1 coeff2]  
Pexc_DR_models(5).percentiles_coeff = [1.282 1]; % 90th percentile
Pexc_DR_models(5).range = [5.8, 7.4];
Pexc_DR_models(5).maxdist = 25; % in km
Pexc_DR_models(5).kinematics = 'R-SS';
Pexc_DR_models(5).dtype = 'AD';

Pexc_DR_models(6).name = 'MEA22_a';
Pexc_DR_models(6).coefficients = [0.43 -0.4; % [coeff1 coeff2] HW? 
                                  0.68 -0.13]; % [coeff1 coeff2] FW? 
Pexc_DR_models(6).percentiles_coeff = []; % 85th percentile
Pexc_DR_models(6).range = [5.0, 7.9];
Pexc_DR_models(6).maxdist = 3.5; % in km
Pexc_DR_models(6).kinematics = 'R';
Pexc_DR_models(6).dtype = 'MD';

Pexc_DR_models(7).name = 'MEA22_b';
Pexc_DR_models(7).coefficients = [0.43 -0.012; % [coeff1 coeff2] HW? 
                                  0.68 -0.13]; % [coeff1 coeff2] FW? 
Pexc_DR_models(7).percentiles_coeff = []; % 85th percentile
Pexc_DR_models(7).range = [5.0, 7.9];
Pexc_DR_models(7).maxdist = 15; % in km
Pexc_DR_models(7).kinematics = 'R';
Pexc_DR_models(7).dtype = 'MD';
