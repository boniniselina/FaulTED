%%   P R O B A B I L I S T I C   F A U L T   D I S P L A C E M E N T    %%
%%                         H A Z A R D   M A P S                        %%
%%                          earthquake approach                         %%

% ----------------------------------------------------------------------

clear; close all; clc;
addpath('./Sources'); addpath('./Input'); addpath('./Output');

%%

% All the input information are organized in a json file (see structure
% model)
jsonFile = 'prova_Takao.json';
jsonText = fileread(jsonFile);
data = jsondecode(jsonText);

%%
% SAVE Outputs
mainDir = fileparts(mfilename('fullpath')); % Main directory
outputDir = fullfile(mainDir, 'Output');    % Output folder

baseFolderName = 'Project';
folderPath = fullfile(outputDir, baseFolderName);

counter = 1;
while exist(folderPath, 'dir')
    folderPath = fullfile(outputDir, sprintf('%s(%d)', baseFolderName, counter));
    counter = counter + 1;
end
mkdir(folderPath);

% Copy the input file to the project folder
inputFilePath = fullfile(mainDir, 'Input', jsonFile); % original path
outputFilePath = fullfile(folderPath, jsonFile); % new path
copyfile(inputFilePath, outputFilePath);

%%

% Extracting Input data for each Fault ID
Fault_IDs = fieldnames(data);

for faultIdx = 1:numel(Fault_IDs)
    current_Fault_ID = Fault_IDs{faultIdx};
    faultData = data.(current_Fault_ID);
    subFields = fieldnames(faultData);
    for j = 1:numel(subFields)
        categoryName = subFields{j}; % Eg. 'Fault_parameters', 'Fault_activity', ...
        categoryData = faultData.(categoryName);
        subCategoryFields = fieldnames(categoryData);
        for k = 1:numel(subCategoryFields)
            varName = subCategoryFields{k};
            varValue = categoryData.(varName);
            assignin('base', varName, varValue);
        end
    end


    %% Set the variables for Figures

    magnitudes = 4:0.1:8.5;
    D_perc = logspace(log10(0.001),log10(100),1000); % Percentage used to explore displacement levels for the Conditional Probability of Exceedance
    x_axis_displacement = logspace(log10(0.001),log10(100),100); % in m
    displacement_levels = logspace(log10(0.001),log10(100),50); % in m

    if ~isempty(Recurrence_time) || ~isnan(Recurrence_time)
        AFOE_fixed = 1./Recurrence_time;
    end


    %%
    % GRID GENERATOR FROM SHAPEFILE
    [PF_length, grid_PF_or, grid_DR_FW_or, grid_DR_HW_or] = Gridding(step, long_range, lat_range, max_dist, input_shapefile, Strike);

    % GRID Adjusting with respect to map uncertainties
    if ~isempty(Fault_zone) & ~isnan(Fault_zone)
        [grid_DR_HW, grid_DR_FW, grid_PF] = adjust_grids(grid_PF_or, grid_DR_HW_or, grid_DR_FW_or, Fault_zone);
    else
        grid_DR_HW = grid_DR_HW_or;
        grid_DR_FW = grid_DR_FW_or;
        grid_PF = grid_PF_or;
    end

    % Defining y/FSL and r_0 values on the input grids
    p=find(round(grid_PF(:,3),4)==0.5);
    xL_value = [round(grid_PF(1:p(1),3),4)];
    Dist_value=0.01:0.01:(max(grid_DR_HW(:,3)));

    figure(1);
    subplot(1,2,1)
    hold on;
    plot(grid_PF(:,1), grid_PF(:,2), 'ro');
    title('Principal Fault');
    xlabel('Long');
    ylabel('Lat');

    subplot(1,2,2)
    hold on;
    plot(grid_DR_HW(:,1), grid_DR_HW(:,2), 'ko', 'MarkerSize', 0.5);
    plot(grid_DR_FW(:,1), grid_DR_FW(:,2), 'ko', 'MarkerSize', 0.5);
    plot(grid_PF_or(:,1),grid_PF_or(:,2),'r', 'LineWidth', 1.5)
    title('Grid for distributed faulting');
    xlabel('Long');
    ylabel('Lat');
    hold off

    saveas(gcf, fullfile(folderPath, ['Fault_grid_' FaultName '.fig']));



    %% Rates
    if isempty(Input_Mw) || isnan(Input_Mw) && isempty(Input_probability) || isnan(Input_probability)
        [Mcase, Mmax, sigma_Mmax, Width, Tmean, rates, MFD, M_0, MomentRate, Telap, yfc, warnings_Mw_geo_ScR, warnings_rates] = rates_computing(FaultName, kinematicType, m_ScR, Length, Width, Dip, Seismogenic_Thickness, SR_min, SR_max, ShearModulus, StrainDrop, bin, mag_truncation, fault_behavior, year_for_calculations, Last_eq_time, Mobs, Sd_Mobs, w, Mmin, b_value, Weighted, folderPath);
    elseif ~isempty(Input_Mw) && ~isnan(Input_Mw) && ~isempty(Input_probability) && ~isnan(Input_probability)
        Mcase = Input_Mw;
        rates = Input_probability;
        d=9.1; c=1.5;
        M_0 = 10.^((c.*Mcase)+d);
        if length(Mcase) ~= length(rates)
            error('Input_Mw and Input_probability must have the same size')
        end
        if ~isempty(Last_eq_time) && ~isnan(Last_eq_time)
            if isempty(year_for_calculations) || isnan(year_for_calculations)
                year_for_calculations=clock; yfc=year_for_calculations(1);
            else
                yfc=year_for_calculations;
            end
            Telap = yfc - Last_eq_time;
        else
            Telap = []; yfc= [];
        end
        Mmax = max(Mcase); sigma_Mmax = []; Tmean = round((1/((SR_max+SR_min)/2))*1000,0);
        MomentRate = []; MFD = []; warnings_Mw_geo_ScR = []; warnings_rates = [];
    else
        error('Please, insert both Input_Mw and Input_probability for the custumized scenario')
    end


    %% %%%%%%%%%%%%%%%%%%%%%% PRINCIPAL RUPTURES %%%%%%%%%%%%%%%%%%%%%% %%

    %% Evaluation of the Displacement Attenuation Law - PRINCIPAL FAULTING
    %% First Term:
    %%% Conditional probability of slip, Pkn(Slip|m,r) %%%

    % Numerical Model from Mammarella et al. (2024)
    if strcmp(P_slip_m, "MAEA24")
        [P_case] = CPSR(Input_MAEA24, Mcase, FaultName, folderPath);
        P_slip_coeff = [];
        model_range = [];
        warnings_Pslip = [];
    else
        % Empirical Models ("Classic" approach)
        [P_case, P_slip_coeff, model_range, warnings_Pslip] = PSlip(magnitudes, Mcase, P_slip_m, kinematicType, FaultName, folderPath);
    end

    %% Second Term:
    %%%% Conditional Probability of Exceedence, Pkn(D>d|m,r,Slip) %%%%
    displacement_labels = {'AD', 'MD'};
    [p_Displ, P_exceedance_full, P_exceedance, warnings_Pexc] = Pexceedance(x_axis_displacement, displacement_levels, D_perc, Displ_type, d_ScR, P_D_model, Mcase, d_truncation, FaultName, folderPath, kinematicType, xL_value);

    %% Floating Ruptures
    if floating == 1
        rates_old = rates;
        P_exceedance_old = P_exceedance;
        P_exceedance_tip = zeros(length(Mcase), size(P_exceedance_full, 2));
        num_xL = length(xL_value);

        for m_idx = 1:length(Mcase)
            row_idx = (m_idx - 1) * num_xL + 1;
            P_exceedance_tip(m_idx, :) = P_exceedance_full(row_idx, :);
        end
        [P_float, srl_case, rates_riv, x_over_L_riv, Dist_riv, dist_starting_point, dist_ending_point, warnings_Mw_srl] = Pfloating(kinematicType, srl_ScR, floating_bin, Length, xL_value, Mcase, M_0, displacement_levels, P_exceedance_full, Dist_value, rates, P_D_model, p_Displ, Displ_type, x_axis_displacement, D_perc, P_exceedance_old);
        P_exceedance = P_float;
        rates = rates_riv';
    else
        % We assume that all evaluation points along the PF have Probability =
        % 1 to experience the rupture
        P_pos = ones(length(Mcase), length(xL_value));

        % The P_exceedance evaluated above is trasformed in a cell array, whose
        % size is compatible to P_float
        P_exceedance_old = P_exceedance;
        P_exceedance = cell(length(Mcase), length(xL_value));
        num_x_n = length(xL_value);
        for mag_idx = 1:length(Mcase)
            row_range = (1:num_x_n) + (mag_idx - 1) * num_x_n;
            for col_idx = 1:num_x_n
                P_exceedance{mag_idx, col_idx} = P_exceedance_old(row_range(col_idx), :);
            end
        end
        warnings_Mw_srl = [];
        srl_case = [];
        dist_starting_point = [];
        dist_ending_point = [];
        x_over_L_riv{length(Mcase)} = xL_value';
    end

    %% P2p from Takao et al. (2013)
    if P2p == 1
        [P_2p,configurations,nf,Ll_cases,lp_tot,lp_p] = P2p_TEA(Length, Mcase, xL_value, FaultName, folderPath, magnitudes, displacement_levels, P_exceedance_full, Displ_type, x_axis_displacement, D_perc, p_Displ,P_D_model);
    else
        P_2p = ones(length(Mcase), length(xL_value));
        configurations = []; nf= []; Ll_cases = [];
    end

    %% Vk(d) - PRINCIPAL FAULTING
    HC_PF_full = cell(length(Mcase), length(xL_value));
    HC_PF_sum = cell(length(Mcase), length(xL_value));
    for g = 1:length(Mcase) % Loop over each magnitude
        for a = 1:length(xL_value) % Loop over each xL_value
            n_combinations = size(P_exceedance{g, a}, 1); % Number of combinations
            for i = 1:n_combinations % Loop over all combinations
                P_slip_curr = P_case(g); % Scalar
                P_base = P_exceedance{g, a}(i, :); % [1x50]
                rate_value = rates(g); % Scalar
                P2p_curr = P_2p(g, a); % Scalar

                % Compute HC_PF_full for the current configuration
                HC_PF_full{g, a}(i, :) = rate_value .* P_slip_curr .* P_base .* P2p_curr;
                if ~isempty(HC_PF_full{g, a})
                    % Sum along the n_combinations dimension (1st dimension)
                    % to include all the contributes coming from every combination
                    HC_PF_sum{g, a} = sum(HC_PF_full{g, a}, 1); % Resulting size: [1, length(xL_value), 50]
                end
            end
        end
    end

    % Sum of all magnitude contributions:
    HC_PF_tot = cell(1, length(xL_value)); % One cell for each xL_value

    for a = 1:length(xL_value) % Loop over each xL_value
        % Initialize accumulator for the sum across Mcase
        total_sum = 0;

        for g = 1:length(Mcase) % Loop over each magnitude
            if ~isempty(HC_PF_sum{g, a})
                % Accumulate the sum across magnitudes
                total_sum = total_sum + squeeze(HC_PF_sum{g, a}); % [length(xL_value), 50]
            end
        end

        % Store the aggregated result for this xL_value
        HC_PF_tot{a} = total_sum; % [length(xL_value), 50]
    end


    % Initialize HC_DR_HW_plot as a cell array to store the extracted curves
    HC_PF_plot = zeros(size(grid_PF, 1), length(displacement_levels));

    % Loop through each row in grid_DR_HW to extract specific combinations
    for i = 1:size(grid_PF, 1)
        % Find the indices corresponding to xL_value and Dist_value
        x = find(round(grid_PF(i, 3), 3) == round(xL_value(:), 3), 1); % Match xL_value

        if ~isempty(x) % Check if valid indices are found
            % Extract the corresponding hazard curve from HC_DR_sum_hw
            if ~isempty(HC_PF_tot{x})
                % Extract the specific hazard curve for xL_value(x) and Dist_value(y)
                HC_PF_plot(i, :) = HC_PF_tot{x}(:);
            end
        else
            % If no match is found, assign an empty array
            HC_PF_plot(i, :) = NaN;
            warning('No match found for the Principal Fault grid, row %d', i);
        end
    end


    for i = 1:size(HC_PF_plot, 1)
        valid_idx = HC_PF_plot(i, :) > 0 & isfinite(HC_PF_plot(i, :));
        x_valid = displacement_levels(valid_idx);
        y_valid = HC_PF_plot(i, valid_idx);

        if length(y_valid) < 2
            poe_PF(i) = NaN;
            continue;
        end

        if AFOE_fixed < min(y_valid) || AFOE_fixed > max(y_valid)
            poe_PF(i) = NaN;
        else
            poe_value = interp1(y_valid, x_valid, AFOE_fixed, 'linear');
            poe_PF(i) = max(poe_value, [], 'omitnan');
        end
    end


    % interpolate the curves with the probability thresholds to
    % generate the hazard maps
    poe_PF_fin=[poe_PF(:,:);flipud(poe_PF(1:end-1,:))];



    %%
    %% %%%%%%%%%%%%%%%%%%%%%% DISTRIBUTED RUPTURES %%%%%%%%%%%%%%%%%%%%%% %%

    %% Evaluation of the Displacement Attenuation Law - DISTRIBUTED FAULTING
    if ~isempty(Pslip_DR_m) && ~isempty(Pexc_DR_m) 

        if floating ==1
            Dist_riv = Dist_riv;
        else
            for i = 1:length(Mcase)
                for j = 1:length(xL_value)
                    Dist_riv{i, j} = Dist_value;
                end
            end
        end

        % Conditional Probability of surface rupture at a specific site for
        % distributed ruptures
        [P_slip_DR_hw, P_slip_DR_fw, warnings_Pslip_DR_AT, model_mag_range_DR, model_dist_range_DR] = P_rupt_site_DR(Dist_riv, Mcase, Pslip_DR_m, Dist_value, kinematicType, FaultName, folderPath);
        % Conditional Probability of exceedance for distributed ruptures
        [P_exceedance_DR_hw, P_exceedance_DR_fw, warnings_DR_AT, Pexc_model_mag_range_DR, Pexc_model_dist_range_DR,P_exc_model_coefficients_DR_hw,P_exc_model_coefficients_DR_fw] = Pexceedance_DR(x_axis_displacement, displacement_levels, Dist_riv, p_Displ, D_perc, d_truncation, Pexc_DR_m, Mcase, Dist_value, kinematicType, FaultName, folderPath);

        %% Vk(d) - DISTRIBUTED FAULTING
        P_exceedance_riv = cell(size(P_exceedance));

        for m_idx = 1:size(P_exceedance, 1)
            for x_idx = 1:size(P_exceedance, 2)
                current_curves = P_exceedance{m_idx, x_idx};

                revised_curves = current_curves;

                for curve_idx = 1:size(current_curves, 1)
                    % As the distances revaluated during floating are measured from
                    % the nearest tip of the single rupture, we revaluate
                    % P_exceedance of PF also considering the Conditional Prob of
                    % exceedance of x/L = 0.005
                    if all(current_curves(curve_idx, :) == 0)
                        revised_curves(curve_idx, :) = P_exceedance_tip(m_idx, :);
                    end
                end

                P_exceedance_riv{m_idx, x_idx} = revised_curves;
            end
        end


        %% &&

        % HANGING WALL
        % Initialize HC_DR_full as a cell array
        HC_DR_full_hw = cell(length(Mcase), length(xL_value));
        HC_DR_sum_hw = cell(length(Mcase), length(xL_value));
        % Initialize HC_DR_total as a cell array
        HC_DR_tot_hw = cell(1, length(xL_value)); % One cell for each xL_value

        for g = 1:length(Mcase) % Loop over each magnitude
            for a = 1:length(xL_value) % Loop over each xL_value
                n_combinations = size(P_slip_DR_hw{g, a}, 1); % Number of combinations
                for b = 1:length(Dist_value) % Loop over each Dist_value
                    for i = 1:n_combinations % Loop over all combinations
                        % Extract the required components
                        % P_exc_hw = squeeze(P_exceedance_DR_hw{g, a}(i, b, :)); % [1x50]
                        % P_base = P_exceedance_riv{g, a}(i, :); % [1x50]
                        P_slip_curr = P_case(g); % Scalar
                        P_slip_hw = P_slip_DR_hw{g, a}(i, b); % Scalar
                        rate_value = rates(g); % Scalar

                        % Compute HC_DR_full for the current configuration
                        if any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'}))                                
                            HC_DR_full_hw{g, a}(i, b, :) = rate_value .* P_slip_curr .* P_base .* P_slip_hw; % adjusting the probability for off-fault location as in the original code
                            P_exc_hw = P_exceedance_DR_hw(b);
                            displ_levels_Moss_hw(b,:) = P_exc_hw .* displacement_levels; % adjusting MD by the d/MD ratio for off-fault location as in the original code
                        else
                            P_exc_hw = squeeze(P_exceedance_DR_hw{g, a}(i, b, :)); % [1x50]

                            % Ensure dimensions are consistent for element-wise multiplication
                            if size(P_exc_hw, 1) ~= 1
                                P_exc_hw = P_exc_hw'; % Convert to row vector if needed
                            end
                        
                            HC_DR_full_hw{g, a}(i, b, :) = rate_value .* P_slip_curr .* P_exc_hw .* P_slip_hw;
                        end
                    end
                end

                if ~isempty(HC_DR_full_hw{g, a})
                    % Sum along the n_combinations dimension (1st dimension)
                    % to include all the contributes coming from every combination
                    HC_DR_sum_hw{g, a} = squeeze(sum(HC_DR_full_hw{g, a}, 1)); % Resulting size: [1, length(Dist_value), 50]

                end
            end
        end

        for a = 1:length(xL_value) % Loop over each xL_value
            % Initialize accumulator for the sum across Mcase
            total_sum = 0;

            for g = 1:length(Mcase) % Loop over each magnitude
                if ~isempty(HC_DR_sum_hw{g, a})
                    % to sum all contributes coming from each tested Mw
                    total_sum = total_sum + HC_DR_sum_hw{g, a}; % [length(Dist_value), 50]
                end
            end

            % Store the aggregated result for this xL_value
            HC_DR_tot_hw{a} = total_sum; % [length(Dist_value), 50]
        end


        % Initialize HC_DR_HW_plot as a cell array to store the extracted curves
        HC_DR_HW_plot = zeros(size(grid_DR_HW, 1), length(displacement_levels));

        % Loop through each row in grid_DR_HW to extract specific combinations
        for i = 1:size(grid_DR_HW, 1)
            if grid_DR_HW(i,3) ~= 0 % if the grid point is located outside of the Main Fault Zone

                % Find the indices corresponding to xL_value and Dist_value
                y = find(round(grid_DR_HW(i, 3), 2) == round(Dist_value(:), 4), 1); % Match Dist_value
                % if strcmp(Pslip_DR_m,'MEA22')
                x = find(round(grid_DR_HW(i, 4), 3) == round(xL_value(:), 3), 1); % Match xL_value
                if ~isempty(x) && ~isempty(y) % Check if valid indices are found
                    for g = 1:length(Mcase)
                        if ~isempty(HC_DR_tot_hw{1, x})
                            % Extract the specific hazard curve for Dist_value(y)
                            HC_DR_HW_plot(i, :) = HC_DR_tot_hw{1, x}(y, :);
                            if any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'}))
                                displ_levels_Moss_plot_hw(i,:) = displ_levels_Moss_hw(y,:);
                            end
                        end
                    end
                end
            else
                % associate the points falling within the buffer chosen for the fault zone
                % with the x/L points on the PF
                if grid_DR_HW(i,3) == 0
                    x3 = find(round(grid_DR_HW(i, 4), 3) == round(xL_value(:), 3), 1); % Match xL_value
                    HC_DR_HW_plot(i,:) = HC_PF_plot(x3,:);
                end
            end

        end

        % Interpolation to uniform x axis
        if any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'})) 
            for i = 1:size(HC_DR_HW_plot, 1)
                if all(HC_DR_HW_plot(i,:) == 0)
                    HC_DR_HW_plot(i,:) = NaN;
                end
            end
            HC_DR_HW_plot_old = HC_DR_HW_plot;
            HC_DR_HW_plot = NaN(size(HC_DR_HW_plot_old)); 
           
            for i = 1:size(grid_DR_HW, 1)
                % omit NaN
                x = displ_levels_Moss_plot_hw(i,:);
                y = HC_DR_HW_plot_old(i,:);
                valid_points = ~isnan(x) & ~isnan(y);
                y_valid = y(valid_points);
                x_valid = x(valid_points);
                if numel(x_valid) >= 2
                    HC_DR_HW_plot(i,:) = interp1(x_valid, y_valid, displacement_levels);
                end
            end
        end


        poe_DR_HW = nan(size(HC_DR_HW_plot, 1), 1);

        for i = 1:size(HC_DR_HW_plot, 1)
            % Select only valid values (non NaN, non Inf, non zero)
            valid_idx = HC_DR_HW_plot(i, :) > 0 & isfinite(HC_DR_HW_plot(i, :));
            x_valid = displacement_levels(valid_idx);
            y_valid = HC_DR_HW_plot(i, valid_idx);


            if isempty(y_valid) || isempty(x_valid)
                poe_DR_HW(i) = NaN;
            elseif AFOE_fixed < min(y_valid) || AFOE_fixed > max(y_valid)
                poe_DR_HW(i) = NaN;
            else
                poe_value = interp1(y_valid, x_valid, AFOE_fixed, 'linear');
                poe_DR_HW(i) = max(poe_value, [], 'omitnan');
            end
        end



        %%
        % FOOTWALL
        % Initialize HC_DR_full as a cell array
        HC_DR_full_fw = cell(length(Mcase), length(xL_value));
        HC_DR_sum_fw = cell(length(Mcase), length(xL_value));
        % Initialize HC_DR_total as a cell array
        HC_DR_tot_fw = cell(1, length(xL_value)); % One cell for each xL_value

        for g = 1:length(Mcase) % Loop over each magnitude
            for a = 1:length(xL_value) % Loop over each xL_value
                n_combinations = size(P_slip_DR_fw{g, a}, 1); % Number of combinations
                for b = 1:length(Dist_value) % Loop over each Dist_value
                    for i = 1:n_combinations % Loop over all combinations
                        % Extract the required components
                        % P_exc_hw = squeeze(P_exceedance_DR_hw{g, a}(i, b, :)); % [1x50]
                        % P_base = P_exceedance_riv{g, a}(i, :); % [1x50]
                        P_slip_curr = P_case(g); % Scalar
                        P_slip_fw = P_slip_DR_fw{g, a}(i, b); % Scalar
                        rate_value = rates(g); % Scalar

                        % Compute HC_DR_full for the current configuration
                        if any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'}))                                
                            HC_DR_full_fw{g, a}(i, b, :) = rate_value .* P_slip_curr .* P_base .* P_slip_fw; % adjusting the probability for off-fault location as in the original code
                            P_exc_fw = P_exceedance_DR_fw(b);
                            displ_levels_Moss_fw(b,:) = P_exc_fw .* displacement_levels; % adjusting MD by the d/MD ratio for off-fault location as in the original code
                        else
                            P_exc_fw = squeeze(P_exceedance_DR_fw{g, a}(i, b, :)); % [1x50]

                            % Ensure dimensions are consistent for element-wise multiplication
                            if size(P_exc_fw, 1) ~= 1
                                P_exc_fw = P_exc_fw'; % Convert to row vector if needed
                            end
                        
                            HC_DR_full_fw{g, a}(i, b, :) = rate_value .* P_slip_curr .* P_exc_fw .* P_slip_fw;
                        end
                    end
                end

                if ~isempty(HC_DR_full_fw{g, a})
                    % Sum along the n_combinations dimension (1st dimension)
                    % to include all the contributes coming from every combination
                    HC_DR_sum_fw{g, a} = squeeze(sum(HC_DR_full_fw{g, a}, 1)); % Resulting size: [1, length(Dist_value), 50]

                end
            end
        end

        for a = 1:length(xL_value) % Loop over each xL_value
            % Initialize accumulator for the sum across Mcase
            total_sum = 0;

            for g = 1:length(Mcase) % Loop over each magnitude
                if ~isempty(HC_DR_sum_fw{g, a})
                    % to sum all contributes coming from each tested Mw
                    total_sum = total_sum + HC_DR_sum_fw{g, a}; % [length(Dist_value), 50]
                end
            end

            % Store the aggregated result for this xL_value
            HC_DR_tot_fw{a} = total_sum; % [length(Dist_value), 50]
        end


        % Initialize HC_DR_FW_plot as a cell array to store the extracted curves
        HC_DR_FW_plot = zeros(size(grid_DR_FW, 1), length(displacement_levels));

        % Loop through each row in grid_DR_HW to extract specific combinations
        for i = 1:size(grid_DR_FW, 1)
            if grid_DR_FW(i,3) ~= 0 % if the grid point is located outside of the Main Fault Zone

                % Find the indices corresponding to xL_value and Dist_value
                % x = find(round(grid_DR_FW(i, 4), 3) == round(xL_value(:), 3), 1); % Match xL_value
                y = find(round(grid_DR_FW(i, 3), 2) == round(-Dist_value(:), 4), 1); % Match Dist_value
                % if strcmp(Pslip_DR_m,'MEA22')
                x = find(round(grid_DR_FW(i, 4), 3) == round(xL_value(:), 3), 1); % Match xL_value
                if ~isempty(x) && ~isempty(y) % Check if valid indices are found
                    for g = 1:length(Mcase)
                        if ~isempty(HC_DR_tot_fw{1, x})
                            % Extract the specific hazard curve for Dist_value(y)
                            HC_DR_FW_plot(i, :) = HC_DR_tot_fw{1, x}(y, :);
                            if any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'}))
                                displ_levels_Moss_plot_fw(i,:) = displ_levels_Moss_fw(y,:);
                            end
                        end
                    end
                    % else
                    %     if ~isempty(y) % Check if valid indices are found
                    %         % Extract the corresponding hazard curve from HC_DR_tot_fw
                    %         for g = 1:length(Mcase)
                    %             if ~isempty(HC_DR_tot_fw{1, 1})
                    %                 % Extract the specific hazard curve for Dist_value(y)
                    %                 HC_DR_FW_plot(i, :) = HC_DR_tot_fw{1, 1}(y, :);
                    %                 if any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'}))
                    %                     displ_levels_Moss_plot_fw(i,:) = displ_levels_Moss_fw(y,:);
                    %                 end
                    %             end
                    %         end
                    %     else
                    %     end
                    % end
                end
            else
                % associate the points falling within the buffer chosen for the fault zone
                % with the x/L points on the PF
                if grid_DR_FW(i,3) == 0
                    x3 = find(round(grid_DR_FW(i, 4), 3) == round(xL_value(:), 3), 1); % Match xL_value
                    HC_DR_FW_plot(i,:) = HC_PF_plot(x3,:);
                end
            end

        end

        % Interpolation to uniform x axis
        if any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'})) 
            for i = 1:size(HC_DR_FW_plot, 1)
                if all(HC_DR_FW_plot(i,:) == 0)
                    HC_DR_FW_plot(i,:) = NaN;
                end
            end
            HC_DR_FW_plot_old = HC_DR_FW_plot;
            HC_DR_FW_plot = NaN(size(HC_DR_FW_plot_old)); 
           
            for i = 1:size(grid_DR_FW, 1)
                % omit NaN
                x = displ_levels_Moss_plot_fw(i,:);
                y = HC_DR_FW_plot_old(i,:);
                valid_points = ~isnan(x) & ~isnan(y);
                y_valid = y(valid_points);
                x_valid = x(valid_points);
                if numel(x_valid) >= 2
                    HC_DR_FW_plot(i,:) = interp1(x_valid, y_valid, displacement_levels);
                end
            end
        end


        poe_DR_FW = nan(size(HC_DR_FW_plot, 1), 1);

        for i = 1:size(HC_DR_FW_plot, 1)
            % Select only valid values (non NaN, non Inf, non zero)
            valid_idx = HC_DR_FW_plot(i, :) > 0 & isfinite(HC_DR_FW_plot(i, :));
            % if any(strcmp(P_DR_model, {'MEA22_a', 'MEA22_b'}))
            %     x_valid = displ_levels_Moss_plot_fw(valid_idx);
            % else
                x_valid = displacement_levels(valid_idx);
            % end
            y_valid = HC_DR_FW_plot(i, valid_idx);


            if isempty(y_valid) || isempty(x_valid)
                poe_DR_FW(i) = NaN;
            elseif AFOE_fixed < min(y_valid) || AFOE_fixed > max(y_valid)
                poe_DR_FW(i) = NaN;
            else
                poe_value = interp1(y_valid, x_valid, AFOE_fixed, 'linear');
                poe_DR_FW(i) = max(poe_value, [], 'omitnan');
            end
        end


        %%
        % Interactive Hazard Map
        for i =1: length(AFOE_fixed)
            interactive_hazard_map(grid_PF, grid_PF_or, grid_DR_FW, grid_DR_HW, poe_PF_fin, poe_DR_FW, poe_DR_HW, i, HC_PF_plot, HC_DR_FW_plot, HC_DR_HW_plot, displacement_levels, FaultName, Recurrence_time);
        end


        %% Save maps in csv files
        file1 = fullfile(folderPath, [FaultName, '_PF_TR', num2str(Recurrence_time), '_map.csv']);
        file2 = fullfile(folderPath, [FaultName, '_DR_TR', num2str(Recurrence_time), '_map.csv']);
        file3 = fullfile(folderPath, [FaultName, '_total_map_TR', num2str(Recurrence_time), '_map.csv']);
        PF_label = repmat({'PF'}, size(grid_PF, 1), 1);
        dist_PF = zeros(size(grid_PF, 1), 1);
        % Principal Faulting
        if size(grid_PF, 1) == length(poe_PF_fin)
            data_PF = [num2cell(grid_PF),num2cell(round(poe_PF_fin(:),3))]; % Convert numbers to cells
            header_PF = {'Longitude', 'Latitude', 'y/FSL', 'Displacement (m)'};
            writecell([header_PF; data_PF], file1);
        else
            warning('Incompatible dimensions between grid_PF and poe_PF_fin.');
        end

        % Distributed Ruptures
        HW_label = repmat({'HW'}, size(grid_DR_HW, 1), 1);
        FW_label = repmat({'FW'}, size(grid_DR_FW, 1), 1);

        data_PF2 = [num2cell(grid_PF(:, 1:2)), num2cell(dist_PF), num2cell(grid_PF(:,3)), PF_label, num2cell(round(poe_PF_fin(:),3))]; % Convert numbers to cells
        % if ~isnan(poe_DR_HW)
        data_DR_HW = [num2cell(grid_DR_HW), HW_label, num2cell(round(poe_DR_HW,3))];
        % elseif ~isnan(poe_DR_FW)
        data_DR_FW = [num2cell(grid_DR_FW), FW_label, num2cell(round(poe_DR_FW,3))];
        % end

        % if ~isnan(all(poe_DR_HW,poe_DR_FW))
        data_DR = [data_DR_HW; data_DR_FW];
        header_DR = {'Longitude', 'Latitude', 'Distance', 'y/FSL', 'Type', 'Displacement (m)'};
        writecell([header_DR; data_DR], file2);
        % end
        data_merged = [data_PF2;data_DR_HW; data_DR_FW];
        writecell([header_DR; data_merged], file3);
        

        %% Write the Report file
        LogFile(FaultName,folderPath,faultData,Width,Telap,yfc,Mmax,sigma_Mmax,Tmean,...
            MomentRate,MFD,Mcase,rates,P_slip_coeff,srl_case,configurations,Ll_cases,...
            P_2p,warnings_Mw_geo_ScR,warnings_rates,warnings_Pslip,warnings_Pexc,...
            warnings_Mw_srl,warnings_Pslip_DR_AT, model_mag_range_DR, model_dist_range_DR,...
            warnings_DR_AT, Pexc_model_mag_range_DR, Pexc_model_dist_range_DR,P_exc_model_coefficients_DR_hw,P_exc_model_coefficients_DR_fw);
    end
end


