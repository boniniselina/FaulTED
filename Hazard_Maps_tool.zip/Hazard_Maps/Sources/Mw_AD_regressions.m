%% Available scaling relations between Mw and AD

% Here we define a structure including all the scaling relations available
% in the scientific literature specifically between Mw and Average
% Displacement (AD), generally evaluated with the following equation:
                            % log(D) = a+b*Mw

% The main authors are listed below, while the corresponding model number 
% is reported within ():

%% Wells & Coppersmith (1994) - WC94
% the authors provide regressions for the whole dataset (all slip type - 1)
% and also for single kinematics type, subdividing the earthquakes into
% normal (2), reverse (5) and strike-slip faults (9). 
% Be careful because the regression for reverse faults is not
% statistically consistent.

%% Leonard (2014) - L14
% the authors provide self-consistent fault scaling relations for dip slip
% (normal and reverse - 4) and strike-slip (11) faults 

%% Thingbaijam et al. (2017) - T17
% the authors provide regressions for the 3 kinematics: normal (3), reverse
% (7), strike-slip (10)

%% Moss et al. (2022) - MEA22
% the authors focus only on reverse faulting (6).

%% Takao et al. (2013) - TEA13
% the authors analyze jointly both reverse and strike-slip faults in the 
% Japan. Be careful because this regression may not be suitable out of this 
% geographic area (8).

function D_Mw_scaling_rel = Mw_AD_regressions()
D_Mw_scaling_rel = struct(); % initializing the structure for Mw-AD scaling relations

D_Mw_scaling_rel(1).name = 'WC94-A';
D_Mw_scaling_rel(1).kinematics = 'All';
D_Mw_scaling_rel(1).coefficients = [-4.8 0.69]; % [a b]
D_Mw_scaling_rel(1).sigma = 0.36; % standard deviation
D_Mw_scaling_rel(1).range = [5.6 8.1];

D_Mw_scaling_rel(2).name = 'WC94-N';
D_Mw_scaling_rel(2).kinematics = 'N';
D_Mw_scaling_rel(2).coefficients = [-4.45 0.63];
D_Mw_scaling_rel(2).sigma = 0.33;
D_Mw_scaling_rel(2).range = [6.0 7.3];

D_Mw_scaling_rel(3).name = 'T17-N';
D_Mw_scaling_rel(3).kinematics = 'N';
D_Mw_scaling_rel(3).coefficients = [-4.967 0.693];
D_Mw_scaling_rel(3).sigma = 0.195;
D_Mw_scaling_rel(3).range = [5.86 8.39];

D_Mw_scaling_rel(4).name = 'L14-D';
D_Mw_scaling_rel(4).kinematics = 'N-R';
D_Mw_scaling_rel(4).coefficients = [-3.42 0.5];
D_Mw_scaling_rel(4).sigma = 0.15;
D_Mw_scaling_rel(4).range = [4.0 8.0];

D_Mw_scaling_rel(5).name = 'WC94-R'; % Warning! not statistically consistent
D_Mw_scaling_rel(5).kinematics = 'R';
D_Mw_scaling_rel(5).coefficients = [-0.74 0.08];
D_Mw_scaling_rel(5).sigma = 0.38;
D_Mw_scaling_rel(5).range = [5.8 7.4];

D_Mw_scaling_rel(6).name = 'MEA22';
D_Mw_scaling_rel(6).kinematics = 'R';
D_Mw_scaling_rel(6).coefficients = [-2.87 0.416];
D_Mw_scaling_rel(6).sigma = 0.2;
D_Mw_scaling_rel(6).range = [4.7 8.02];

D_Mw_scaling_rel(7).name = 'T17-R';
D_Mw_scaling_rel(7).kinematics = 'R'; % shallow earthquakes (not in subduction zones)
D_Mw_scaling_rel(7).coefficients = [-3.156 0.693];
D_Mw_scaling_rel(7).sigma = 0.149;
D_Mw_scaling_rel(7).range = [5.59 7.6];

D_Mw_scaling_rel(8).name = 'TEA13';
D_Mw_scaling_rel(8).kinematics = 'R-SS';
D_Mw_scaling_rel(8).coefficients = [-4.032 0.558];
D_Mw_scaling_rel(8).sigma = 0.36;
D_Mw_scaling_rel(8).range = [5.7 7.4];

D_Mw_scaling_rel(9).name = 'WC94-S';
D_Mw_scaling_rel(9).kinematics = 'SS';
D_Mw_scaling_rel(9).coefficients = [-6.32 0.9];
D_Mw_scaling_rel(9).sigma = 0.28;
D_Mw_scaling_rel(9).range = [5.6 8.1];

D_Mw_scaling_rel(10).name = 'T17-S';
D_Mw_scaling_rel(10).kinematics = 'SS';
D_Mw_scaling_rel(10).coefficients = [-4.8 0.69];
D_Mw_scaling_rel(10).sigma = 0.227;
D_Mw_scaling_rel(10).range = [5.38 8.7];

D_Mw_scaling_rel(11).name = 'L14-S';
D_Mw_scaling_rel(11).kinematics = 'SS';
D_Mw_scaling_rel(11).coefficients = [-3.425 0.5];
D_Mw_scaling_rel(11).sigma = 0.15;
D_Mw_scaling_rel(11).range = [4.0 8.0];

% Save the structure 
% save('AD_Mw_scaling_rel.mat', "AD_Mw_scaling_rel", '-mat')

end