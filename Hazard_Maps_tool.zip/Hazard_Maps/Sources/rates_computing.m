%% Magnitude cases and Rates
% This part has been readapted from Peruzza et al. 2010 (JOSE) and
% Pace, Visini, Peruzza (2015) FiSH: Matalab tools for...
% Please refer to the original authors when using this code or partial
% or modified version of it.
% It is composed of two main parts: i) the evaluation of the fault moment rate
% from geometry and slip rates data, and ii) the evaluation of the fault
% activity rate.

% In the first part also the Mmax and related standard deviation is
% computed. The seismic moment derived from the moment rate is used for
% balancing the chosen magnitude-frequency distribution in the second part
% tHE User can choose the Mw-freq distribution (fault_behavior) among:
%%% 1) Single-value model - time indipendent
%%% 2) Single-value model - time dipendent: Brownian Passage Time
%%% 3) Gaussian Characteristic model - time independent
%%% 4) Gaussian Characteristic model - time dipendent: Brownian Passage Time
%%% 5) Classical Gutenberg-Richter
%%% 6) Truncated Gutenberg-Richter

function [Mcase, Mmax, sigma_Mmax, Width, Tmean, rates, MFD, M_0, MomentRate, Telap, yfc, warnings_Mw_geo_ScR, warnings_rates] = rates_computing(FaultName, kinematicType, m_ScR, Length, Width, Dip, Seismogenic_Thickness, SR_min, SR_max, ShearModulus, StrainDrop, bin, mag_truncation, fault_behavior, year_for_calculations, Last_eq_time, Mobs, Sd_Mobs, w, Mmin, b_value, Weighted, folderPath)

warnings_rates = struct('id', {}, 'message', {}, 'values', {});

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%              PART 1 : Evaluation of the Moment Rate                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CODE TO COMPUTE Tmean and CV from geometry and slip rates data
% from ERROR PROPAGATION for Mathematica by Peruzza et al. 2010 (JOSE)
% written by F. Visini and B. Pace with the help of L. Peruzza

%%% DEFINITION OF COEFFICIENTS
%%%% coefficients by Hanks & Kanamori, 1985
d=9.1; c=1.5;

ShearModulus = ShearModulus*10^10;
StrainDrop = StrainDrop*10^-5;

%% convert input data and return the appropriate coefficients of the used
%% scale-relationships
if ~isempty(Last_eq_time) && ~isnan(Last_eq_time)
    if isempty(year_for_calculations) || isnan(year_for_calculations)
        warning_id = 'MATLAB:CurrYear';
        warning_msg = sprintf('Year: You are using current year for computing elapsed time');
        disp(warning_msg)
        warnings_rates(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', []);
        year_for_calculations=clock; yfc=year_for_calculations(1);
    else
        yfc=year_for_calculations;
    end
    Telap = yfc - Last_eq_time;
elseif isempty(Last_eq_time) || isnan(Last_eq_time) && fault_behavior == 2 || fault_behavior == 4
    error('Information not sufficient to evaluate the BPT Mw-frequency distribution. The year of the last known earthquake occcurred on the fault is necessary');
else
    Telap = []; yfc=[];
end

% convert from km to m, and from mm/yr to m/yr
Length=Length*1000;
if ~isnan(Width) % check if a Width is already indicated
    Width = Width*1000;
else % otherwise, we evaluate it using dip angle and seismogenic thickness
    Width=(Seismogenic_Thickness *1000)/sind(Dip);
end
V=(SR_min+SR_max)/2000;
dV=V-(SR_min/1000);
mag = Mobs;
sdmag = Sd_Mobs;

if all(~isnan([Width, Seismogenic_Thickness, Dip]))
    W_from_Thickness_Dip = (Seismogenic_Thickness *1000)/sind(Dip);
    if Width > W_from_Thickness_Dip
        warning_id = 'MATLAB:InvalidWidth';
        warning_msg = sprintf('Input Width is too big compared to the width evaluated from seismogenic thickness and fault dip angle (%.1f km^2).', W_from_Thickness_Dip/1000);
        disp(warning_msg)
        warnings_rates(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', W_from_Thickness_Dip);
    end
end

%%                Calculate Mmax with a standard deviation
% return the appropriate magnitudes from the used scale-relationships
[MRLD, MRA, dMRLD, dMRA, MAR, LAR, pea02_Sigma, legends_Mw, warnings_Mw_geo_ScR]=coeff2mag(m_ScR, kinematicType, Length, Width, ShearModulus, StrainDrop);
% calculate the moment magnitude
MMO= (1/c)* (log10(StrainDrop * ShearModulus* Length^2 *Width) -d);
dMMO=0.3; %standard deviation of the magnitude calculated by the seismic moment definition

% create a vector of magnitudes M and a vector of standard deviations dM
M=[MMO; MAR; MRLD; MRA; mag];
M=round(M*100)/100; %round to second decimal
dM=[dMMO; pea02_Sigma; dMRLD; dMRA; sdmag];
dM=round(dM*100)/100; %round to second decimal

M(isnan(M))=[]; % if a magnitude is equal to NaN then it is not used
dM(isnan(dM))=[]; % if a magnitude is equal to NaN then it is not used

%define a vector of common range of magnitude with a bin 0.01 for computing pdf from vectors M and dM
% if mag_truncation==0
% x_range_of_mag=floor(min(M-dM)):0.01:ceil(max(M+dM));
% else
% x_range_of_mag=floor(min(M-mag_truncation*dM)):0.01:ceil(max(M+mag_truncation*dM));
% end
if mag_truncation == 0
    x_range_of_mag = floor(min(M - dM)):0.01:ceil(max(M + dM));
else
    x_range_of_mag = floor(min(M - mag_truncation * dM)):0.01:ceil(max(M + mag_truncation * dM));
end

pdf_magnitudes = zeros(length(M), length(x_range_of_mag));
% for each M calculate a probability density function using a normal distribution
for k=1:length(M)
    pdf_magnitudes(k,:)=normpdf(x_range_of_mag,M(k),dM(k));
end

% for the Scale-Relationships derived magnitude & observed Magnitude, if desired, calculate the
% truncated distribution given the number of sd
if mag_truncation>0
    dist_trunc_mag(length(M),length(x_range_of_mag))=zeros;
    for i=1:length(M)
        lower_threshold=(M(i)-mag_truncation*dM(i));
        upper_threshold=(M(i)+mag_truncation*dM(i));
        lowest_value=find(x_range_of_mag <= lower_threshold,1,'last');
        highest_value=find(x_range_of_mag <= upper_threshold,1,'last');
        dist_trunc_mag(i,lowest_value:highest_value)=pdf_magnitudes(i,lowest_value:highest_value);
    end
    pdf_magnitudes(1:(size(dist_trunc_mag,1)),:)=dist_trunc_mag;
end

% normalize each pdf to its maximum value, so each pdf weigths as 1.
pdf_magnitudes=pdf_magnitudes./repmat((max(pdf_magnitudes,[],2)),1,size(pdf_magnitudes,2));


% check that the size of weights and magnitudes is the same
% if obs magnitude does not exist then recompute weigths to have their sum=1
% if LAR >= Length its weigth is 0
if ~isempty(Weighted) & ~isnan(Weighted)
    weights_fault = Weighted;
    if LAR>=Length
        weights_fault(2)=0;
    end
    weights=weights_fault(1:length(M))/sum(weights_fault(1:length(M)));
    pdf_magnitudes=pdf_magnitudes.*repmat((weights),1,size(pdf_magnitudes,2));
end

%%% weighted pdf are stored
out_weights=[];
if isempty(Weighted)
    out_weights(1:length(M),1)=NaN;
else
    out_weights(1:length(M),1)=weights;
end

if LAR>=Length
    out_weights(2)=0;
end


% calcuate the summed distribution
% if LAR is greater or equal than Length then LAR is not used
if LAR>=Length
    pdf_magnitudes(2,:)=[];
end
summed_pdf_magnitudes=sum(pdf_magnitudes);

% calculate mean and standard deviation of the summed distribution by
% fitting it with a normal distribution
[Mmax,sigma_Mmax] = normfit(x_range_of_mag,[],[],summed_pdf_magnitudes);
Mmax=round(Mmax*10)/10; % round to the first decimal
sigma_Mmax=round(sigma_Mmax*10)/10; % round to the first decimal

% from Mmax and sigma_Mmax calculate a probability density function using a normal distribution
% actually, this is not in the graph
gauss_fit=normpdf(x_range_of_mag,Mmax,sigma_Mmax);
if ~isempty(Weighted)
    gauss_fit=gauss_fit/max(gauss_fit);
end

% PLOT: PDF for the computed Mmax and standard deviation evaluated as the
% sum of the PDF of the scaling relations and the observed Mw (if present)
figure()
hold on

count_pdf=1;

plot(x_range_of_mag,pdf_magnitudes(count_pdf,:),'LineWidth',1.0,'LineStyle','-','Color','b')
count_pdf=count_pdf+1;
if LAR<Length
    plot(x_range_of_mag,pdf_magnitudes(count_pdf,:),'LineWidth',1.0,'LineStyle','-','Color','g')
    count_pdf=count_pdf+1;
end
plot(x_range_of_mag,pdf_magnitudes(count_pdf,:),'LineWidth',1.0,'LineStyle','-','Color','r')
count_pdf=count_pdf+1;
plot(x_range_of_mag,pdf_magnitudes(count_pdf,:),'LineWidth',1.0,'LineStyle','-','Color','c')
count_pdf=count_pdf+1;
if ~isnan(mag)
    plot(x_range_of_mag,pdf_magnitudes(count_pdf,:),'LineWidth',1.0,'LineStyle','-','Color','m')
end

plot(x_range_of_mag,summed_pdf_magnitudes,...
    'LineWidth',1.0,'LineStyle','--','Color',[0.3 0.3 0.3])

stem(Mmax,max(summed_pdf_magnitudes),'k','LineWidth',1.5)
line([(Mmax-sigma_Mmax) (Mmax+sigma_Mmax)], [max(summed_pdf_magnitudes) max(summed_pdf_magnitudes)],...
    'LineWidth',1.5,'LineStyle','--','Color',[0 0 0])
% check what magnitudes entered in the graph to have the correct legend
if LAR < Length && ~isempty(mag) && ~isnan(mag)
    legend([ 'MMo ';'MAR ';legends_Mw;'MObs'; 'SumD'; 'Mmax'])
elseif LAR < Length && isempty(mag) || isnan(mag)
    legend([ 'MMo ';'MAR ';legends_Mw;'SumD';'Mmax'])
elseif LAR >= Length && ~isnan(mag)
    legend([ 'MMo ';legends_Mw;'MObs'; 'SumD'; 'Mmax'])
elseif LAR >= Length && isnan(mag)
    legend([ 'MMo ';legends_Mw;'SumD'; 'Mmax'])
end

xlabel('Magnitude')
ylabel('Probability density function')
hold off
title(FaultName)
hold off
% pdf_magnitudes=[];

saveas(gcf, fullfile(folderPath, ['Mw_Scenario_' FaultName '.fig']));

%%       Error propagation to evaluate Tmean and alpha by error
%%              propagation formula and Seismic Moment

if LAR>=Length || out_weights(2)==0 % if  LenghtFromAspectRatio >= Length given in the input or weights is zero(MAR is not used)
    L_forTmean=Length;
else
    L_forTmean=LAR;
end

Tmean=round((10.^(d+c*Mmax)./(ShearModulus*V.*L_forTmean*Width))); % average recurrence time as defined in Field,1999
Tep=[]; % average recurrence time as defined in Peruzza et al., 2010
varTep=[]; % variance of average recurrence time as defined in Peruzza et al., 2010

Tep= (10.^(d+c*Mmax)./(ShearModulus*V.*L_forTmean*Width)) +...
    ((10.^(d+c.*Mmax)*c*log(10))./(ShearModulus*V.*L_forTmean*Width)).*sigma_Mmax -...
    (10.^(d+c.*Mmax)./(ShearModulus*(V^2).*L_forTmean*Width))*dV;

varTep= (((10.^(d+c.*Mmax)*c*log(10))./(ShearModulus*V.*L_forTmean*Width))).^2 .*(sigma_Mmax.^2) +...
    ((10.^(d+c.*Mmax)./(ShearModulus*(V^2).*L_forTmean*Width))).^2*(dV^2);

e=sqrt(varTep);
alpha=e./Tmean;

%%                       Moment rate calculation
MomentRate=(10.^(d+c.*((Mmax))))/Tmean;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%          PART 2 : Evaluation of the Fault Activity Rate              %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This part refers to the CODE TO COMPUTE Activity rates for variuos
% magnitude-frequency distribution balancing Moment Rates
% written by F. Visini and B. Pace with the help of L. Peruzza


%% Magnitude-frequency distributions
% choice of the magnitude-frequency distribution: call of the appropriate function

%% SINGLE-VALUE MODEL
if fault_behavior == 1
    %% 1) time indipendent
    Mcase = Mmax;
    M_0=10.^((c.*Mcase)+d);
    rates(:,1)=(MomentRate./M_0);
    MFD = 'Single-Value';

elseif fault_behavior == 2
    %% 2) time dipendent: Brownian Passage Time (BPT)
    %%% calculate a fictious Tmean following Pace et al., 2006
    Mcase = Mmax;
    M_0=10.^((c.*Mcase)+d);
    Tm=1/(MomentRate/M_0);
    % BPT hazard rate calculation
    if ~isnan(Telap)

        if Telap>10*Tm
            Telap=10*Tm;
            warning(strcat('Telap for the fault is forced to be equal to 10*Tm to avoid computational problems'))
        end

        Hbpt_a1(1,:)=cdf('inversegaussian',(Telap+w),Tm,(Tm/(alpha^2)));
        Hbpt_a2(1,:)=cdf('inversegaussian',(Telap),Tm,(Tm/(alpha^2)));
        Hbpt=(Hbpt_a1-Hbpt_a2)./(1-Hbpt_a2);
        Hbpt(Hbpt>1)=1;
    end
    Tfict=(-1*w)./log(1-Hbpt);

    rates(:,1)=1./Tfict;
    MFD = 'Single-Value BPT';

    %% CHARACTERISTIC GAUSSIAN MODEL
elseif fault_behavior == 3 || fault_behavior == 4
    Mcase=(Mmax-sigma_Mmax):bin:(Mmax+sigma_Mmax);
    M_0=10.^((c.*Mcase)+d);
    pdf_mag = pdf('Normal',Mcase,Mmax,sigma_Mmax);
    total_moment=sum(pdf_mag.*M_0);
    ratio=(MomentRate)/total_moment;

    if fault_behavior == 3
        %% 3) time independent
        rates=ratio*pdf_mag;
        MFD = 'Chartacteristic Gaussian';

    elseif fault_behavior == 4
        %% 4) time dipendent: Brownian Passage Time (BPT)
        balanced_pdf_moment=ratio*pdf_mag;
        CumRateMmin=sum(balanced_pdf_moment);
        Tm=1/CumRateMmin;

        % BPT hazard rate calculation
        if ~isempty(Telap)
            if Telap>10*Tm
                Telap=10*Tm;
                warning(strcat('Telap for the fault is forced to be equal to 10*Tm to avoid computational problems'))
            end

            Hbpt_a1(1,:)=cdf('inversegaussian',(Telap+w),Tm,(Tm/(alpha^2)));
            Hbpt_a2(1,:)=cdf('inversegaussian',(Telap),Tm,(Tm/(alpha^2)));
            Hbpt=(Hbpt_a1-Hbpt_a2)./(1-Hbpt_a2);
            Hbpt(Hbpt>1)=1;
        end

        % calculate a fictious Tmean following Pace et al., 2006 and a fictious
        %%% Mo rate
        Tfict=((-1*w)./log(1-Hbpt))';
        Morate_fict=MomentRate.*(Tmean./Tfict);

        ratio=(Morate_fict)/total_moment;
        balanced_pdf_moment=ratio*pdf_mag;

        Mo_balanced_fict=sum(balanced_pdf_moment.*M_0);

        rates=balanced_pdf_moment;
        MFD = 'Chartacteristic Gaussian - BPT';
    end

    %% CLASSICAL GUTENBERG-RICHTER
elseif fault_behavior == 5
    a=1; % starting value for a
    Mcase=(Mmin:bin:Mmax);
    M_0=10.^(c.*Mcase+d);

    Ncum=10.^(a-b_value.*Mcase);
    Incremental=[fliplr(diff(fliplr(Ncum))),Ncum(end)];
    Incremental_Morate=Incremental.*M_0;
    Incremental_Morate_balanced=(Incremental_Morate.*MomentRate)./sum(Incremental_Morate);
    rates=(Incremental.*Incremental_Morate_balanced)./(Incremental_Morate);
    MFD = 'Classical G-R';

    %% TRUNCATED GUTENBERG-RICHTER
elseif fault_behavior == 6
    Mcase=(Mmin:bin:Mmax);
    M_0=10.^(c.*Mcase+d);
    Beta=(2/3)*b_value;
    Mt=10^(c*Mmin+d);
    Mxp=10^(c*(Mmax+bin)+d); % added a bin to assume that the Max Magnitude given in input is reached.

    TruncGR=((((Mt./M_0).^Beta) - ((Mt./Mxp).^Beta))./(1-((Mt./Mxp).^Beta)));

    Incremental=[fliplr(diff(fliplr(TruncGR))),TruncGR(end)];
    Incremental_Morate=Incremental.*M_0;
    Incremental_Morate_balanced=(Incremental_Morate.*MomentRate)./sum(Incremental_Morate);
    rates=(Incremental.*Incremental_Morate_balanced)./(Incremental_Morate);
    MFD = 'Truncated G-R';

end

%% PLOT Mw - rates

figure()
plot(Mcase, rates,'-o', 'Color', 'k', 'MarkerFaceColor', [0.65 0.65 0.65], 'LineWidth', 1.3)
xlabel('Magnitude')
ylabel('Rates')
set(gca,'XScale', 'lin', 'YScale','log')
title(MFD)

saveas(gcf, fullfile(folderPath, ['Rates_' FaultName '.fig']));




end