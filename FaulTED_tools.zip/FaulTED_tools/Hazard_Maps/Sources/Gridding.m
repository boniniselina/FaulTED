%% %%%%%%%%%%%%%%%%%% Create grids from shapefiles %%%%%%%%%%%%%%%%%% %%
% this codes create a grid of points, resample the PF and assign to each
% point of the grid x/l and distance. Distance is positive for hangingwall
% and negative for footwall.
%%


function [PF_length, grid_PF, grid_DR_FW, grid_DR_HW] = Gridding(step, max_dist, input_shapefile, Strike)

%% 1. Grid information
pf = shaperead(input_shapefile);


%% 2. Shapefile
% read the PF shapefile

xpf_orig = [pf.X]';
ypf_orig = [pf.Y]';
xpf_orig = flipud(xpf_orig);
ypf_orig = flipud(ypf_orig);
% 
xpf_orig = xpf_orig(~isnan(xpf_orig));
ypf_orig = ypf_orig(~isnan(ypf_orig));


%% Automatic Bounding box with buffer
bbox = pf.BoundingBox;   % [minLon minLat; maxLon maxLat]

lat0_bbox = mean(bbox(:,2));
degLat = 111320;
degLon = 111320 * cosd(lat0_bbox);

buffer_m = max(max_dist) + 1000;

long_range = [bbox(1,1) - buffer_m/degLon, ...
              bbox(2,1) + buffer_m/degLon];

lat_range = [bbox(1,2) - buffer_m/degLat, ...
             bbox(2,2) + buffer_m/degLat];

x = long_range(1):step:long_range(2);
y = lat_range(1):step:lat_range(2);


[X,Y] = meshgrid(x,y);
X = X(:);
Y = Y(:);


% resampling
[ypf,xpf]=interpm(ypf_orig,xpf_orig,0.00005);


%%
% cumulative distance

e = referenceEllipsoid('wgs84');

temp_dist = zeros(length(ypf)-1,1);
temp_az = zeros(length(ypf)-1,1);

for i = 1:(length(ypf)-1)
    [temp_dist(i), temp_az(i)] = distance(ypf(i),xpf(i),ypf(i+1),xpf(i+1),e);
end
cumdist = [0; cumsum(temp_dist)];
PF_length = cumdist(end);
mean_azimuth = Strike;

%%

x_l = 0.005:0.005:1; % alla fine verranno riscalati tra 0 e 0.5
dist_x_l = PF_length.*x_l; % distance along the PF of the x/l points

h = zeros(length(dist_x_l),1);

clear i
for i = 1:length(dist_x_l)
    temp1 = abs(cumdist-dist_x_l(i));
    h(i) = find(temp1 <= min(temp1),1,'last');
end

x_l(x_l>0.5) = abs(1-x_l(x_l>0.5));

x_pf_xl = xpf(h);
y_pf_xl = ypf(h);

%% select point of the grid that are placed on hangingwall or footwall
% polygon for hangingwall or footwall

lat0 = mean(ypf);
lon0 = mean(xpf);

xpf_m = (xpf - lon0) * 111320 * cosd(lat0);
ypf_m = (ypf - lat0) * 111320;

x_pf_xl_m = (x_pf_xl - lon0) * 111320 * cosd(lat0);
y_pf_xl_m = (y_pf_xl - lat0) * 111320;

X_m = (X - lon0) * 111320 * cosd(lat0);
Y_m = (Y - lat0) * 111320;


az_pf = atan2d(xpf_m(end)-xpf_m(1), ypf_m(end)-ypf_m(1));
az_pf = mod(az_pf,360);

angle_diff = abs(atan2d(sind(az_pf - Strike), cosd(az_pf - Strike)));

if angle_diff > 90
    xpf = flipud(xpf);
    ypf = flipud(ypf);

    xpf_m = flipud(xpf_m);
    ypf_m = flipud(ypf_m);

    x_pf_xl = flipud(x_pf_xl);
    y_pf_xl = flipud(y_pf_xl);

    x_pf_xl_m = flipud(x_pf_xl_m);
    y_pf_xl_m = flipud(y_pf_xl_m);

    x_l = fliplr(x_l);
end

nG = numel(X_m);

dist_min = inf(nG,1);
side = nan(nG,1);
idx_seg = nan(nG,1);

for s = 1:length(xpf_m)-1

    ax = xpf_m(s);
    ay = ypf_m(s);

    bx = xpf_m(s+1);
    by = ypf_m(s+1);

    vx = bx - ax;
    vy = by - ay;

    wx = X_m - ax;
    wy = Y_m - ay;

    t = (wx*vx + wy*vy) ./ (vx^2 + vy^2);
    t = max(0,min(1,t));

    px = ax + t*vx;
    py = ay + t*vy;

    d = hypot(X_m - px, Y_m - py);

    crossval = vx*(Y_m - py) - vy*(X_m - px);

    k = d < dist_min;

    dist_min(k) = d(k);
    side(k) = sign(crossval(k));
    idx_seg(k) = s;
end

ihw = find(side < 0 & dist_min <= max_dist(1));
ifw = find(side > 0 & dist_min <= max_dist(2));

xhw = X(ihw);
yhw = Y(ihw);
xfw = X(ifw);
yfw = Y(ifw);


if mean_azimuth <180
polyHW = [x_pf_xl,y_pf_xl; x_pf_xl(end), min(Y); min(X),min(Y);...
min(X), y_pf_xl(1); x_pf_xl(1),y_pf_xl(1)];

polyFW = [x_pf_xl,y_pf_xl; max(X), y_pf_xl(end); max(X),max(Y);...
x_pf_xl(1), max(Y); x_pf_xl(1),y_pf_xl(1)];
else
polyFW = [x_pf_xl,y_pf_xl; min(X),y_pf_xl(end); min(X),min(Y);...
x_pf_xl(1), min(Y); x_pf_xl(1),y_pf_xl(1)];

polyHW = [x_pf_xl,y_pf_xl; x_pf_xl(end), max(Y);max(X),max(Y);...
    max(X), y_pf_xl(1);x_pf_xl(1),y_pf_xl(1)];
end  



% ihw = find(inpolygon(X,Y,polyHW(:,1),polyHW(:,2)));
% ifw = find(inpolygon(X,Y,polyFW(:,1),polyFW(:,2)));
% 
% xhw = X(ihw);
% yhw = Y(ihw);
% 
% xfw = X(ifw);
% yfw = Y(ifw);


%%



%% Distance and x_l values are assigned 

clear i 

p_r_hw = zeros(length(xhw),1);
p_x_l_hw = zeros(length(xhw),1);

for i = 1:length(xhw)

    [temp_p_r, ~] = distance(y_pf_xl,x_pf_xl,yhw(i),xhw(i),e);

    [p_r_hw(i), idx_min] = min(temp_p_r);
    p_x_l_hw(i) = x_l(idx_min);

end

dist_hw = p_r_hw;
hw_in_distance = find(dist_hw <= max_dist(1));


p_r_fw = zeros(length(xfw),1);
p_x_l_fw = zeros(length(xfw),1);

for i = 1:length(xfw)

    [temp_p_r, ~] = distance(y_pf_xl,x_pf_xl,yfw(i),xfw(i),e);

    [p_r_fw(i), idx_min] = min(temp_p_r);
    p_x_l_fw(i) = x_l(idx_min);

end

dist_fw = -1 * p_r_fw;
fw_in_distance = find(dist_fw >= -max_dist(2));



% for i = 1 : length(xhw)
%    [temp_p_r, temp_p_az] = distance(y_pf_xl,x_pf_xl,yhw(i),xhw(i),e); 
%     p_r(i) = min(temp_p_r);
%     % p_az(i) = temp_p_az (temp_p_r ==min(temp_p_r));
%     % p_x_l(i) = x_l(temp_p_r == min(temp_p_r));
% 
%     [p_r(i), idx_min] = min(temp_p_r);      
%     p_az(i) = temp_p_az(idx_min);           
%     p_x_l(i) = x_l(idx_min);
% end
% dist_hw = p_r;
% p_x_l_hw = p_x_l;
% hw_in_distance = find(dist_hw<=max_dist(1));
% 
% clear i , clear p_r, clear p_x_l, clear p_az
% for i = 1 : length(xfw)
%    [temp_p_r, temp_p_az] = distance(y_pf_xl,x_pf_xl,yfw(i),xfw(i),e); 
%     p_r(i) = min(temp_p_r);
%     % p_az(i) = temp_p_az (temp_p_r ==min(temp_p_r));
%     % p_x_l(i) = x_l(temp_p_r ==min(temp_p_r));
%     [p_r(i), idx_min] = min(temp_p_r);      
%     p_az(i) = temp_p_az(idx_min);           
%     p_x_l(i) = x_l(idx_min);
% 
% end
% dist_fw = -1* p_r;
% p_x_l_fw = p_x_l;
% fw_in_distance = find(dist_fw>=-max_dist(2));

%%
%% Output PF

grid_PF = [x_pf_xl(:), y_pf_xl(:), x_l(:)];

u = grid_PF(:,3) > 0;
grid_PF = grid_PF(u,:);

%% Output HW

grid_DR_HW = [xhw(hw_in_distance), ...
              yhw(hw_in_distance), ...
              round(dist_hw(hw_in_distance))/1000, ...
              round(p_x_l_hw(hw_in_distance),4)];

u_2 = grid_DR_HW(:,4) > 0;
grid_DR_HW = grid_DR_HW(u_2,:);

%% Output FW

grid_DR_FW = [xfw(fw_in_distance), ...
              yfw(fw_in_distance), ...
              round(dist_fw(fw_in_distance))/1000, ...
              round(p_x_l_fw(fw_in_distance),4)];

u_3 = grid_DR_FW(:,4) > 0;
grid_DR_FW = grid_DR_FW(u_3,:);

%%

%% Figures for checking

% 1: grid, fault and bounding box

figure
hold on
plot(X,Y,'.','Color',[0.8 0.8 0.8])
plot(xpf,ypf,'-r','LineWidth',2)
scatter(x_pf_xl,y_pf_xl,8,x_l,'filled')
colorbar
axis square
daspect([1 1 1])
title('Faglia ricampionata e punti x/l')
xlabel('Longitude')
ylabel('Latitude')

% 2: HW/FW with distance from PF

figure
hold on
scatter(xhw,yhw,10,dist_hw,'filled','s')
scatter(xfw,yfw,10,dist_fw,'filled','o')
plot(xpf,ypf,'-r','LineWidth',2)
colorbar
axis square
daspect([1 1 1])
title('Distanza firmata dalla faglia')
xlabel('Longitude')
ylabel('Latitude')

% 3: selected points within max_dist associated with x/l

figure
hold on
scatter(xhw(hw_in_distance),yhw(hw_in_distance),10, ...
        p_x_l_hw(hw_in_distance),'filled','s')

scatter(xfw(fw_in_distance),yfw(fw_in_distance),10, ...
        p_x_l_fw(fw_in_distance),'filled','o')

plot(xpf,ypf,'-r','LineWidth',2)
colorbar
axis square
daspect([1 1 1])
title('x/l dei punti entro distanza massima')
xlabel('Longitude')
ylabel('Latitude')





% grid_PF = [x_pf_xl,y_pf_xl,x_l'];
% % XL_site_PF=[grid_PF(:,3)];
% % grid_PF=[x_pf_xl,y_pf_xl,XL_site_PF];
% u=grid_PF(:,3)>0;
% grid_PF=grid_PF(u,:);
% 
% grid_DR_HW = [xhw(hw_in_distance),yhw(hw_in_distance),round(dist_hw(hw_in_distance)')/1000,round(p_x_l_hw(hw_in_distance)',4)];
% u_2=grid_DR_HW(:,4)>0;
% grid_DR_HW=grid_DR_HW(u_2,:);
% 
% grid_DR_FW = [xfw(fw_in_distance),yfw(fw_in_distance),round(dist_fw(fw_in_distance)')/1000,round(p_x_l_fw(fw_in_distance)',4)];
% u_3=grid_DR_FW(:,4)>0;
% grid_DR_FW=grid_DR_FW(u_3,:);

% grid_DR_tot = [xhw(hw_in_distance),yhw(hw_in_distance),round(dist_hw(hw_in_distance)'),round(p_x_l_hw(hw_in_distance)',4);
%                xfw(fw_in_distance),yfw(fw_in_distance),round(dist_fw(fw_in_distance)'),round(p_x_l_fw(fw_in_distance)',4)];
% writetable(array2table(grid_DR_tot,'VariableName',{'lon','lat','dist','x/l'}),{[FaultName,'_grid_DR.txt']});  %Nome file output Distributed
% writetable(array2table(grid_PF,'VariableName',{'lon','lat','x/l'}), {[FaultName,'_grid_PF.txt']}); %Nome file output principal
% D_F2S=round(([grid_DR_tot(:,3)]./1000),2);
% XL_site=[grid_DR_tot(:,4)];
% 
% %grid DR HW
% k=D_F2S(:)>0 & XL_site(:)>0;
% grid_DR_HW=[xhw(k),yhw(k),D_F2S(k),XL_site(k)];
% clear k
% %grid DR FW
% k=D_F2S(:)<0 & XL_site(:)>0;
% grid_DR_FW=[xfw(k),yfw(k),D_F2S(k),XL_site(k)];
%%
% figure
% hold on
% plot(X,Y,'.')
% plot(xpf,ypf,'-r')
% scatter(x_pf_xl,y_pf_xl,8,x_l,'filled')
% plot(polyHW(:,1),polyHW(:,2),'-k')
% plot(polyFW(:,1),polyFW(:,2),'-r')
% colorbar
% axis square
% 
% 
% figure
% hold on
% plot(x_pf_xl,y_pf_xl,'-r')
% scatter(xhw,yhw,10,dist_hw,'filled','Marker','s')
% scatter(xfw,yfw,10,dist_fw,'filled','Marker','o')
% colorbar
% axis square
% 
% figure
% 
% hold on
% 
% scatter(xhw(hw_in_distance),yhw(hw_in_distance),10,p_x_l_hw(hw_in_distance),'filled','Marker','s')
% scatter(xfw(fw_in_distance),yfw(fw_in_distance),10,p_x_l_fw(fw_in_distance),'filled','Marker','o')
% plot(x_pf_xl,y_pf_xl,'-r','LineWidth',2)
% colorbar
% axis square
% daspect([1 1 1])

end