%% Function to account for the uncertainties related to the location of 
%% the ruptures along the main fault trace 
% (e.g., fr(r) from Petersen et al., 2011 - 
% Respect zone suggested by Guidelines of Seismic Microzonation for ACF in Italy)

function [grid_DR_HW, grid_DR_FW, grid_PF] = adjust_grids(grid_PF_or, grid_DR_HW_or, grid_DR_FW_or, Fault_zone)

    grid_PF = grid_PF_or;
    grid_DR_HW = grid_DR_HW_or;
    grid_DR_FW = grid_DR_FW_or;

    buffer_HW = Fault_zone(1); % m
    buffer_FW = Fault_zone(2); % m

    % from m to km
    buffer_HW_km = buffer_HW / 1000;
    buffer_FW_km = buffer_FW / 1000;

    idx_HW_near = grid_DR_HW_or(:,3) <= buffer_HW_km;
    grid_DR_HW(idx_HW_near, 3) = 0;

    idx_FW_near = grid_DR_FW_or(:,3) >= -buffer_FW_km;
    grid_DR_FW(idx_FW_near, 3) = 0;

    % Readjusting r_0 
    idx_HW_far = grid_DR_HW_or(:,3) > buffer_HW_km;
    grid_DR_HW(idx_HW_far, 3) = grid_DR_HW_or(idx_HW_far, 3) - buffer_HW_km;
    idx_FW_far = grid_DR_FW_or(:,3) > buffer_FW_km;
    grid_DR_FW(idx_FW_far, 3) = grid_DR_FW_or(idx_FW_far, 3) - buffer_FW_km;

    % grid points falling within the fault zone are included within 
    % the PF grid and removed from HW/FW grids 
    removed_idx_hw = [];
    removed_idx_fw = [];

    for i = 1:size(grid_DR_HW, 1)
        if grid_DR_HW(i,3) == 0
            removed_idx_hw = [removed_idx_hw, i];
        end
    end
    grid_PF = [grid_PF; grid_DR_HW_or(removed_idx_hw, [1,2,4])];
    grid_DR_HW(removed_idx_hw, :) = [];

    for j = 1:size(grid_DR_FW, 1)
        if grid_DR_FW(j,3) == 0
            removed_idx_fw = [removed_idx_fw, j];
        end
    end
    grid_PF = [grid_PF; grid_DR_FW_or(removed_idx_fw, [1,2,4])];
    grid_DR_FW(removed_idx_fw, :) = [];

end
