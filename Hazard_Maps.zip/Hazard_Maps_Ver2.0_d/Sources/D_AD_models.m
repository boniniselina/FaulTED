%% Available models to fit AD data
% Here we define a structure including all the models available
% in the scientific literature to evaluate D/AD.
% The data are usually fit with a Gamma distribution.

% The main authors are listed below, while the corresponding model number 
% is reported within ():

%% Youngs et al. (2003) - YEA03
% The authors focused on normal faults (1)

%% Moss et al. (2022) - MEA22
% The authors focused on reverse faults (2)

%% Petersen et al. (2011) - PEA11
% The authors focused on strike-slip faults documenting other types of
% regressions for the displacement distribution along the PF ( -a) Bilinear,
% -b) Quadratic, -c) Elliptical) which are not listed below. Pet11_a,
% Pet11_b and Pet11_c could be found directly in the Pexceedance function

%% Takao et al. (2013) - TEA13
% The authors analyzed both reverse and strike-slip faults (3)
% Warning: this model is based on Japanese earthquakes data 
% The model may not be suitable out of this geographic area

function D_models = D_AD_models()

D_models = struct(); % initializing the structure for the fit models

D_models(1).name = 'YEA03';
D_models(1).kinematics = 'N';
D_models(1).a = @(x) exp(-0.193 + 1.628 * x);
D_models(1).b = @(x) exp(0.009 - 0.476 * x);
D_models(1).function = 'Gamma';

D_models(2).name = 'MEA22';
D_models(2).kinematics = 'R';
D_models(2).a = @(x) 4.2797 * x + 1.6216;
D_models(2).b = @(x) -0.5003 * x + 0.5133;
D_models(2).function = 'Gamma';

D_models(3).name = 'TEA13'; % L > 10km
D_models(3).kinematics = 'R-SS';
D_models(3).a = @(x) exp(0.70 + 0.34 * x);
D_models(3).b = @(x) exp(-1.40 + 1.82 * x);
D_models(3).function = 'Gamma';

D_models(4).name = 'TEA13_b'; % L < 10km
D_models(4).kinematics = 'R-SS';
D_models(4).a = 1.53;
D_models(4).b = 0.58;
D_models(4).function = 'Gamma';

% Save the structure 
% save('AD_models.mat', "D_models", '-mat')

end