%% Log File for the Hazard Curves Code
% This function stands for the generation of a report, for each input faults,
% resumming all the input information and the main results

function LogFile(FaultName,folderPath,faultData,Width,Telap,yfc,Mmax,sigma_Mmax,Tmean,...
            MomentRate,MFD,Mcase,rates,P_slip_coeff,srl_case,configurations,Ll_cases,...
            P_2p,warnings_Mw_geo_ScR,warnings_rates,warnings_Pslip,warnings_Pexc,...
            warnings_Mw_srl,warnings_Pslip_DR_AT, model_mag_range_DR, model_dist_range_DR,...
            warnings_DR_AT, Pexc_model_mag_range_DR, Pexc_model_dist_range_DR,P_exc_model_coefficients_DR_hw,P_exc_model_coefficients_DR_fw)


%% File generation within the corresponding output directory
report_file = sprintf('%s_Report.txt', FaultName);
report_path = fullfile(folderPath, report_file);

counter_2 = 1;
while exist(report_path, 'file') % Check if the file already exists
    report_path = fullfile(folderPath, sprintf('%s_Report(%d).txt', FaultName, counter_2));
    counter_2 = counter_2 + 1;
end

fileID = fopen(report_path, 'a');
if fileID == -1
    error('Report not generated: %s', report_path);
end

%% START WRITING THE REPORT

% HEADINGS
fprintf(fileID, '*****************************************************************************************\n');
fprintf(fileID, 'REPORT FOR FAULT: %s\n', FaultName);
fprintf(fileID, 'Generated on: %s\n', datetime("now"));
fprintf(fileID, '*****************************************************************************************\n\n');

%% FAULT PARAMETERS
fprintf(fileID, 'FAULT PARAMETERS:\n');
fprintf(fileID, '- Fault Name: %s\n', FaultName);
fprintf(fileID, '- Kinematics: %s\n',faultData.Fault_parameters.kinematicType);
fprintf(fileID, '- Length (FSL): %s km\n', num2str(faultData.Fault_parameters.Length));
if ~isempty(faultData.Fault_parameters.Dip) & ~isnan(faultData.Fault_parameters.Dip) & ~isempty(faultData.Fault_parameters.Seismogenic_Thickness) & ~isnan(faultData.Fault_parameters.Seismogenic_Thickness)
    fprintf(fileID, '- Width: %s km ', num2str(round(Width/1000,1)));
    fprintf(fileID, '(which was evaluated from Dip angle: %s° and Seismogenic Thickness: %s km)\n', num2str(faultData.Fault_parameters.Dip), num2str(faultData.Fault_parameters.Seismogenic_Thickness));
else
    fprintf(fileID, '- Width: %s km\n ', num2str(round(faultData.Fault_parameters.Width,1)));
end
fprintf(fileID, '-----------------------------------------------------------------------------------------\n\n');

%% EVALUATION SITE INFORMATION
fprintf(fileID, 'DESIGN INFORMATION:\n');
if ~isempty(faultData.Design_information.Recurrence_time) && ~isnan(faultData.Design_information.Recurrence_time)
    fprintf(fileID, '- Design Recurrence Time: %s years\n', num2str(faultData.Design_information.Recurrence_time));
end
if ~isempty(faultData.Design_information.Design_displ) && ~isnan(faultData.Design_information.Design_displ)
    fprintf(fileID, '- Design displacement: %s m\n', num2str(faultData.Site_information.Design_displ));
end

fprintf(fileID, '-----------------------------------------------------------------------------------------\n\n');

%% FAULT ACTIVITY
fprintf(fileID, 'FAULT ACTIVITY:\n');
fprintf(fileID, '- Slip Rate: %s - %s mm/yr\n', num2str(faultData.Fault_activity.SR_min), num2str(faultData.Fault_activity.SR_max));
if ~isempty(faultData.Fault_activity.Mobs) && ~isnan(faultData.Fault_activity.Mobs)
    fprintf(fileID, '- Last known earthquake occurred in %s with an observated Mw: %s ± %s \n', num2str(faultData.Fault_activity.Last_eq_time), num2str(faultData.Fault_activity.Mobs), num2str(faultData.Fault_activity.Sd_Mobs));
    fprintf(fileID, '- Elapsed time: %s yr from today (%s)\n', num2str(Telap), num2str(yfc));
else
    fprintf(fileID, '- Last earthquake documented on the fault: unknown');
end
fprintf(fileID, '- Shear Modulus (mu): %s*10^10 Pa\n', num2str(faultData.Fault_activity.ShearModulus));
fprintf(fileID, '- Strain Drop: %s*10^-5\n', num2str(faultData.Fault_activity.ShearModulus));


if ~isempty(faultData.Fault_activity.Input_Mw) && all(~isnan(faultData.Fault_activity.Input_Mw)) && ~isempty(faultData.Fault_activity.Input_probability) && all(~isnan(faultData.Fault_activity.Input_probability))
    fprintf(fileID, 'Custumer input for Mw-frequency distribution: \n - Mw = %s \n - rates = %s \n', num2str(faultData.Fault_activity.Input_Mw), num2str(faultData.Fault_activity.Input_probability));
else
    if ~isempty(faultData.Fault_activity.mag_truncation)
        fprintf(fileID, 'Considering the chosen Scaling Relation between Mw and fault rupture length and area (%s),\n the %s fault is expected to generate an earthquake of maximum Mw: %s ± %s (evaluated with a truncation of %s sigma)\n with a mean recurrence interval: %s yr \n', faultData.Fault_activity.m_ScR, FaultName, num2str(Mmax), num2str(sigma_Mmax), num2str(faultData.Fault_activity.mag_truncation), num2str(Tmean));
    else
        fprintf(fileID, 'Considering the chosen Scaling Relation between Mw and fault rupture length and area (%s),\n the %s fault is expected to generate an earthquake of maximum Mw: %s ± %s with a mean recurrence interval: %s yr \n', faultData.Fault_activity.m_ScR, FaultName, num2str(Mmax), num2str(sigma_Mmax), num2str(Tmean));
    end

        fprintf(fileID, 'The evaluated Moment Rate is %.3e Nm/yr\n', MomentRate);
        fprintf(fileID, 'The chosen Magnitude-Frequency distribution is %s\n', MFD);

    if faultData.Fault_activity.fault_behavior == 1
        fprintf(fileID, 'Then, Mmax: %s represents the evaluated Characteristic Mw\n', num2str(Mmax));
        % fprintf(fileID, 'corresponding to an annual rate of %s\n', num2str(rates));
    elseif faultData.Fault_activity.fault_behavior == 2
        fprintf(fileID, 'Then, Mmax: %s represents the evaluated Characteristic Mw\n', num2str(Mmax));
        fprintf(fileID, 'The annual rate is evaluated for a probability window of %s years\n', num2str(faultData.Fault_activity.w));
    elseif faultData.Fault_activity.fault_behavior == 3
        fprintf(fileID, 'The fault is expected to generate a symmetric gaussian distribution of earthquakes Mw centred on Mmax\n The Mw values are calculated from Mmax-sd to Mmax+sd with a bin: %s\n', faultData.Fault_activity.bin);
    elseif faultData.Fault_activity.fault_behavior == 4
        fprintf(fileID, 'The fault is expected to generate a symmetric gaussian distribution of earthquakes Mw centred on Mmax\n The Mw values are calculated from Mmax-sd to Mmax+sd with a bin: %s,\n for a probability window of %s years\n', num2str(faultData.Fault_activity.bin), num2str(faultData.Fault_activity.w));
    else
        fprintf(fileID, 'The Mw values are calculated from from Mmin: %s to Mmax with a bin: %s, for a b value: %s\n', num2str(faultData.Fault_activity.Mmin), num2str(faultData.Fault_activity.bin), num2str(faultData.Fault_activity.b_value));
    end

    fprintf(fileID, '-----------------------------------\n');
    fprintf(fileID, '| Magnitude value |      Rate     |\n');
    fprintf(fileID, '-----------------------------------\n');
    for i = 1:length(Mcase)
        fprintf(fileID, '|      %6.1f     |  %10.5e  |\n', Mcase(i), rates(i));
    end
    fprintf(fileID, '-----------------------------------\n');


end

if ~isempty(warnings_Mw_geo_ScR)
    fprintf(fileID, 'WARNING MESSAGES:\n');
    for i = 1:length(warnings_Mw_geo_ScR)
        fprintf(fileID, '- %s\n', warnings_Mw_geo_ScR(i).message);
    end
end

if ~isempty(warnings_rates)
    fprintf(fileID, 'WARNING MESSAGES:\n');
    for i = 1:length(warnings_rates)
        fprintf(fileID, '- %s\n', warnings_rates(i).message);
    end
end
fprintf(fileID, '\n-----------------------------------------------------------------------------------------\n\n');

%% EVALUATION OF THE DISPLACEMENT ATTENUATION LAW FOR PF
fprintf(fileID, 'EVALUATION OF THE DISPLACEMENT ATTENUATION LAW FOR PF:\n');
fprintf(fileID, '   a) Probability of surface rupture\n');
fprintf(fileID, 'The chosen model is %s\n', faultData.PFDH_model_PF.P_slip_m);
if ~isempty(P_slip_coeff)
    fprintf(fileID, 'characterized by f(x) = %s + %s*Mw\n', num2str(P_slip_coeff(1)),num2str(P_slip_coeff(2)));
end
if ~isempty(warnings_Pslip)
    fprintf(fileID, 'WARNING MESSAGES:\n');
    for i = 1:length(warnings_Pslip)
        fprintf(fileID, '- %s\n', warnings_Pslip(i).message);
    end
end
fprintf(fileID, '   b) Conditional probability of exceedance\n');
fprintf(fileID, 'The chosen model is %s\n', faultData.PFDH_model_PF.P_D_model);
fprintf(fileID, 'The calculation is performed with the following input faultData:\n');
if faultData.PFDH_model_PF.Displ_type == 1
    if ~isempty(faultData.PFDH_model_PF.d_truncation)
        if any(strcmp(faultData.PFDH_model_PF.P_D_model, {'PEA11_a', 'PEA11_b', 'PEA11_c'}))
            fprintf(fileID, '- The scaling relation between average displacement AD and Mw (%s)\n', faultData.PFDH_model_PF.d_ScR, num2str(faultData.PFDH_model_PF.d_truncation));
        else
            fprintf(fileID, '- The scaling relation between average displacement AD and Mw (%s) with truncation of the pdf at %s sigma is selected\n', faultData.PFDH_model_PF.d_ScR, num2str(faultData.PFDH_model_PF.d_truncation));
        end
    else
        fprintf(fileID, '- The scaling relation between average displacement AD and Mw (%s) without truncation of the pdf is selected\n', faultData.PFDH_model_PF.d_ScR);
    end
else
    if ~isempty(faultData.PFDH_model_PF.d_truncation)
        fprintf(fileID, '- The scaling relations between maximum displacement MD and Mw (%s) with truncation of the pdf at %s sigma is selected\n', faultData.PFDH_model_PF.d_ScR, num2str(faultData.PFDH_model_PF.d_truncation));
    else
        fprintf(fileID, '- The scaling relations between maximum displacement MD and Mw (%s) without truncation of the pdf is selected\n', faultData.PFDH_model_PF.d_ScR);
    end
end

if ~isempty(warnings_Pexc)
    fprintf(fileID, 'WARNING MESSAGES:\n');
    for i = 1:length(warnings_Pexc)
        fprintf(fileID, '- %s\n', warnings_Pexc(i).message);
    end
end
fprintf(fileID, '-----------------------------------------------------------------------------------------\n\n');

%% EVALUATION OF THE FLOATING OF THE RUPTURES
if faultData.PFDH_model_PF.floating==1
    fprintf(fileID, 'EVALUATION OF THE FLOATING OF THE RUPTURES along the PF:\n');
    % if classic == 1
    %     fprintf(fileID, 'Classic methodology');
    % else
        fprintf(fileID, 'Alternative methodology by Bonini et al. (2025)\n');
    % end
    fprintf(fileID, 'Using %s as scaling relation between rupture length at the surface and Mw\n', faultData.PFDH_model_PF.srl_ScR);
    fprintf(fileID, 'The following rupture segment lengths (km) are tested:\n');
    
    fprintf(fileID, '-----------------------------------\n');
    fprintf(fileID, '| Magnitude value |     L (km)    |\n');
    fprintf(fileID, '-----------------------------------\n');
    for i = 1:length(Mcase)
        fprintf(fileID, '|      %6.1f     |  %10.2f   |\n', Mcase(i), srl_case(i));
    end
    fprintf(fileID, '-----------------------------------\n');

    fprintf(fileID, 'Each rupture is traslated along the PF with a step of: %s km\n', num2str(faultData.PFDH_model_PF.floating_bin));

    if ~isempty(warnings_Mw_srl)
        fprintf(fileID, 'WARNING MESSAGES:\n');
        for i = 1:length(warnings_Mw_srl)
            fprintf(fileID, '- %s\n', warnings_Mw_srl(i).message);
        end
    end

    fprintf(fileID, '-----------------------------------------------------------------------------------------\n\n');
else
    fprintf(fileID, 'No floating rutures.\n');
    fprintf(fileID, '-----------------------------------------------------------------------------------------\n\n');

end

%% EVALUATION OF THE P2p FROM TAKAO ET AL. (2013)
if faultData.PFDH_model_PF.P2p==1
    fprintf(fileID, 'EVALUATION OF THE P2p FROM TAKAO ET AL. (2013):\n');
    fprintf(fileID, 'WARNING: TAKAO ET AL. (2013, 2014, 2016) approaches have been generated analyzing JAPANESE EARTHQUAKES ONLY.\n Therefore, the regressions may not be suitable out of this geographic area!\n');
    first_p = cellfun(@(x) x(1), configurations);
    last_p = cellfun(@(x) x(end), configurations);
    fprintf(fileID, 'The tested fault configurations are:\n');
    fprintf(fileID, 'i) %s - %s\n', num2str(first_p(1)), num2str(last_p(1)));
    fprintf(fileID, 'ii) %s - %s\n', num2str(first_p(2)), num2str(last_p(2)));
    fprintf(fileID, 'Translation along PF is performed considering a bin of 1 km\n');

    Title_p2p = {'Mw', 'Ll_case_a (km)', 'Ll_case_b (km)', 'Ll_case_c (km)', 'Ll_case_d (km)'};

    fprintf(fileID, '%s\n', repmat('=', 1, 80));

    fprintf(fileID, '%s\n', repmat('=', 1, 80));
    fprintf(fileID, '%15s   %15s   %15s   %15s   %15s\n', Title_p2p{:});

    for m = 1:length(Mcase)
        fprintf(fileID, '%15.3s   %15s  %15s   %15s   %15s\n', ...
            num2str(Mcase(m)), num2str(round(Ll_cases(m,1),2)), num2str(round(Ll_cases(m,2),2)), ...
            num2str(round(Ll_cases(m,3),2)), num2str(round(Ll_cases(m,4),2)));
    end

fprintf(fileID, 'Where Ll_cases are the segments rupture length resulting from the tri-linear models.\n');
fprintf(fileID, '-----------------------------------------------------------------------------------------\n\n');
end

%% EVALUATION OF THE ATTENUATION LAW FOR DR
if ~isempty(faultData.PFDH_model_DR.Pslip_DR_m) && ~isempty(faultData.PFDH_model_DR.Pexc_DR_m) 
    fprintf(fileID, '\nEVALUATION OF THE CONDITIONAL PROBABILITY OF SURFACE RUPTURES AT A SPECIFIC SITE LOCATION FOR DISTRIBUTED RUPTURES:\n');
    fprintf(fileID, 'The chosen model is %s, which is characterized by:\n', faultData.PFDH_model_DR.Pslip_DR_m);

    if strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'YEA03')
        fprintf(fileID,'FUNCTIONAL FORM 1 (Equation 7)\n f(x) = 2.06 + (-4.62 + 0.118*m + 0.682*h)*ln(r+3.32)\n where h = 1 if HW and h = 0 if FW\n');
        fprintf(fileID,'FUNCTIONAL FORM 2 (Equation 8)\n f(x) = 3.27 + (-8.28 + 0.577*m + 0.629*h)*ln(r+4.14)+tz\n where h = 1 if HW and h = 0 if FW\n tz is  a random variate\n');
        fprintf(fileID,'The final result is calculated by averaging the two equations\n');  
    elseif any(strcmp(faultData.PFDH_model_DR.Pslip_DR_m, {'FL21_a', 'FL21_b'}))
        if strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'FL21_a')
                fprintf(fileID,'FUNCTIONAL FORM 3 (Regular Scenario)\n f(x) = -2.254 + -1.175*ln(r+1e-5)\n for Hanging Wall\n');
                fprintf(fileID,'FUNCTIONAL FORM 3 (Regular Scenario)\n f(x) = -3.459 + -1.903*ln(r+1.008e-5)\n for Footwall\n');
        elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'FL21_b')
                fprintf(fileID,'FUNCTIONAL FORM 3 (Conservative Scenario)\n f(x) = -1.888 + -0.8802*ln(r+1.009e-5)\n for Hanging Wall\n');
                fprintf(fileID,'FUNCTIONAL FORM 3 (Conservative Scenario)\n f(x) = -2.505 + -1.181*ln(r+1.006e-5)\n for Footwall\n');
        end
    elseif any(strcmp(faultData.PFDH_model_DR.Pslip_DR_m, {'PEA11_a', 'PEA11_b', 'PEA11_c', 'PEA11_d', 'PEA11_e'}))
        if strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'PEA11_a') % 25 m
            fprintf(fileID,'FUNCTIONAL FORM 4\n f(x) = exp(-1.147* ln(r*1000)+2.1046)\n');
        elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'PEA11_b') % 50 m
            fprintf(fileID,'FUNCTIONAL FORM 4\n f(x) = exp(-0.900* ln(r*1000)+0.9866)\n');
        elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'PEA11_c') % 100 m
            fprintf(fileID,'FUNCTIONAL FORM 4\n f(x) = exp(-1.0114* ln(r*1000)+2.5572)\n');
        elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'PEA11_d') % 150 m
            fprintf(fileID,'FUNCTIONAL FORM 4\n f(x) = exp(-1.0934* ln(r*1000)+3.5526)\n');
        elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'PEA11_e') % 200 m
            fprintf(fileID,'FUNCTIONAL FORM 4\n f(x) = exp(-1.1538* ln(r*1000)+4.2342)\n');
        end           
    elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'TEA13')
        fprintf(fileID,'FUNCTIONAL FORM 1\n f(x) = -3.839 + (-3.886 + 0.350*m)*ln(r+0.2)\n');
    elseif any(strcmp(faultData.PFDH_model_DR.Pslip_DR_m, {'TEA14_a', 'TEA14_b', 'TEA14_c', 'TEA14_d'}))
        if strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'TEA14_a') % 50 m
            fprintf(fileID,'FUNCTIONAL FORM 3\n f(x) = -6.988 + -1.410*ln(r+0.2)\n');
        elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'TEA14_b') % 100 m
            fprintf(fileID,'FUNCTIONAL FORM 3\n f(x) = -6.135 + -1.427*ln(r+0.2)\n');
        elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'TEA14_c') % 250 m
            fprintf(fileID,'FUNCTIONAL FORM 3\n f(x) = -4.903 + -1.459*ln(r+0.2)\n');
        elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'TEA14_d') % 500 m
            fprintf(fileID,'FUNCTIONAL FORM 3\n f(x) = -3.859 + -1.499*ln(r+0.2)\n');
        end

    elseif strcmp(faultData.PFDH_model_DR.Pslip_DR_m, 'MEA22')
            fprintf(fileID, 'P(d>0) = exp(-2.2*r+0.5)\n for Hanging Wall\n');
            fprintf(fileID, 'P(d>0) = exp(-2.4*r+0.4)\n for Footwall\n');
    end

    if ~isempty(warnings_Pslip_DR_AT)
        ids = {warnings_Pslip_DR_AT.id};
        hasDistanceExceeds = any(strcmp(ids, 'MATLAB:DistanceExceeds'));
        hasInvalidMw = any(strcmp(ids, 'MATLAB:InvalidMw'));
        hasInvalidKinematics = any(strcmp(ids, 'MATLAB:InvalidKin'));
        fprintf(fileID, 'WARNING MESSAGES:\n');

        if faultData.PFDH_model_PF.floating==1 && hasDistanceExceeds
            % if classic == 0
                fprintf(fileID, '- Some revalued distances exceed the model limit [%s km]. The results will be an extrapolation\n', num2str(model_dist_range_DR));
            % else
            %     fprintf(fileID, '- r_0 exceeds the model limit [%s km]. The results will be an extrapolation\n', num2str(model_dist_range_DR));
            % end
        end
        if hasInvalidMw
                fprintf(fileID, '- Some tested Mw values exceed the valid range of the model [%s - %s]. The results will be an extrapolation\n', num2str(model_mag_range_DR(1)), num2str(model_mag_range_DR(2)));
        end
        if hasInvalidKinematics
                fprintf(fileID, '- The input fault kinematics is not consistent with the chosen model.\n');                
        end
    end
    fprintf(fileID, '-----------------------------------------------------------------------------------------\n\n');


    fprintf(fileID, '\nEVALUATION OF THE CONDITIONAL PROBABILITY OF EXCEEDANCE FOR DISTRIBUTE RUPTURES\n');
    fprintf(fileID, 'The chosen model is %s\n', faultData.PFDH_model_DR.Pexc_DR_m);

    if any(strcmp(faultData.PFDH_model_DR.Pexc_DR_m, {'YEA03_a', 'YEA03_b','MEA22_a', 'MEA22_b'}))  
        fprintf(fileID, 'It is based on the equation:\n Largest d/MD (or AD) = %s * exp(%s * r)\n for Hanging Wall\n', P_exc_model_coefficients_DR_hw(1,1),P_exc_model_coefficients_DR_hw(1,2));
        fprintf(fileID, 'It is based on the equation:\n Largest d/MD (or AD) = %s * exp(%s * r)\n for Footwall\n', P_exc_model_coefficients_DR_fw(1,1),P_exc_model_coefficients_DR_fw(1,2));
    elseif any(strcmp(faultData.PFDH_model_DR.Pexc_DR_m, {'TEA13_a', 'TEA13_b', 'TEA14'})) 
        fprintf(fileID, 'It is based on the equation:\n Largest d/MD (or AD) = %s * exp(%s * r)\n', P_exc_model_coefficients_DR_hw(1,1),P_exc_model_coefficients_DR_hw(1,2));
    elseif strcmp(faultData.PFDH_model_DR.Pexc_DR_m,'PEA11')
        fprintf(fileID, 'It is based on the equation: ln(d) = 1.4016*m-0.1671*ln(r)-6.79971\n');
    end

    if ~isempty(warnings_DR_AT)
        ids = {warnings_DR_AT.id};
        hasDistanceExceeds = any(strcmp(ids, 'MATLAB:DistanceExceeds'));
        hasInvalidMw = any(strcmp(ids, 'MATLAB:InvalidMw'));
        hasInvalidKinematics = any(strcmp(ids, 'MATLAB:InvalidKin'));
        fprintf(fileID, 'WARNING MESSAGES:\n');

        if faultData.PFDH_model_PF.floating==1 && hasDistanceExceeds
            % if classic == 0
            %     fprintf(fileID, '- Some revalued distances exceed the model limit [%s km]. The results will be an extrapolation\n', num2str(Pexc_model_dist_range_DR));
            % else
                fprintf(fileID, '- r_0 exceeds the model limit [%s km]. The results will be an extrapolation\n', num2str(Pexc_model_dist_range_DR));
        %     end
        % end
        if hasInvalidMw
                fprintf(fileID, '- Some tested Mw values exceed the valid range of the model [%s - %s]. The results will be an extrapolation\n', num2str( Pexc_model_mag_range_DR(1)), num2str(Pexc_model_mag_range_DR(2)));
        end
        if hasInvalidKinematics
                fprintf(fileID, '- The input fault kinematics is not consistent with the chosen model.\n');                
        end

    end


    fprintf(fileID, '-----------------------------------------------------------------------------------------\n\n');

else
end

%% END OF THE REPORT
fclose(fileID);

end

