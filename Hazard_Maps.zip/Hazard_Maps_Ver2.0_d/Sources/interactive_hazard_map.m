function interactive_hazard_map(grid_PF, grid_PF_or, grid_DR_FW, grid_DR_HW, poe_PF_fin, poe_DR_FW, poe_DR_HW, i, HC_PF_plot, HC_DR_FW_plot, HC_DR_HW_plot, displacement_levels, FaultName, Recurrence_time)

% Main window
fig = uifigure('Name', 'Fault Displacement Hazard Maps', 'Position', [100, 100, 1200, 600]);

% Tabs for maps
tabGroup = uitabgroup(fig, 'Position', [10, 10, 800, 580]);
tabPF = uitab(tabGroup, 'Title', 'Principal Faulting');
tabDR = uitab(tabGroup, 'Title', 'Distributed Ruptures');

axMapPF = uiaxes(tabPF, 'Position', [10, 10, 780, 560]);
axMapDR = uiaxes(tabDR, 'Position', [10, 10, 780, 560]);

% Info panel
panelInfo = uipanel(fig, 'Position', [820, 10, 370, 580]);
axCurve = uiaxes(panelInfo, 'Position', [20, 300, 330, 250]);
title(axCurve, 'Hazard Curve');
tbl = uitable(panelInfo, 'Position', [20, 100, 330, 180]);
btnSave = uibutton(panelInfo, 'Position', [110, 50, 150, 40], 'Text', 'Save Hazard Curve', 'ButtonPushedFcn', @(btn, event) save_curve());

% Calculating upper and lower limits for map axes
min_long_HW = min(grid_DR_HW(:,1));
min_lat_HW = min(grid_DR_HW(:,2));
min_long_FW = min(grid_DR_FW(:,1));
min_lat_FW = min(grid_DR_FW(:,2));

min_long = min(min_long_HW,min_long_FW);
min_lat = min(min_lat_HW,min_lat_FW);

max_long_HW = max(grid_DR_HW(:,1));
max_lat_HW = max(grid_DR_HW(:,2));
max_long_FW = max(grid_DR_FW(:,1));
max_lat_FW = max(grid_DR_FW(:,2));

max_long = max(max_long_HW,max_long_FW);
max_lat = max(max_lat_HW,max_lat_FW);

valid_idx = ~isnan(poe_PF_fin(i,:));  % find non-NaN indexes
valid_idx_fw = ~isnan(poe_DR_FW(:,i));  
valid_idx_hw = ~isnan(poe_DR_HW(:,i));  

% Plot PF Grid
hold(axMapPF, 'on');
plot(axMapPF, grid_PF_or(:,1), grid_PF_or(:,2), 'k', 'LineWidth', 2);
scatter(axMapPF, grid_PF(valid_idx,1), grid_PF(valid_idx,2), 30, poe_PF_fin(i, valid_idx), 'Filled');
colormap(axMapPF, cool);
cbarPF = colorbar(axMapPF);
cbarPF.Label.String = 'Displacement (m)';
xlim(axMapPF,[min_long max_long]);
ylim(axMapPF,[min_lat max_lat]);
title(axMapPF, [FaultName, ' Fault - T_R = ', num2str(Recurrence_time), ' yrs']);
xlabel(axMapPF, 'Longitude (°)'); ylabel(axMapPF, 'Latitude (°)');
grid(axMapPF, 'on');
% fontsize(axMapPF,scale=1.2)

% Plot DR Grid
hold(axMapDR, 'on');
scatter(axMapDR, grid_DR_FW(valid_idx_fw,1), grid_DR_FW(valid_idx_fw,2), 30, poe_DR_FW(valid_idx_fw,i), 'Filled');
scatter(axMapDR, grid_DR_HW(valid_idx_hw,1), grid_DR_HW(valid_idx_hw,2), 30, poe_DR_HW(valid_idx_hw,i), 'Filled');
plot(axMapDR, grid_PF_or(:,1), grid_PF_or(:,2), 'k', 'LineWidth', 2);
xlim(axMapDR,[min_long max_long]);
ylim(axMapDR,[min_lat max_lat]);
colormap(axMapDR, parula);
cbarDR = colorbar(axMapDR);
cbarDR.Label.String = 'Displacement (m)';
grid(axMapDR, 'on');

title(axMapDR, [FaultName, ' Fault - T_R = ', num2str(Recurrence_time), ' yrs']);
xlabel(axMapDR, 'Longitude (°)'); ylabel(axMapDR, 'Latitude (°)');

    function txt = display_curve(~, event_obj)
        pos = get(event_obj, 'Position');
        cla(axCurve);
    
        if tabGroup.SelectedTab == tabPF
            % Principal Faulting
            distPF = sqrt((grid_PF(:,1) - pos(1)).^2 + (grid_PF(:,2) - pos(2)).^2);
            [~, idx] = min(distPF);
            hazardCurve = HC_PF_plot(idx, :);
            gridName = 'Main Fault';    
            y_FSL = grid_PF(idx, 3); % y/FSL
            displacement = poe_PF_fin(i, idx); % Displacement
            r_distance = NaN; % Not applicable for PF
    
        else
            % Distributed Ruptures
            distFW = sqrt((grid_DR_FW(:,1) - pos(1)).^2 + (grid_DR_FW(:,2) - pos(2)).^2);
            distHW = sqrt((grid_DR_HW(:,1) - pos(1)).^2 + (grid_DR_HW(:,2) - pos(2)).^2);
            [minDistFW, idxFW] = min(distFW);
            [minDistHW, idxHW] = min(distHW);
    
            if minDistFW < minDistHW
                idx = idxFW;
                hazardCurve = HC_DR_FW_plot(idx, :);
                gridName = 'Footwall';
                y_FSL = grid_DR_FW(idx, 4); % y/FSL
                r_distance = grid_DR_FW(idx, 3); % Distance r_0
                displacement = poe_DR_FW(idx, i); % Displacement
            else
                idx = idxHW;
                hazardCurve = HC_DR_HW_plot(idx, :);
                gridName = 'Hanging Wall';
                y_FSL = grid_DR_HW(idx, 4); % y/FSL
                r_distance = grid_DR_HW(idx, 3); % Distance r_0
                displacement = poe_DR_HW(idx, i); % Displacement
            end
        end
    
        % Updating hazard curve
        hold(axCurve, 'on');
        loglog(axCurve, displacement_levels, hazardCurve, 'LineWidth', 2);  
        set(axCurve, 'YScale', 'log', 'XScale', 'log');
        ylim(axCurve, [1E-8 1E-1]);
        xlim(axCurve, [1E-3 1E2]);
        xlabel(axCurve, 'Displacement (m)'); ylabel(axCurve, 'Annual Frequency of Exceedance (yr^-^1)');
        title(axCurve, sprintf('Hazard Curve'));
        subtitle(axCurve, sprintf('%s (%.2f°, %.2f°)', gridName, pos(1), pos(2)));
        grid(axCurve, 'on');
    
        % Updating table
        tbl.Data = [displacement_levels(:), hazardCurve(:)];
        tbl.ColumnName = {'Displacement (m)', 'AFOE (1/yr)'};
    
        % Data for the bottom "Save Hazard Curve"
        assignin('base', 'selected_curve_data', tbl.Data);
        assignin('base', 'selected_grid_name', gridName);
        assignin('base', 'selected_position', pos);
    
        % Updating label
        txt = {
            sprintf('%s', gridName), ...
            sprintf('X: %.2f', pos(1)), ...
            sprintf('Y: %.2f', pos(2)), ...
            sprintf('y/FSL: %.4f', round(y_FSL,2)), ...
            sprintf('Displacement: %.4f m', round(displacement,2))
        };
    
        if ~isnan(r_distance)
            txt{end+1} = sprintf('r_0: %.4f km', r_distance);
        end

    end


dcm = datacursormode(fig);
set(dcm, 'UpdateFcn', @display_curve);


    function save_curve()
        % Find data within the workspace
        data_to_save = evalin('base', 'selected_curve_data');
        gridName = evalin('base', 'selected_grid_name');
        pos = evalin('base', 'selected_position');
        folderPath = evalin('base', 'folderPath'); 

        if ~exist(folderPath, 'dir')
            mkdir(folderPath);
        end

        filename_txt = fullfile(folderPath, sprintf('HazardCurve_%s_X%.3f_Y%.3f.txt', gridName, pos(1), pos(2)));

        % save HC as txt file
        try
            writematrix(data_to_save, filename_txt, 'Delimiter', '\t');
            fprintf('File saved in: %s\n', filename_txt);
        catch ME
            warning('Error while saving the file: %s', ME.message);
        end

    end


end