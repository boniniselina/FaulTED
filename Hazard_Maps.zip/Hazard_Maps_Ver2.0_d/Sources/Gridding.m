%% %%%%%%%%%%%%%%%%%% Create grids from shapefiles %%%%%%%%%%%%%%%%%% %%
% this codes create a grid of points, resample the PF and assign to each
% point of the grid x/l and distance. Distance is positive for hangingwall
% and negative for footwall.
%%


function [PF_length, grid_PF, grid_DR_FW, grid_DR_HW] = Gridding(step, long_range, lat_range, max_dist, input_shapefile, Strike)

%% 1. Grid information
% step = 0.001; % passo della griglia in termini di gradi lat e lon
% max_dist = 2500; % Lunghezza massima per estensione in metri
% pf = shaperead(input_shapefile); %'Segmento_EW_Martani.shp');
pf = shaperead(input_shapefile);
% pf = input_shapefile;
x = long_range(1):step:long_range(2);% intervallo di long nel quale viene realizzata la griglia
y = lat_range(1):step:lat_range(2);% int


[X,Y] = meshgrid(x,y);
X = X(:);
Y = Y(:);

%% 2. Shapefile
% read the PF shapefile

xpf_orig = [pf.X]';
ypf_orig = [pf.Y]';
xpf_orig = flipud(xpf_orig);
ypf_orig = flipud(ypf_orig);
% 
xpf_orig = xpf_orig(~isnan(xpf_orig));
ypf_orig = ypf_orig(~isnan(ypf_orig));
% resampling
[ypf,xpf]=interpm(ypf_orig,xpf_orig,0.00005);


%%
% cumulative distance
% e = referenceEllipsoid(reference_ellipsoid);
% e = referenceEllipsoid('grs80');
e = referenceEllipsoid('wgs84');
for i = 1:(length(ypf)-1)
    [temp_dist(i), temp_az(i)] = distance(ypf(i),xpf(i),ypf(i+1),xpf(i+1),e);
end
cumdist = [0;cumsum(temp_dist)'];
PF_length = cumdist(end);
mean_azimuth = Strike;

%%

x_l = 0.005:0.005:1; % alla fine verranno riscalati tra 0 e 0.5
dist_x_l = PF_length.*x_l; % distance along the PF of the x/l points

clear i
for i = 1:length(dist_x_l)
    temp1 = abs(cumdist-dist_x_l(i));
    
    h(i) = find(temp1 <= min(temp1),1,'last');

end
x_l(x_l>0.5) = abs(1-x_l(x_l>0.5));

%%
% prendo 
% solo i punti della PF associabili a x_l
x_pf_xl = xpf(h);
y_pf_xl = ypf(h);

%% select point of the grid that are placed on hangingwall or footwall
% polygon for hangingwall or footwall
if mean_azimuth <180
polyHW = [x_pf_xl,y_pf_xl; x_pf_xl(end), min(Y); min(X),min(Y);...
min(X), y_pf_xl(1); x_pf_xl(1),y_pf_xl(1)];

polyFW = [x_pf_xl,y_pf_xl; max(X), y_pf_xl(end); max(X),max(Y);...
x_pf_xl(1), max(Y); x_pf_xl(1),y_pf_xl(1)];
else
polyFW = [x_pf_xl,y_pf_xl; min(X),y_pf_xl(end); min(X),min(Y);...
x_pf_xl(1), min(Y); x_pf_xl(1),y_pf_xl(1)];

polyHW = [x_pf_xl,y_pf_xl; x_pf_xl(end), max(Y);max(X),max(Y);...
    max(X), y_pf_xl(1);x_pf_xl(1),y_pf_xl(1)];
end  



ihw = find(inpolygon(X,Y,polyHW(:,1),polyHW(:,2)));
ifw = find(inpolygon(X,Y,polyFW(:,1),polyFW(:,2)));

xhw = X(ihw);
yhw = Y(ihw);

xfw = X(ifw);
yfw = Y(ifw);


%%

% [~, az_start] = distance(ypf(1), xpf(1), ypf(2), xpf(2), e);
% [~, az_end] = distance(ypf(end-1), xpf(end-1), ypf(end), xpf(end), e);
% 
% [ypf_ext_start, xpf_ext_start] = reckon(ypf(1), xpf(1), max_dist / 1000, az_start, e);
% [ypf_ext_end, xpf_ext_end] = reckon(ypf(end), xpf(end), max_dist / 1000, az_end, e);
% 
% 
% ypf_ext = [ypf_ext_start; ypf; ypf_ext_end];
% xpf_ext = [xpf_ext_start; xpf; xpf_ext_end];
% 
% 
% if mean_azimuth < 180
%     polyHW = [xpf_ext, ypf_ext; xpf_ext(end), min(Y); min(X), min(Y); ...
%               min(X), ypf_ext(1); xpf_ext(1), ypf_ext(1)];
%     polyFW = [xpf_ext, ypf_ext; max(X), ypf_ext(end); max(X), max(Y); ...
%               xpf_ext(1), max(Y); xpf_ext(1), ypf_ext(1)];
% else
%     polyFW = [xpf_ext, ypf_ext; min(X), ypf_ext(end); min(X), min(Y); ...
%               xpf_ext(1), min(Y); xpf_ext(1), ypf_ext(1)];
%     polyHW = [xpf_ext, ypf_ext; xpf_ext(end), max(Y); max(X), max(Y); ...
%               max(X), ypf_ext(1); xpf_ext(1), ypf_ext(1)];
% end
% 
% ihw = find(inpolygon(X, Y, polyHW(:,1), polyHW(:,2)));
% ifw = find(inpolygon(X, Y, polyFW(:,1), polyFW(:,2)));
% 
% xhw = X(ihw);
% yhw = Y(ihw);
% 
% xfw = X(ifw);
% yfw = Y(ifw);

%% Distance and x_l values are assigned 

clear i 
for i = 1 : length(xhw)
   [temp_p_r, temp_p_az] = distance(y_pf_xl,x_pf_xl,yhw(i),xhw(i),e); 
    p_r(i) = min(temp_p_r);
    % p_az(i) = temp_p_az (temp_p_r ==min(temp_p_r));
    % p_x_l(i) = x_l(temp_p_r == min(temp_p_r));

    [p_r(i), idx_min] = min(temp_p_r);      
    p_az(i) = temp_p_az(idx_min);           
    p_x_l(i) = x_l(idx_min);
end
dist_hw = p_r;
p_x_l_hw = p_x_l;
hw_in_distance = find(dist_hw<=max_dist(1));

clear i , clear p_r, clear p_x_l, clear p_az
for i = 1 : length(xfw)
   [temp_p_r, temp_p_az] = distance(y_pf_xl,x_pf_xl,yfw(i),xfw(i),e); 
    p_r(i) = min(temp_p_r);
    % p_az(i) = temp_p_az (temp_p_r ==min(temp_p_r));
    % p_x_l(i) = x_l(temp_p_r ==min(temp_p_r));
    [p_r(i), idx_min] = min(temp_p_r);      
    p_az(i) = temp_p_az(idx_min);           
    p_x_l(i) = x_l(idx_min);

end
dist_fw = -1* p_r;
p_x_l_fw = p_x_l;
fw_in_distance = find(dist_fw>=-max_dist(2));

%%
grid_PF = [x_pf_xl,y_pf_xl,x_l'];
% XL_site_PF=[grid_PF(:,3)];
% grid_PF=[x_pf_xl,y_pf_xl,XL_site_PF];
u=grid_PF(:,3)>0;
grid_PF=grid_PF(u,:);

grid_DR_HW = [xhw(hw_in_distance),yhw(hw_in_distance),round(dist_hw(hw_in_distance)')/1000,round(p_x_l_hw(hw_in_distance)',4)];
u_2=grid_DR_HW(:,4)>0;
grid_DR_HW=grid_DR_HW(u_2,:);

grid_DR_FW = [xfw(fw_in_distance),yfw(fw_in_distance),round(dist_fw(fw_in_distance)')/1000,round(p_x_l_fw(fw_in_distance)',4)];
u_3=grid_DR_FW(:,4)>0;
grid_DR_FW=grid_DR_FW(u_3,:);

% grid_DR_tot = [xhw(hw_in_distance),yhw(hw_in_distance),round(dist_hw(hw_in_distance)'),round(p_x_l_hw(hw_in_distance)',4);
%                xfw(fw_in_distance),yfw(fw_in_distance),round(dist_fw(fw_in_distance)'),round(p_x_l_fw(fw_in_distance)',4)];
% writetable(array2table(grid_DR_tot,'VariableName',{'lon','lat','dist','x/l'}),{[FaultName,'_grid_DR.txt']});  %Nome file output Distributed
% writetable(array2table(grid_PF,'VariableName',{'lon','lat','x/l'}), {[FaultName,'_grid_PF.txt']}); %Nome file output principal
% D_F2S=round(([grid_DR_tot(:,3)]./1000),2);
% XL_site=[grid_DR_tot(:,4)];
% 
% %grid DR HW
% k=D_F2S(:)>0 & XL_site(:)>0;
% grid_DR_HW=[xhw(k),yhw(k),D_F2S(k),XL_site(k)];
% clear k
% %grid DR FW
% k=D_F2S(:)<0 & XL_site(:)>0;
% grid_DR_FW=[xfw(k),yfw(k),D_F2S(k),XL_site(k)];
%%
% figure
% hold on
% plot(X,Y,'.')
% plot(xpf,ypf,'-r')
% scatter(x_pf_xl,y_pf_xl,8,x_l,'filled')
% plot(polyHW(:,1),polyHW(:,2),'-k')
% plot(polyFW(:,1),polyFW(:,2),'-r')
% colorbar
% axis square
% 
% 
% figure
% hold on
% plot(x_pf_xl,y_pf_xl,'-r')
% scatter(xhw,yhw,10,dist_hw,'filled','Marker','s')
% scatter(xfw,yfw,10,dist_fw,'filled','Marker','o')
% colorbar
% axis square
% 
% figure
% 
% hold on
% 
% scatter(xhw(hw_in_distance),yhw(hw_in_distance),10,p_x_l_hw(hw_in_distance),'filled','Marker','s')
% scatter(xfw(fw_in_distance),yfw(fw_in_distance),10,p_x_l_fw(fw_in_distance),'filled','Marker','o')
% plot(x_pf_xl,y_pf_xl,'-r','LineWidth',2)
% colorbar
% axis square
% daspect([1 1 1])

end