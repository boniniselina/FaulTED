%% Conditional Probability of Exceedence, Pkn(D>d|m,r,Slip) for Principal Faulting
% It is the second term of the attenuation law representing the
% conditional distribution of the amount of fault displacement given that
% slip occurs (P_exceedance)

% IMPORTANT: the evaluation of this probability is performed for all the
% x/L values from 0.005 to 0.5. Then, the code find within the complete
% matrix P_exceedance_full the curves calculated for the x/L_values in input.
% This because, in case of floating=1, the code can easily use this complete
% matrix to adjust the P_exceedance with respect to the x/L revaluated for
% each ruptures, whise length depend on the Mw.

%%                       'YEA03' - 'MEA22' - 'TEA13'
% The displacement is usually normalized by the maximum displacement (MD) or
% the average displacement (AD), measured for each rupture, and used to
% define a distribution for the ratio D/MD or D/AD. D/MD and D/AD are
% expressed as a function of the location of point j along the rupture
% (x/L), and it is symmetric about x/L = 0.5.

% If MD is chose, this data are fitted with a Beta distribution (for all the
% available models, only Moss et al. (2022) is an exception, as the model
% prefers to use a Gamma distribution to fit data), while if AD is chosen,
% this data are fitted with a Gamma distribution.

% The conditional Probability of Exceedance can be obtained by convolving
% this distribution with the lognormal distribution for MD or AD.

%%                                 'PEA11'
% Otherwise, Petersen et al. (2011) develop three models for this analysis:
%   (a) a bilinear model that allows for constant displacements near the
%       middle of the rupture and a linear taper at the ends of the rupture;
%   (b) a polynomial model that predicts slightly lower displacements at
%       the middle of the fault, consistent with asymmetric rupture models
%       where the displacements may be higher near the ends of the faults
%       as described in Wesnousky (2008);
%   (c) an elliptical model that curves at the end and is preferred by
%       Biasi and Weldon (2006).
% in general, the authors documented the three models for log(D) (PEA11_a,b,c)
% and log(D/AD) (PEA11_d,e,f - not yet implemented).
% In this model, they suggest that the displacement follow a lognormal
% distribution and the cdf is evaluated with a complementary error function.

function [p_Displ, P_exceedance_full, P_exceedance, warnings_Pexc] = Pexceedance(x_axis_displacement, displacement_levels, D_perc, Displ_type, d_ScR, P_D_model, Mcase, d_truncation, FaultName, folderPath, kinematicType, xL_value)

x_l = linspace(0.005, 0.5, 100);
warnings_Pexc = struct('id', {}, 'message', {}, 'values', {});

%%                       'YEA03' - 'MEA22' - 'TEA13'
%% 1) Definition of theoretical regressions and models
% Please, refer to Mw_AD_regressions.m and Mw_MD_regressions.m to check the
% scaling relationships between Mw and Displacement included in this code.
% The same is suggested for the available literature models usually used to
% fit data with a Gamma or a Beta distribution (D_AD_models.m and
% D_MD_models.m)

% find the chosen scaling relation and model
[D_Mw_scaling_rel, D_mw_Index, warnings_Pexc] = getScalingCoefficients(d_ScR, Displ_type, kinematicType, warnings_Pexc);

%% 2) Calculation of the log-normal distribution to fit the chosen
%%    scaling relation between Mw and Maximum or Average Displacement
%%    and evaluation of the corresponding P(D|MD) pr P(D|AD)

% Chosen Scaling relation
d_ScR_Coeffs = D_Mw_scaling_rel(D_mw_Index).coefficients;
D_relation = d_ScR_Coeffs(1) + d_ScR_Coeffs(2).*Mcase;
d_ScR_Sigma = D_Mw_scaling_rel(D_mw_Index).sigma;

% P(D|MD) or P(D|AD)
for i = 1:length(Mcase)
    if ~isempty(d_truncation) && ~isnan(d_truncation)
        pd (i) = makedist('Normal','mu',D_relation(i),'sigma',d_ScR_Sigma);
        pd_trunc (i)= truncate(pd(i),(D_relation(i))-(d_truncation*d_ScR_Sigma),(D_relation(i))+(d_truncation*d_ScR_Sigma));
        p_Displ(i,:) = pdf(pd_trunc(i),log10(x_axis_displacement));
        p_Displ(i,:) = p_Displ(i,:)./sum(p_Displ(i,:));
    else
        p_Displ(i,:) = pdf("normal",log10(x_axis_displacement),D_relation(i),d_ScR_Sigma);
        p_Displ(i,:) = p_Displ(i,:)./sum(p_Displ(i,:));
    end
end

if any(strcmp(P_D_model, {'YEA03', 'MEA22', 'TEA13'}))
    [D_models, D_model_Index, warnings_Pexc] = getModelCoefficients(P_D_model, Displ_type, warnings_Pexc, kinematicType);
    for i = 1:length(x_l)
        % a, b parameters and function of the chosen model
        a_gamma = D_models(D_model_Index).a(x_l(i));
        b_gamma = D_models(D_model_Index).b(x_l(i));
        chosen_function = D_models(D_model_Index).function;
        scenario(i, :) = cdf(chosen_function, D_perc, a_gamma, b_gamma);
    end


    %% 3) Evaluation of the Conditional Probability of Exceedance
    n=1; P2 = []; P3 = []; P_exceedance_full = [];

    for m = 1: size(p_Displ,1) % M
        for g = 1:size(scenario,1) % x/l

            for i =1:length(p_Displ(m,:)) % probability of having a specific AD value as function of M
                D_assoluto =  x_axis_displacement(i) .* D_perc;

                for h = 1:length(displacement_levels)
                    P_non_exceedance = find(D_assoluto < displacement_levels(h),1,"last"); % Explore the Probability of Non-Exceedance
                    if isempty(P_non_exceedance)
                        P_non_exceedance=1;
                    end

                    P2(i,h) =  (1-scenario(g,P_non_exceedance)); % P of exceedance = 1 - P non-exceedance

                end
                P3(i,:) = p_Displ(m,i) .* P2(i,:);
            end

            P_exceedance_full(n,:) = sum(P3,1); % the first 100 rows
            % (corresponding to the 100 values ​​of x/L) refer to the first magnitude
            % of Mcase, the second 100 to the second value of Mcase etc., while the
            % number of columns depends on the length of displacement_levels

            n=n+1;
        end
    end


    %%                                   'PEA11'
elseif any(strcmp(P_D_model, {'PEA11_a', 'PEA11_b', 'PEA11_c'}))

    if ~strcmp(kinematicType, 'SS')
        warning_id = 'MATLAB:InvalidKin';
        warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen P_D_model.');
        disp(warning_msg)
        warnings_Pexc(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', []);
    end

    % Displacement models log(D)
    % Displacement distribution along the PF
    for m = 1:length(Mcase)
        for j = 1:length(x_l)
            if strcmp(P_D_model, "PEA11_a") == 1  % Bilinear
                xl_d = 1 / 8.5206 * ((1.7658 - 1.7969) * Mcase(m) + (-7.8962 + 10.2855));
                chosen_function = 'Bilinear';
                if x_l(j) >= xl_d
                    scenario(m,j) = log((exp(1.7658 * Mcase(m) - 7.8962))/100);  % Eq. 8
                    sigma = 0.9624;
                else
                    scenario(m,j) = log((exp(1.7969 * Mcase(m) + 8.5206 * x_l(j) - 10.2855))/100);  % Eq. 7
                    sigma = 1.2906;
                end
            elseif strcmp(P_D_model, "PEA11_b") == 1  % Quadratic
                scenario(m,j) = log((exp(1.7895 * Mcase(m) + 14.4697 * x_l(j) - 20.1723 * x_l(j)^2 - 10.5451))/100);  % Eq. 10
                sigma = 1.1346;
                chosen_function = 'Quadratic';
            elseif strcmp(P_D_model, "PEA11_c") == 1  % Elliptical
                x_star = sqrt(1 - (1 / 0.5^2) * (x_l(j) - 0.5)^2);  % Eq. 12
                scenario(m,j) = log((exp(3.3041 * x_star + 1.7927 * Mcase(m) - 11.2192))/100);  % Eq. 13
                sigma = 1.1348;
                chosen_function = 'Elliptical';
            end
        end
    end

    % Conditional probability of exceedance
    P_exceedance_full=zeros(length(Mcase)*length(x_l), length(displacement_levels));
    n=1;
    for m = 1:length(Mcase)
        for j = 1:length(x_l)
            for i = 1:length(displacement_levels)
                temp1 = (scenario(m, j) - log(displacement_levels(i))) /(sigma* sqrt(2)); % PDF
                P_exceedance_full(n, i) = (erf(temp1) + 1) / 2; % CDF

            end
            n=n+1;
        end
    end


    % Normalized displacement models log(A/AD) - not yet implemented

end



%% Site-specific Conditional Probability of exceedance
% find within the complete matrix the curves corresponding to xL_value
indices_xL = arrayfun(@(xl_val) find(abs(x_l - xl_val) == min(abs(x_l - xl_val)), 1), xL_value);

P_exceedance = zeros(length(Mcase)*length(xL_value), length(displacement_levels));
n=1;

for m = 1:length(Mcase)
    % row range for the current Mcase
    row_start = (m - 1) * length(x_l) + 1;
    row_end = m * length(x_l);
    P_block = P_exceedance_full(row_start:row_end, :);

    for k = 1:length(xL_value)
        P_exceedance(n, :) = P_block(indices_xL(k), :);
        n=n+1;
    end
end

%% Figures
if any(strcmp(P_D_model, {'YEA03', 'MEA22', 'TEA13'}))

    for i = 1:size(scenario,1)
        pos1(i) = find(scenario(i,:)>=0.05,1,"first");
        pos2(i) = find(scenario(i,:)>=0.15,1,"first");
        pos3(i) = find(scenario(i,:)>=0.5,1,"first");
        pos4(i) = find(scenario(i,:)>=0.85,1,"first");
        pos5(i) = find(scenario(i,:)>=0.95,1,"first");
        D_per_xL(:,i) = [D_perc(pos1(i));D_perc(pos2(i));D_perc(pos3(i));D_perc(pos4(i));D_perc(pos5(i))];
    end

    for mm = 1:length(Mcase)
        % 50° percentile, D/AD (D/MD) * AD (MD) to find D along x/L
        D_xL_profile(mm,:) = D_per_xL(3,:) .* 10.^(D_relation(mm));
    end

    figure()
    hold on
    plot(x_l, D_xL_profile', 'k-', 'LineWidth', 1.5);
    plot(1-x_l, D_xL_profile', 'k-', 'LineWidth', 1.5);


else % Petersen et al (2011)
    D_xL_profile = exp(scenario);
    figure()
    hold on
    plot(x_l, D_xL_profile', 'k-', 'LineWidth', 1.5);
    plot(1-x_l, D_xL_profile', 'k-', 'LineWidth', 1.5);
end

xlabel('x/L')
ylabel('D (m)')
title('50° percentile')
hold off

saveas(gcf, fullfile(folderPath, ['D_xL_Distribution' FaultName '.fig']));




figure()
hold on
plot(displacement_levels, P_exceedance')

ylim([0.001 1])
set(gca,'YScale','lin','XScale','log')
grid on
xlabel('Displacement (m)')
ylabel('P (D>d)')

saveas(gcf, fullfile(folderPath, ['Conditional_Probability_Exceedence' FaultName '.fig']));


%%
    function [D_Mw_scaling_rel, D_mw_Index, warnings_Pexc] = getScalingCoefficients(d_ScR, Displ_type, kinematicType, warnings_Pexc)
        
        if Displ_type == 1 % If AD
            D_Mw_scaling_rel = Mw_AD_regressions();
        else % If MD
            D_Mw_scaling_rel = Mw_MD_regressions();
        end

        D_mw_Index = [];

        for y = 1:length(D_Mw_scaling_rel)
            if strcmp(D_Mw_scaling_rel(y).name, d_ScR)
                D_mw_Index = y;
                if ~contains(D_Mw_scaling_rel(y).kinematics, kinematicType) & ~strcmp(D_Mw_scaling_rel(y).kinematics, 'All')
                    warning_id = 'MATLAB:InvalidKin';
                    warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen d_ScR.');
                    disp(warning_msg)
                    warnings_Pexc(end+1) = struct('id', warning_id, ...
                        'message', warning_msg, ...
                        'values', []);
                end
                return;
            end
        end

        if isempty(D_mw_Index)
            error('Model not found. Please, insert a valid name for the (D-Mw) scaling relation');
        else
            
        end

    end

    function [D_models, D_model_Index, warnings_Pexc] = getModelCoefficients(P_D_model, Displ_type, warnings_Pexc, kinematicType)
        if Displ_type == 1 % If AD
            D_models = D_AD_models();
        elseif Displ_type == 2 % If MD
            D_models = D_MD_models();
        end

        D_model_Index = [];

        for y = 1:length(D_models)
            if strcmp(D_models(y).name, P_D_model)
                D_model_Index = y;
                if ~contains(D_models(y).kinematics, kinematicType)
                    warning_id = 'MATLAB:InvalidKin';
                    warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen P_D_model.');
                    disp(warning_msg)
                    warnings_Pexc(end+1) = struct('id', warning_id, ...
                        'message', warning_msg, ...
                        'values', []);
                end

                return;
            end
        end

        if isempty(D_model_Index)
            error('Model not found. Please, insert a valid name for the model to fit displacement data');
        else
        end
    end

%%

end




