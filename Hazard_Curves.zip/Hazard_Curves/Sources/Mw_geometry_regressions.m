%% Available scaling relations between Mw and geometric fault parameters 
%% Rupture Length at Depth (RLD), Area (RA)

% Here we define a structure including all the scaling relations available
% in the scientific literature specifically between Mw (or Moment) and fault 
% source geometric parameters

% The main authors are listed below, while the corresponding model number 
% is reported within ():

%% Wells & Coppersmith (1994) - WC94
% the authors provide regressions not only for single kinematics type: 
% normal (1), reverse (2) and strike-slip faults (3); but also for the 
% whole datasets (All Slip Type, 4). - Mw 

% General setting of the structure:
%%% 1) Name of the Scaling relation
%%% 2) Kinematics
%%% 3) coefficients [aRLD, bRLD, aRA, bRA]
%%% 4) standard deviation [sdRLD, sdRA]
%%% 5) magnitude range [Mmin_RLD Mmax_RLD, Mmin_RA, Mmax_RA]

%% Leonard (2010) - L10
% the author provide self-consistent fault scaling relations for dip slip
% (normal and reverse - 5) and strike-slip (6) faults and for faults
% developed in stable continental regions (SCR - 7). - M_0
% See Table 5 

% General setting of the structure:
%%% 1) Name of the Scaling relation
%%% 2) Kinematics
%%% 3) coefficients [aRLD, bRLDmin, bRLDmax, aRA, bRAmin, bRAmax]
%%%         for SS: [aRLD, bRLDmin, bRLDmax, aRA, bRAmin, bRAmax]
%%% 4) standard deviation [empty]
%%% 5) Size range for DS [min_RLD, min_RA]
%%%       for SS: [min_RLD, max_RLD, min_RA, max_RA]
%         for SCR: [min_RLD, max_RLD, min_RA, max_RA] 
%      in m^2

%% Thingbaijam et al. (2017) - T17
% the authors provide regressions for the 3 kinematics: normal (8), reverse
% (9), strike-slip (10). - Mw

% General setting of the structure:
%%% 1) Name of the Scaling relation
%%% 2) Kinematics
%%% 3) coefficients [aRLD, bRLD, aRA, bRA]
%%% 4) standard deviation [sdRLD, sdRA]
%%% 5) magnitude range [Mmin_RLD Mmax_RLD, Mmin_RA, Mmax_RA]

%% Pace et al. 2002 (BGTA) - Pea02
% The authors suggest coefficient related to fault aspect ratio (AS - 11)
% Following the approach used in the FiSH code, these coefficients are 
% ALWAYS used for computing Magnitudes

% General setting of the structure:
%%% 1) Name of the Scaling relation
%%% 2) Kinematics
%%% 3) coefficients [aAS, bAS]
%       first row for Normal
%       second for Reverse
%       third for Strike-Slip
%       fourth for All Dip type
%%% 4) standard deviation [sdAS]
%%% 5) magnitude range [empty]

%%

function Mag_geom_scaling_rel = Mw_geometry_regressions()
Mag_geom_scaling_rel = struct(); % initializing the structure 

%% Wells & Coppersmith (1994)

Mag_geom_scaling_rel(1).name = 'WC94-N';
Mag_geom_scaling_rel(1).kinematics = 'N';
Mag_geom_scaling_rel(1).coefficients = [4.34, 1.54, 3.93, 1.02]; % a and b for RLD, and RA]
Mag_geom_scaling_rel(1).sigma = [0.31, 0.25]; % standard deviation for RLD, and RA
Mag_geom_scaling_rel(1).range = [5.2, 7.3, 5.2, 7.3]; % Mmin, Mmax for RLD, and RA 

Mag_geom_scaling_rel(2).name = 'WC94-R';
Mag_geom_scaling_rel(2).kinematics = 'R';
Mag_geom_scaling_rel(2).coefficients = [4.49, 1.49, 4.33, 0.90];
Mag_geom_scaling_rel(2).sigma = [0.26, 0.25];
Mag_geom_scaling_rel(2).range = [4.8, 7.6, 4.8, 7.6];

Mag_geom_scaling_rel(3).name = 'WC94-S';
Mag_geom_scaling_rel(3).kinematics = 'SS';
Mag_geom_scaling_rel(3).coefficients = [4.33, 1.49, 3.98, 1.02];
Mag_geom_scaling_rel(3).sigma = [0.24, 0.23];
Mag_geom_scaling_rel(3).range = [4.8, 8.1, 4.8, 7.9];

Mag_geom_scaling_rel(4).name = 'WC94-A';
Mag_geom_scaling_rel(4).kinematics = 'All';
Mag_geom_scaling_rel(4).coefficients = [4.38, 1.49, 4.07, 0.98];
Mag_geom_scaling_rel(4).sigma = [0.26, 0.24];
Mag_geom_scaling_rel(4).range = [4.8, 8.1, 4.8, 7.9];

%% Leonard (2010)

Mag_geom_scaling_rel(5).name = 'L10-D'; 
Mag_geom_scaling_rel(5).kinematics = 'N-R';
Mag_geom_scaling_rel(5).coefficients = [2.5, 7.53, 8.51, 1.5, 5.69, 6.6];
Mag_geom_scaling_rel(5).sigma = NaN;
Mag_geom_scaling_rel(5).range = [5500, 0, 5500]; % > Mmin (lower boundary)

Mag_geom_scaling_rel(6).name = 'L10-S';
Mag_geom_scaling_rel(6).kinematics = 'SS';
Mag_geom_scaling_rel(6).coefficients = [1.5, 12.01, 12.88, 1.5, 5.69, 6.47, 2.27, 9.15, 1, 15.26];
Mag_geom_scaling_rel(6).sigma = NaN;
Mag_geom_scaling_rel(6).range = [45000, NaN, 0, NaN, 3400, 65000, 65000, NaN]; % m^2

Mag_geom_scaling_rel(7).name = 'L-SCR';
Mag_geom_scaling_rel(7).kinematics = 'SCR'; 
Mag_geom_scaling_rel(7).coefficients = [2.5, 7.87, 8.28, 1.5, 6.22, 6.52, 2.5, 8.08, NaN];
Mag_geom_scaling_rel(7).sigma = NaN;
Mag_geom_scaling_rel(7).range = [2500, NaN, 0, NaN, NaN, NaN, NaN, NaN];

%% Thingbaijam et al. (2017)

Mag_geom_scaling_rel(8).name = 'T17-N';
Mag_geom_scaling_rel(8).kinematics = 'N';
Mag_geom_scaling_rel(8).coefficients = [3.5505, 2.0619, 3.1572, 1.2376]; % a and b for RLD and RA
Mag_geom_scaling_rel(8).sigma = [0.128, 0.181];
Mag_geom_scaling_rel(8).range = [5.86, 8.39];

Mag_geom_scaling_rel(9).name = 'T17-R';
Mag_geom_scaling_rel(9).kinematics = 'R';
Mag_geom_scaling_rel(9).coefficients = [4.3860, 1.6287, 4.1582, 0.9533];
Mag_geom_scaling_rel(9).sigma = [0.083, 0.121];
Mag_geom_scaling_rel(9).range = [5.59, 7.69];

Mag_geom_scaling_rel(10).name = 'T17-S';
Mag_geom_scaling_rel(10).kinematics = 'SS';
Mag_geom_scaling_rel(10).coefficients = [4.3216, 1.4684, 3.7006, 1.0616];
Mag_geom_scaling_rel(10).sigma = [0.151, 0.184];
Mag_geom_scaling_rel(10).range = [5.38, 8.70];

%% Pace et al. (2002)

Mag_geom_scaling_rel(11).name = 'Pea02';
Mag_geom_scaling_rel(11).kinematics = [];
Mag_geom_scaling_rel(11).coefficients = [3.0939,  1.2501; % Normal
                                        -4.4543, 2.1992;  % Reverse
                                        -7.096,  2.9807;  % Strike-Slip
                                        -2.3725, 1.9354]; % All Dip
Mag_geom_scaling_rel(11).sigma = 0.25;
Mag_geom_scaling_rel(11).range = NaN;

end