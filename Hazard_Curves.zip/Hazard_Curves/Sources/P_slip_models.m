%% Conditional Probability of Surface Rupture given a magnitude m
%% Empirical models

% The models are here organized in a structure as follow:
% -------------------------------------------------------------------
                                                    % a            b
% ALL SLIP TYPES
%   [1] Wells & Coppersmith (1993)
%         276 worldwide earthq.                   -12.51        2.053
%   [2] Pizza et al. (2023)                                    
%         363 All type                            -14.47        2.177
% NORMAL FAULTS
%  [3-5] Youngs et al. (2003), based on Pezzopane & Dawson (1996)
%         32 Great Basin earthq.                  -16.02        2.685 
%         47 Northern Basin and Range earthq.     -18.71        3.041
%         105 Extensional Cordillera earthq.      -12.53        1.921
%  [6] Pizza et al. (2023)      
%         60 Normal                               -13.50        2.159 
% STRIKE-SLIP FAULTS  
%   [7] Pizza et al. (2023)      
%         139 Strike-Slip                         -28.56        4.436       
%   [8] Takao (2013)
%         107 R&SS Japanese earthq.               -32.03        4.900  
%  [9-10] Moss et al. (2013) - Strike-Slip
%         Soft soil (Vs30<600m/s)               -12.2908       1.9520
%         Stiff soil/rock (Vs30>600m/s)         -11.4071       1.8465
% REVERSE FAULTS
%   [11] Pizza et al. (2023)      
%         119 Reverse                             -10.75        1.427
%   [12] Yang et al. (2021)
%         Cratonic earthq. in Australia           -24.59          4  
%  [13-14] Moss et al. (2013) - Reverse
%         Soft soil (Vs30<600m/s)                -6.2548       0.8308
%         Stiff soil/rock (Vs30>600m/s)         -13.9745       2.1395


% -------------------------------------------------------------------

function Pslip_models = P_slip_models()

Pslip_models = struct();

Pslip_models(1).name = 'WC93';
Pslip_models(1).coefficients = [-12.51 2.053];
Pslip_models(1).range = [5.0, 8.2];
Pslip_models(1).kinematics = 'All';
Pslip_models(1).color = 'k'; 
Pslip_models(1).style = '--'; 

Pslip_models(2).name = 'PZA23-A';
Pslip_models(2).coefficients = [-14.47 2.177];
Pslip_models(2).range = [5.5, 7.9];
Pslip_models(2).kinematics = 'All';
Pslip_models(2).color = 'k'; 
Pslip_models(2).style = ':'; 

Pslip_models(3).name = 'YEA03_a';
Pslip_models(3).coefficients = [-16.02 2.685];
Pslip_models(3).range = [4.5, 7.6];
Pslip_models(3).kinematics = 'N';
Pslip_models(3).color = 'r'; 
Pslip_models(3).style = '-'; 

Pslip_models(4).name = 'YEA03_b';
Pslip_models(4).coefficients = [-18.71 3.041];
Pslip_models(4).range = [4.5, 7.6];
Pslip_models(4).kinematics = 'N';
Pslip_models(4).color = 'r'; 
Pslip_models(4).style = '--'; 

Pslip_models(5).name = 'YEA03_c';
Pslip_models(5).coefficients = [-12.53 1.921];
Pslip_models(5).range = [4.5, 7.6];
Pslip_models(5).kinematics = 'N';
Pslip_models(5).color = 'r'; 
Pslip_models(5).style = '-.'; 

Pslip_models(6).name = 'PZA23-N';
Pslip_models(6).coefficients = [-13.50 2.159];
Pslip_models(6).range = [5.5, 7.1];
Pslip_models(6).kinematics = 'N';
Pslip_models(6).color = 'r'; 
Pslip_models(6).style = ':'; 

Pslip_models(7).name = 'PZA23-S';
Pslip_models(7).coefficients = [-28.56 4.436];
Pslip_models(7).range = [5.5, 7.8];
Pslip_models(7).kinematics = 'SS';
Pslip_models(7).color = [1, 0.5, 0]; % orange
Pslip_models(7).style = '-'; 

Pslip_models(8).name = 'TEA13';
Pslip_models(8).coefficients = [-32.03 4.900];
Pslip_models(8).range = [5.7, 7.4];
Pslip_models(8).kinematics = 'R-SS';
Pslip_models(8).color = 'g'; 
Pslip_models(8).style = '--'; 

Pslip_models(9).name = 'MEA13-S_a';
Pslip_models(9).coefficients = [-12.2908 1.9520];
Pslip_models(9).range = [4.2, 8.5];
Pslip_models(9).kinematics = 'SS';
Pslip_models(9).color = [0.97, 0.73, 0.24]; % light orange; 
Pslip_models(9).style = '--'; 

Pslip_models(10).name = 'MEA13-S_b';
Pslip_models(10).coefficients = [-11.4071 1.8465];
Pslip_models(10).range = [4.8, 8.0];
Pslip_models(10).kinematics = 'SS';
Pslip_models(10).color = [0.85, 0.73, 0.5]; % sandy yellow; 
Pslip_models(10).style = '-.'; 

Pslip_models(11).name = 'PZA23-R';
Pslip_models(11).coefficients = [-10.75 1.427];
Pslip_models(11).range = [5.5, 7.9];
Pslip_models(11).kinematics = 'R';
Pslip_models(11).color = 'b'; 
Pslip_models(11).style = '--'; 

Pslip_models(12).name = 'YAN21';
Pslip_models(12).coefficients = [-24.59 4];
Pslip_models(12).range = [4.7, 6.6];
Pslip_models(12).kinematics = 'R';
Pslip_models(12).color = 'c'; 
Pslip_models(12).style = '--'; 

Pslip_models(13).name = 'MEA13-R_a'; % soft soil
Pslip_models(13).coefficients = [-6.2548 0.8308];
Pslip_models(13).range = [4.2, 8.7];
Pslip_models(13).kinematics = 'R';
Pslip_models(13).color = 'b'; 
Pslip_models(13).style = '-.'; 

Pslip_models(14).name = 'MEA13-R_b'; % stiff soil/rock
Pslip_models(14).coefficients = [-13.9745 2.1395];
Pslip_models(14).range = [6.0, 8.0];
Pslip_models(14).kinematics = 'R';
Pslip_models(14).color = 'b'; 
Pslip_models(14).style = ':'; 

end