%% Available scaling relations between Mw and rupture length at the surface (SRL)

% Here we define a structure including the scaling relations available
% in the scientific literature specifically between Mw (or Seismic Moment, M0) 
% and SRL, generally evaluated with the following equation:
                            % log(SRL) = a+b*Mw
                          % log(SRL) = a+b*log(M0) for (Leonard 2014)
% The main authors are listed below, while the corresponding model number 
% is reported within ():

%% Wells & Coppersmith (1994) - WC94
% the authors provide regressions not only for single kinematics type: 
% normal (1), reverse (2) and strike-slip faults (3); but also for the 
% whole datasets (All Slip Type, 4). - Mw 

% General setting of the structure:
%%% 1) Name of the Scaling relation
%%% 2) Kinematics
%%% 3) coefficients [a, b]
%%% 4) standard deviation 
%%% 5) magnitude range [Mmin, Mmax]

%% Leonard (2014) - L14
% the author provide self-consistent fault scaling relations for dip slip
% (normal and reverse - 5) and strike-slip (6-7) faults. - M_0

% General setting of the structure:
%%% 1) Name of the Scaling relation
%%% 2) Kinematics
%%% 3) coefficients [a, b]
%%% 4) standard deviation [empty]
%%% 5) Size range for DS [min, max] 
%%%       for SS: [min, max] (3400 - 65000)
%         for SS: [min, max]  (>65000)
%      in m^2

%% Lavrentiadis et a. (2022)? - not yet implemented 
% DS --> log10(SRL) = c0 + c1*X1 + c2 + ϵSRL
% SS --> log10(SRL) = c0 + c1*X1 + ϵSRL
% where X1 = M−min(β1 +β2*M,log10(Wlim))

%%
function srl_Mw_scaling_rel = Mw_srl_regressions()
srl_Mw_scaling_rel = struct(); % initializing the structure for Mw-SRL scaling relations

%% Wells & Coppersmith (1994)

srl_Mw_scaling_rel(1).name = 'WC94-N';
srl_Mw_scaling_rel(1).kinematics = 'N';
srl_Mw_scaling_rel(1).coefficients = [-2.01, 0.5]; 
srl_Mw_scaling_rel(1).sigma = 0.21;
srl_Mw_scaling_rel(1).range = [5.2, 7.3];

srl_Mw_scaling_rel(2).name = 'WC94-R'; 
srl_Mw_scaling_rel(2).kinematics = 'R';
srl_Mw_scaling_rel(2).coefficients = [-2.86, 0.63];
srl_Mw_scaling_rel(2).sigma = 0.20;
srl_Mw_scaling_rel(2).range = [5.4, 7.4];

srl_Mw_scaling_rel(3).name = 'WC94-S';
srl_Mw_scaling_rel(3).kinematics = 'SS';
srl_Mw_scaling_rel(3).coefficients = [-3.55, 0.74];
srl_Mw_scaling_rel(3).sigma = 0.23;
srl_Mw_scaling_rel(3).range = [5.6, 8.1];

srl_Mw_scaling_rel(4).name = 'WC94-A';
srl_Mw_scaling_rel(4).kinematics = 'All';
srl_Mw_scaling_rel(4).coefficients = [-3.22, 0.69]; 
srl_Mw_scaling_rel(4).sigma = 0.22;
srl_Mw_scaling_rel(4).range = [5.2, 8.1];

%% Leonard (2014)

srl_Mw_scaling_rel(5).name = 'L14-D';
srl_Mw_scaling_rel(5).kinematics = 'N-R';
srl_Mw_scaling_rel(5).coefficients = [9.25, 2.27];
srl_Mw_scaling_rel(5).sigma = 0.15;
srl_Mw_scaling_rel(5).range = [5500, NaN]; 

srl_Mw_scaling_rel(6).name = 'L14-S';
srl_Mw_scaling_rel(6).kinematics = 'SS';
srl_Mw_scaling_rel(6).coefficients = [9.15, 2.27];
srl_Mw_scaling_rel(6).sigma = 0.15;
srl_Mw_scaling_rel(6).range = [3400, 65000];

srl_Mw_scaling_rel(7).name = 'L14-S';
srl_Mw_scaling_rel(7).kinematics = 'SS';
srl_Mw_scaling_rel(7).coefficients = [12.86, 1.5];
srl_Mw_scaling_rel(7).sigma = 0.15;
srl_Mw_scaling_rel(7).range = [65000, NaN];


end