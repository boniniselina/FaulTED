%%   P R O B A B I L I S T I C   F A U L T   D I S P L A C E M E N T    %%
%%                     H A Z A R D   A N A L Y S I S                    %%
%%                          earthquake approach                         %%

% This code was written by Bonini S. in France at the ‘Institut de
% Radioprotection et Sûreté Nucléaire’ for the 6 month’s period of
% her PhD project entitled “Parameters for assessing active faulting
% and related surface effects in railway design”.

%% MAIN CODE TO GENERATE HAZARD CURVES

clear all; close all; clc;
addpath('./Sources'); addpath('./Input'); addpath('./Output');

%% USER INPUTS
% All the input information are organized in a json file (see structure
% model)
jsonFile = 'Model1_pea11.json';
jsonText = fileread(jsonFile);
data = jsondecode(jsonText);

%%
% SAVE Outputs
mainDir = fileparts(mfilename('fullpath')); % Main directory
outputDir = fullfile(mainDir, 'Output');    % Output folder

baseFolderName = 'Project';
folderPath = fullfile(outputDir, baseFolderName);

counter = 1;
while exist(folderPath, 'dir')
    folderPath = fullfile(outputDir, sprintf('%s(%d)', baseFolderName, counter));
    counter = counter + 1;
end
mkdir(folderPath);


% Copy the input file to the project folder
inputFilePath = fullfile(mainDir, 'Input', jsonFile); % original path
outputFilePath = fullfile(folderPath, jsonFile); % new path
copyfile(inputFilePath, outputFilePath);

%%

% Extracting Input data for each Fault ID
Fault_IDs = fieldnames(data);

for faultIdx = 1:numel(Fault_IDs)
    current_Fault_ID = Fault_IDs{faultIdx};
    faultData = data.(current_Fault_ID);
    subFields = fieldnames(faultData);
    for j = 1:numel(subFields)
        categoryName = subFields{j}; % Eg. 'Fault_parameters', 'Fault_activity', ...
        categoryData = faultData.(categoryName);
        subCategoryFields = fieldnames(categoryData);
        for k = 1:numel(subCategoryFields)
            varName = subCategoryFields{k};
            varValue = categoryData.(varName);
            assignin('base', varName, varValue);
        end
    end

    xL_value = y_FSL_value;
    Dist_value = r0_value;
    Dist_riv = [];

    %% Set the variables for Figures

    magnitudes = 4:0.1:8.5;
    D_perc = logspace(log10(0.001),log10(10),1000); % Percentage used to explore displacement levels for the Conditional Probability of Exceedance
    x_axis_displacement = logspace(log10(0.001),log10(10),100); % in m
    displacement_levels = logspace(log10(0.001),log10(10),50); % in m

    colors = 'krbgy'; % Distance
    line_styles = {'-', '--', '-.', ':'}; % y/FSL

    if ~isempty(Recurrence_time) || ~isnan(Recurrence_time)
        AFOE_fixed = 1./Recurrence_time;
    end


    %% Rates
    if isempty(Input_Mw) | all(isnan(Input_Mw)) & isempty(Input_probability) | all(isnan(Input_probability))
        [Mcase, Mmax, sigma_Mmax, Width, Tmean, rates, MFD, M_0, MomentRate, Telap, yfc, warnings_Mw_geo_ScR, warnings_rates] = rates_computing(FaultName, kinematicType, m_ScR, Length, Width, Dip, Seismogenic_Thickness, SR_min, SR_max, ShearModulus, StrainDrop, bin, mag_truncation, fault_behavior, year_for_calculations, Last_eq_time, Mobs, Sd_Mobs, w, Mmin, b_value, Weighted, folderPath);
    elseif ~isempty(Input_Mw) && ~isnan(Input_Mw) && ~isempty(Input_probability) && ~isnan(Input_probability)
        Mcase = Input_Mw;
        rates = Input_probability;
        d=9.1; c=1.5;
        M_0 = 10.^((c.*Mcase)+d);
        if length(Mcase) ~= length(rates)
            error('Input_Mw and Input_probability must have the same size')
        end
        if ~isempty(Last_eq_time) && ~isnan(Last_eq_time)
            if isempty(year_for_calculations) || isnan(year_for_calculations)
                year_for_calculations=clock; yfc=year_for_calculations(1);
            else
                yfc=year_for_calculations;
            end
            Telap = yfc - Last_eq_time;
        else
            Telap = []; yfc= [];
        end
        Mmax = max(Mcase); sigma_Mmax = []; Tmean = round((1/((SR_max+SR_min)/2))*1000,0);
        MomentRate = []; MFD = []; warnings_Mw_geo_ScR = []; warnings_rates = [];
    else
        error('Please, insert both Input_Mw and Input_probability for the custumized scenario')
    end
    %% %%%%%%%%%%%%%%%%%%%%%% PRINCIPAL RUPTURES %%%%%%%%%%%%%%%%%%%%%% %%

    %% Evaluation of the Displacement Attenuation Law - PRINCIPAL FAULTING
    %% First Term:
    %%% Conditional probability of slip, Pkn(Slip|m,r) %%%

    % Numerical Model from Mammarella et al. (2024)
    if strcmp(P_slip_m, "MAEA24")
        [P_case] = CPSR(Input_MAEA24, Mcase, FaultName, folderPath);
        P_slip_coeff = [];
        model_range = [];
        warnings_Pslip = [];
    else
        % Empirical Models ("Classic" approach)
        [P_case, P_slip_coeff, model_range, warnings_Pslip] = PSlip(magnitudes, Mcase, P_slip_m, kinematicType, FaultName, folderPath);
    end

    %% Second Term:
    %%%% Conditional Probability of Exceedence, Pkn(D>d|m,r,Slip) %%%%
    displacement_labels = {'AD', 'MD'};
    [p_Displ, P_exceedance_full, P_exceedance, warnings_Pexc] = Pexceedance(x_axis_displacement, displacement_levels, D_perc, Displ_type, d_ScR, P_D_model, Mcase, d_truncation, FaultName, folderPath, kinematicType, xL_value);

    %% Floating Ruptures
    if floating == 1
        rates_old = rates;
        P_exceedance_old = P_exceedance;
        P_exceedance_tip = zeros(length(Mcase), size(P_exceedance_full, 2));
        num_xL = length(xL_value);

        for m_idx = 1:length(Mcase)
            row_idx = (m_idx - 1) * num_xL + 1;
            P_exceedance_tip(m_idx, :) = P_exceedance_full(row_idx, :);
        end
        if classic == 0
            [P_float, srl_case, rates_riv, x_over_L_riv, Dist_riv, dist_starting_point, dist_ending_point, warnings_Mw_srl] = Pfloating(kinematicType, srl_ScR, floating_bin, Length, xL_value, Mcase, M_0, displacement_levels, P_exceedance_full, Dist_value, rates, P_D_model, p_Displ, Displ_type, x_axis_displacement, D_perc,P_exceedance_old);
        else % We consider only ruptures at distance r_0
            [P_float, srl_case, rates_riv, x_over_L_riv, Dist_riv, dist_starting_point, dist_ending_point, warnings_Mw_srl] = Pfloating_classic(kinematicType, srl_ScR, floating_bin, Length, xL_value, Mcase, M_0, displacement_levels, P_exceedance_full, Dist_value, rates, P_D_model, p_Displ, Displ_type, x_axis_displacement, D_perc,P_exceedance_old);
        end
        P_exceedance = P_float;
        rates = rates_riv';
    else

        % The P_exceedance evaluated above is trasformed in a cell array, whose
        % size is compatible to P_float
        P_exceedance_old = P_exceedance;
        P_exceedance = cell(length(Mcase), length(xL_value));
        num_x_n = length(xL_value);
        for mag_idx = 1:length(Mcase)
            row_range = (1:num_x_n) + (mag_idx - 1) * num_x_n;
            for col_idx = 1:num_x_n
                P_exceedance{mag_idx, col_idx} = P_exceedance_old(row_range(col_idx), :);
            end
        end
        warnings_Mw_srl = [];
        srl_case = [];
        dist_starting_point = [];
        dist_ending_point = [];
        x_over_L_riv{length(Mcase)} = xL_value';
    end

    %% P2p from Takao et al. (2013)
    if P2p == 1
        % [P_2p,configurations,nf,Ll_cases,lp_tot,lp_p] = P2p_TEA(Length, Mcase, xL_value, FaultName, folderPath, magnitudes);
        [P_2p,P_3p,configurations,nf,Ll_cases,lp_tot,lp_p] = P2p_TEA(Length, Mcase, xL_value, FaultName, folderPath, magnitudes, displacement_levels, P_exceedance_full, Displ_type, x_axis_displacement, D_perc, p_Displ,P_D_model);
        if strcmp(P_D_model, 'TEA13')
            P_exceedance_old = P_exceedance;
            P_exceedance = P_3p;
        else
        end

    else
        P_2p = ones(length(Mcase), length(xL_value));
        configurations = []; nf= []; Ll_cases = [];
    end

    %% Vk(d) - PRINCIPAL FAULTING
    HC_PF_full = cell(length(Mcase), length(xL_value));
    HC_PF_sum = cell(length(Mcase), length(xL_value));
    for g = 1:length(Mcase) % Loop over each magnitude
        for a = 1:length(xL_value) % Loop over each xL_value
            n_combinations = size(P_exceedance{g, a}, 1); % Number of combinations
            for i = 1:n_combinations % Loop over all combinations
                P_slip_curr = P_case(g); % Scalar
                P_base = P_exceedance{g, a}(i, :); % [1x50]
                rate_value = rates(g); % Scalar
                P2p_curr = P_2p(g, a); % Scalar

                % Compute HC_PF_full for the current configuration
                HC_PF_full{g, a}(i, :) = rate_value .* P_slip_curr .* P_base .*  P2p_curr;
                if ~isempty(HC_PF_full{g, a})
                    % Sum along the n_combinations dimension (1st dimension)
                    % to include all the contributes coming from every combination
                    HC_PF_sum{g, a} = sum(HC_PF_full{g, a}, 1); % Resulting size: [1, length(Dist_value), 50]
                end
            end
        end
    end

    % Sum of all magnitude contributions:
    HC_PF_tot = cell(1, length(xL_value)); % One cell for each xL_value

    for a = 1:length(xL_value) % Loop over each xL_value
        % Initialize accumulator for the sum across Mcase
        total_sum = 0;

        for g = 1:length(Mcase) % Loop over each magnitude
            if ~isempty(HC_PF_sum{g, a})
                % Accumulate the sum across magnitudes
                total_sum = total_sum + squeeze(HC_PF_sum{g, a}); % [length(Dist_value), 50]
            end
        end

        % Store the aggregated result for this xL_value
        HC_PF_tot{a} = total_sum; % [length(Dist_value), 50]
    end


    % Hazard curves
    figure()
    hold on

    % plot only the total Hazard curves
    for i = 1:length(HC_PF_tot)
        HC_PF_current = HC_PF_tot{i};
        plot(displacement_levels, HC_PF_current, 'k',...
            'LineStyle', line_styles{i}, 'LineWidth', 1.5, ...
            'DisplayName', sprintf('y/FSL = %.1f', xL_value(i)));
        if ~isempty(Design_displ) && ~isnan(Design_displ)
            Ddesign_prob_PF(i) = interp1(displacement_levels, HC_PF_current, Design_displ);
            plot([1e-8 Design_displ Design_displ], [Ddesign_prob_PF(i) Ddesign_prob_PF(i) 1e-18], ...
                'LineStyle', ':', 'Color', [0.64 0.08 0.18], 'LineWidth', 1.5, ...
                'DisplayName', sprintf('D_{Design} = %.1f m', Design_displ))
            text_in_plot = sprintf('%.2e yr^-^1', Ddesign_prob_PF(i));
            text(0.004,  Ddesign_prob_PF(i), text_in_plot , 'VerticalAlignment', 'top', 'HorizontalAlignment', 'left', 'Color', 'k')
            Ddesign_recurrence(i) = 1./Ddesign_prob_PF(i);
        else
            Ddesign_prob_PF = [];
            Ddesign_recurrence = [];
        end

    end

    if ~isempty(AFOE_fixed) & ~isnan(AFOE_fixed)
        for i = 1:length(AFOE_fixed)
            loglog(displacement_levels, AFOE_fixed(i) * ones(size(displacement_levels)), ...
                'LineStyle', '--', 'LineWidth', 2, 'Color', [0.3010,0.7450,0.9330], ...
                'DisplayName', sprintf('T_R = %d yr', Recurrence_time));
            % text(110, AFOE_fixed(i), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left', 'Color', 'k');
        end
    end

    grid on
    axis square
    ylabel('Annual Frequency of Exceedance (yr^-^1)')
    xlabel('Displacement (m)')
    set(gca,'YScale','log','XScale','log')
    ylim([1E-8 1E-1])
    xlim([1E-3 1E1])
    legend('show')
    title(['Hazard Curves - ' FaultName])
    hold off

    saveas(gcf, fullfile(folderPath, ['Hazard_curve_PF_' FaultName '.fig']));


    %% Save PF Hazard Curves in Cell-array
    cellContent = cell(length(displacement_levels), length(xL_value));
    for j = 1:length(HC_PF_tot)
        HC_PF_current = HC_PF_tot{j};
        for i = 1:length(displacement_levels)
            cellContent{i, 1} = displacement_levels(i);
            cellContent{i, j+1} = HC_PF_current(i);
        end
    end
    Hazard_curves_PF{faultIdx} = cellContent;
    xL_title = compose('y/FSL = %.1f', xL_value);
    title_PF = ['Displ (m)', xL_title'];


    csvFileName = fullfile(folderPath, ['Hazard_curve_PF_' FaultName '.csv']);
    fid = fopen(csvFileName, 'w');

    fprintf(fid, '%s', title_PF{1});
    for k = 2:numel(title_PF)
        fprintf(fid, ',%s', title_PF{k});
    end
    fprintf(fid, '\n');

    [nRows, nCols] = size(cellContent);
    for i = 1:nRows
        for j = 1:nCols
            if isnumeric(cellContent{i,j})
                fprintf(fid, '%g', cellContent{i,j});
            else
                fprintf(fid, '%s', cellContent{i,j});
            end
            if j < nCols
                fprintf(fid, ',');
            end
        end
        fprintf(fid, '\n');
    end
    fclose(fid);


    %% %%%%%%%%%%%%%%%%%%%%%% DISTRIBUTED RUPTURES %%%%%%%%%%%%%%%%%%%%%% %%

    %% Evaluation of the Displacement Attenuation Law - DISTRIBUTED FAULTING
    if ~isempty(Pslip_DR_m) && ~isempty(Pexc_DR_m) && Dist_value > 0

        if floating ==1
            Dist_riv = Dist_riv;
        else
            for i = 1:length(Mcase)
                for j = 1:length(xL_value)
                    Dist_riv{i, j} = Dist_value;
                end
            end
        end


        % Conditional Probability of surface rupture at a specific site for
        % distributed ruptures
        [P_slip_DR, warnings_Pslip_DR_AT, model_mag_range_DR, model_dist_range_DR] = P_rupt_site_DR(Dist_riv, Wall_type, Mcase, Pslip_DR_m, Dist_value, kinematicType, FaultName, folderPath);
        % Conditional Probability of exceedance for distributed ruptures
        [P_exceedance_DR, warnings_DR_AT, Pexc_model_mag_range_DR, Pexc_model_dist_range_DR,P_exc_model_coefficients_DR] = Pexceedance_DR(x_axis_displacement, displacement_levels, Dist_riv, p_Displ, D_perc, d_truncation, Pexc_DR_m, Wall_type, Mcase, Dist_value, kinematicType, FaultName, folderPath);

        %% Vk(d) - DISTRIBUTED FAULTING
        P_exceedance_riv = cell(size(P_exceedance));

        for m_idx = 1:size(P_exceedance, 1)
            for x_idx = 1:size(P_exceedance, 2)
                current_curves = P_exceedance{m_idx, x_idx};

                revised_curves = current_curves;

                for curve_idx = 1:size(current_curves, 1)
                    % As the distances revaluated during floating are measured from
                    % the nearest tip of the single rupture, we revaluate
                    % P_exceedance of PF also considering the Conditional Prob of
                    % exceedance of x/L = 0.005
                    if all(current_curves(curve_idx, :) == 0)
                        revised_curves(curve_idx, :) = P_exceedance_tip(m_idx, :);
                    end
                end

                P_exceedance_riv{m_idx, x_idx} = revised_curves;
            end
        end


        %% &&
        % Initialize HC_DR_full as a cell array
        HC_DR_full = cell(length(Mcase), length(xL_value));
        HC_DR_sum = cell(length(Mcase), length(xL_value));
        % Initialize HC_DR_total as a cell array
        HC_DR_tot = cell(1, length(xL_value)); % One cell for each xL_value

        for g = 1:length(Mcase) % Loop over each magnitude
            for a = 1:length(xL_value) % Loop over each xL_value
                n_combinations = size(P_slip_DR{g, a}, 1); % Number of combinations
                for b = 1:length(Dist_value) % Loop over each Dist_value
                    for i = 1:n_combinations % Loop over all combinations
                        % Extract the required components
                        P_base = P_exceedance_riv{g, a}(i, :); % [1x50]
                        P_slip_curr = P_case(g); % Scalar
                        P_slip = P_slip_DR{g, a}(i, b); % Scalar
                        rate_value = rates(g); % Scalar


                        % Compute HC_DR_full for the current configuration
                        if any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'}))
                            HC_DR_full{g, a}(i, b, :) = rate_value .* P_slip_curr .* P_base .* P_slip; % adjusting the probability for off-fault location as in the original code
                            P_exc = P_exceedance_DR(b);
                            displ_levels_Moss(b,:) =  P_exc .* displacement_levels;
                        else
                            P_exc = squeeze(P_exceedance_DR{g, a}(i, b, :)); % [1x50]

                            % Ensure dimensions are consistent for element-wise multiplication
                            if size(P_exc, 1) ~= 1
                                P_exc = P_exc'; % Convert to row vector if needed
                            end

                            HC_DR_full{g, a}(i, b, :) = rate_value .* P_slip_curr .* P_exc .* P_slip;
                        end
                    end
                end

                if ~isempty(HC_DR_full{g, a})
                    % Sum along the n_combinations dimension (1st dimension)
                    % to include all the contributes coming from every combination
                    HC_DR_sum{g, a} = sum(HC_DR_full{g, a}, 1); % Resulting size: [1, length(Dist_value), 50]
                end
            end

            for a = 1:length(xL_value) % Loop over each xL_value
                % Initialize accumulator for the sum across Mcase
                total_sum = 0;

                for g = 1:length(Mcase) % Loop over each magnitude
                    if ~isempty(HC_DR_sum{g, a})
                        % to sum all contributes coming from each tested Mw
                        total_sum = total_sum + squeeze(HC_DR_sum{g, a}); % [length(Dist_value), 50]
                    end
                end

                % Store the aggregated result for this xL_value
                HC_DR_tot{a} = total_sum; % [length(Dist_value), 50]
            end
        end

        %% &&

        figure();
        % Plot for DR
        hold on;

        for i = 1:length(xL_value)
            HC_DR_current = HC_DR_tot{i}';

            for j = 1:length(Dist_value)
                if strcmp(Pslip_DR_m,'MEA22') && any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'}))
                    loglog(displ_levels_Moss(j,:), HC_DR_current(j,:), 'LineWidth', 1.5,...
                        'Color', colors(j), 'LineStyle', line_styles{i}, ...
                        'DisplayName', sprintf('y/FSL = %.1f, r_0 = %.2f km', xL_value(i), Dist_value(j)));
                    if ~isempty(Design_displ) && ~isnan(Design_displ)
                        Ddesign_prob_DR(i, j) = interp1(displ_levels_Moss(j,:), HC_DR_current, Design_displ);
                        plot([1e-8 Design_displ Design_displ], [Ddesign_prob_DR(i, j) Ddesign_prob_DR(i, j) 1e-18], ...
                            'LineStyle', ':', 'Color', [0.64 0.08 0.18], 'LineWidth', 1.5, ...
                            'DisplayName', sprintf('D_{Design} = %.1f m', Design_displ))
                        text_in_plot = sprintf('%.2e yr^-^1', Ddesign_prob_DR(i, j));
                        text(0.004,  Ddesign_prob_DR(i, j), text_in_plot , 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left', 'Color', 'k')
                        Ddesign_recurrence(i,i) = 1./Ddesign_prob_DR(i,j);
                    else
                        Ddesign_prob_DR = [];
                        Ddesign_recurrence_DR = [];
                    end
                else
                    loglog(displacement_levels, HC_DR_current(j,:), 'LineWidth', 1.5, ...
                        'Color', colors(j), 'LineStyle', line_styles{i}, ...
                        'DisplayName', sprintf('r_0 = %.2f km', Dist_value(j)));
                    if ~isempty(Design_displ) && ~isnan(Design_displ)
                        Ddesign_prob_DR(i, j) = interp1(displacement_levels, HC_DR_current, Design_displ);
                        plot([1e-8 Design_displ Design_displ], [Ddesign_prob_DR(i, j) Ddesign_prob_DR(i, j) 1e-18], ...
                            'LineStyle', ':', 'Color', [0.64 0.08 0.18], 'LineWidth', 1.5, ...
                            'DisplayName', sprintf('D_{Design} = %.1f m', Design_displ))
                        text_in_plot = sprintf('%.2e yr^-^1', Ddesign_prob_DR(i, j));
                        text(0.004,  Ddesign_prob_DR(i, j), text_in_plot , 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left', 'Color', 'k')
                        Ddesign_recurrence_DR(i,i) = 1./Ddesign_prob_DR(i,j);
                    else
                        Ddesign_prob_DR = [];
                        Ddesign_recurrence_DR = [];
                    end
                end

            end
        end

        if ~isempty(AFOE_fixed) & ~isnan(AFOE_fixed)
            for i = 1:length(AFOE_fixed)
                loglog(displacement_levels, AFOE_fixed(i) * ones(size(displacement_levels)), ...
                    'LineStyle', '--', 'LineWidth', 2, 'Color', [0.3010,0.7450,0.9330], ...
                    'DisplayName', sprintf('T_R = %d yr', Recurrence_time));
            end
        end

        set(gca, 'XScale', 'log', 'YScale', 'log');
        grid on
        axis square
        ylabel('Annual Frequency of Exceedance (yr^-^1)')
        xlabel('Displacement (m)')
        ylim([1E-8 1E-1])
        legend('show')
        xlim([0.001 10])
        if strcmp(Wall_type, "HW")==1
            title (['Hazard Curve - ' FaultName ' (Hanging wall)'])
        elseif strcmp(Wall_type, "FW")==1
            title (['Hazard Curve - ' FaultName ' (Footwall)'])
        end
        hold off

        saveas(gcf, fullfile(folderPath, ['Hazard_curve_DR_' FaultName '.fig']));

        %% save the DR Hazard Curves in Cell-array
        for j = 1:length(HC_DR_tot)
            HC_DR_current = HC_DR_tot{j}';
            for d_idx = 1:length(Dist_value)
                for i = 1:length(displacement_levels)
                    if any(strcmp(Pexc_DR_m,{'MEA22_a', 'MEA22_b'}))
                        cellContent_DR{i, 1} = displ_levels_Moss(d_idx, i)';
                    else
                        cellContent_DR{i, 1} = displacement_levels(i);
                    end
                    cellContent_DR{i, d_idx+1} = HC_DR_current(d_idx, i);
                end
            end
            Hazard_curves_DR{faultIdx, j} = cellContent_DR;
        end
        Dist_title = compose('r_0 = %.1f km', Dist_value);
        title_DR = ['Displ (m)', Dist_title];

        csvFileName_DR = fullfile(folderPath, ['Hazard_curve_DR_' FaultName '.csv']);
        fid2 = fopen(csvFileName_DR, 'w');

        fprintf(fid2, '%s', title_DR{1});
        for k = 2:numel(title_DR)
            fprintf(fid2, ',%s', title_DR{k});
        end
        fprintf(fid2, '\n');

        [nRows, nCols] = size(cellContent);
        for i = 1:nRows
            for j = 1:nCols
                if isnumeric(cellContent{i,j})
                    fprintf(fid2, '%g', cellContent{i,j});
                else
                    fprintf(fid2, '%s', cellContent{i,j});
                end
                if j < nCols
                    fprintf(fid2, ',');
                end
            end
            fprintf(fid2, '\n');
        end
        fclose(fid2);

    else
        warnings_DR_AT = [];
        title_DR = [];
        Hazard_curves_DR = [];
        Ddesign_prob_DR = [];
        Ddesign_recurrence_DR = [];
        model_mag_range_DR = [];
        model_dist_range_DR = [];
        warnings_Pslip_DR_AT = [];
        Pexc_model_mag_range_DR = [];
        Pexc_model_dist_range_DR = [];
        P_exc_model_coefficients_DR = [];
    end

    %% Function for log
    LogFile(faultIdx,FaultName,folderPath,faultData,Width,Telap,yfc,Mmax,sigma_Mmax,Tmean,...
        MomentRate,MFD,Mcase,rates,P_slip_coeff,srl_case,dist_starting_point,dist_ending_point,...
        x_over_L_riv,configurations,Ll_cases,P_2p,warnings_Mw_geo_ScR,warnings_rates,warnings_Pslip,...
        warnings_Pexc,warnings_Mw_srl,warnings_Pslip_DR_AT,model_mag_range_DR,model_dist_range_DR,...
        warnings_DR_AT, Pexc_model_mag_range_DR, Pexc_model_dist_range_DR,Hazard_curves_PF,title_PF,...
        Hazard_curves_DR,title_DR,Ddesign_prob_PF,Ddesign_recurrence,Ddesign_prob_DR,Ddesign_recurrence_DR,classic,P_exc_model_coefficients_DR)

end

