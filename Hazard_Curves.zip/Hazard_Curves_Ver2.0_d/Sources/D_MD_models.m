%% Available models to fit MD data
% Here we define a structure including all the models available
% in the scientific literature to evaluate D/MD.
% The data are usually fit with a Beta distribution (for all the available models, 
% just Moss et al. (2022) is an exception, as the model prefers to use a 
% Gamma distribution to fit data).

% The main authors are listed below, while the corresponding model number 
% is reported within ():

%% Youngs et al. (2003) - YEA03
% The authors focused on normal faults (1)

%% Moss et al. (2022) - MEA22
% The authors focused on reverse faults (2)

%% Takao et al. (2013) - TEA13
% The authors analyzed both reverse and strike-slip faults (3)
% Warning: this model is based on Japanese earthquakes data 
% The model may not be suitable out of this geographic area

function D_models = D_MD_models()

D_models = struct(); % initializing the structure for the fit models

D_models(1).name = 'YEA03';
D_models(1).kinematics = 'N';
D_models(1).a = @(x) exp(-0.705 + 1.138 * x);
D_models(1).b = @(x) exp(0.421 - 0.257 * x);
D_models(1).function = 'Beta';

D_models(2).name = 'MEA22';
D_models(2).kinematics = 'R';
D_models(2).a = @(x) 1.4244 * x + 1.856;
D_models(2).b = @(x) -0.0832 * x +0.1994;
D_models(2).function = 'Gamma';

D_models(3).name = 'TEA13'; % L > 10km
D_models(3).kinematics = 'R-SS';
D_models(3).a = @(x) exp(0.70 - 0.87 * x);
D_models(3).b = @(x) exp(2.30 - 3.84 * x);
D_models(3).function = 'Beta';

D_models(4).name = 'TEA13_b'; % L < 10km
D_models(4).kinematics = 'R-SS';
D_models(4).a = 0.91;
D_models(4).b = 1.90;
D_models(4).function = 'Beta';

% Save the structure 
% save('MD_models.mat', "D_models", '-mat')

end