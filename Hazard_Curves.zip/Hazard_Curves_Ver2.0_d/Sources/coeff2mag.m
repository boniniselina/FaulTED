function[MRLD, MRA, dMRLD, dMRA, MAR, LAR, pea02_Sigma, legends_Mw, warnings_Mw_geo_ScR]=coeff2mag(m_ScR, kinematicType, Length, Width,  ShearModulus, StrainDrop)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% COMPUTE MAGNITUDEs FROM scale- and FROM ASPECT RATIO- relationship) %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Return the coefficients of the chosen Scaling Relation and of 
%% Pace et al. (2002)
[ScR_Coeffs, ScR_Sigma, ScR_Range, pea02Coeffs, pea02_Sigma] = getScalingCoefficients(m_ScR, kinematicType);

warnings_Mw_geo_ScR = struct('id', {}, 'message', {}, 'values', {});

%% WELLS & COPPERSMITH (1994) EQUATIONS
% note that here Length and Width have to be expressed in km

if any(strcmp(m_ScR, {'WC94-N', 'WC94-R', 'WC94-S', 'WC94-A'})) 
    Length_km=Length/1000;
    Width_km=Width/1000;
     
    MRLD= ScR_Coeffs(1) + ScR_Coeffs(2)*log10(Length_km);
    MRA= ScR_Coeffs(3) + ScR_Coeffs(4)*log10(Length_km*Width_km);
    dMRLD= ScR_Sigma(1);
    dMRA= ScR_Sigma(2);
    % Reliability of the magnitude range
    if any(MRLD < ScR_Range(1)) || any(MRLD > ScR_Range(2))
        warning_id = 'MATLAB:InvalidMwRLD';
        warning_msg = sprintf('Some tested Mw values ​​are outside the valid range of the selected model (%.1f - %.1f) for RLD. The results will be an extrapolation.', ScR_Range(1), ScR_Range(2));
        disp(warning_msg)
        warnings_Mw_geo_ScR(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', []);
    elseif any(MRA < ScR_Range(3)) || any(MRA > ScR_Range(4))
        warning_id = 'MATLAB:InvalidMwRA';
        warning_msg = sprintf('Some tested Mw values ​​are outside the valid range of the selected model (%.1f - %.1f) for RA. The results will be an extrapolation.', ScR_Range(3), ScR_Range(4));
        disp(warning_msg)
        warnings_Mw_geo_ScR(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', []);
    end
        
%% LEONARD (2010) EQUATIONS
% Remember that the Scaling Relations are used to estimate the seismic
% moment from which the Moment Magnitude Mw can be assessed

elseif any(strcmp(m_ScR, {'L10-D', 'L10-S', 'L10-SCR'}))  
   
    MRLDmin= (2/3)* log10(10^(ScR_Coeffs(2)+ ScR_Coeffs(1)*log10(Length)))-6.07;
    MRAmin= (2/3)* log10(10^(ScR_Coeffs(5) + ScR_Coeffs(4)*log10((Length)*(Width))))-6.07;
    MRLDmax= (2/3)* log10(10^(ScR_Coeffs(3)+ ScR_Coeffs(1)*log10(Length)))-6.07;
    MRAmax= (2/3)* log10(10^(ScR_Coeffs(6) + ScR_Coeffs(4)*log10((Length)*(Width))))-6.07;
    MRLD= MRLDmin+((MRLDmax-MRLDmin)/2);
    MRA= MRAmin+((MRAmax-MRAmin)/2);
    dMRLD=(MRLDmax-MRLDmin)/2;
    dMRA=(MRAmax-MRAmin)/2;

%% THINGBAIJAM ET AL. (2017) EQUATIONS
% note that here Length and Width have to be expressed in km

elseif strcmpi(m_ScR,'T17-N')==1 | strcmpi(m_ScR,'T17-R')==1 | strcmpi(m_ScR,'T17-S')==1

    Length_km=Length/1000;
    Width_km=Width/1000;
     
    MRLD= ScR_Coeffs(1) + ScR_Coeffs(2)*log10(Length_km);
    MRA= ScR_Coeffs(3) + ScR_Coeffs(4)*log10(Length_km*Width_km);
    dMRLD= ScR_Sigma(1);
    dMRA= ScR_Sigma(2);

        % Reliability of the magnitude range
    if any(MRLD < ScR_Range(1)) || any(MRLD > ScR_Range(2))
        warning_id = 'MATLAB:InvalidMwRLDRA';
        warning_msg = sprintf('Some tested Mw values ​​are outside the valid range of the selected model (%.1f - %.1f) for RLD and RA. The results will be an extrapolation.', ScR_Range(1), ScR_Range(2));
        disp(warning_msg)
        warnings_Mw_geo_ScR(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', []);
    end

end

    legends_Mw=['MRLD'; ' MRA'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Aspect Ratio Control Formula (Pace and Peruzza, 2002)
% note that here Length and Width are expressed in km
Width_km=Width/1000;
LAR= pea02Coeffs(1)+pea02Coeffs(2)*(Width_km);
% check if Length from Aspect Ratio is not greater than input length

% now dimensions are in metres
%LAR=min(Length,(LAR*1000));
LAR=LAR*1000;
% calculate the moment magnitude from LAR 
MAR= (2/3)* (log10(StrainDrop * ShearModulus* LAR^2 *Width) -9.05);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% 
    function [ScR_Coeffs, ScR_Sigma, ScR_Range, pea02Coeffs, pea02_Sigma] = getScalingCoefficients(m_ScR, kinematicType)
        Mag_geom_scaling_rel = Mw_geometry_regressions();
        
        ScR_Coeffs = [];
        ScR_Sigma = [];
        ScR_Range = [];
        pea02Coeffs = [];
        pea02_Sigma = [];

        % Looking for the input Scaling Relation
        modelFound = false;
        for i = 1:10
            if strcmp(Mag_geom_scaling_rel(i).name, m_ScR)
                ScR_Coeffs = Mag_geom_scaling_rel(i).coefficients;
                ScR_Sigma = Mag_geom_scaling_rel(i).sigma;
                ScR_Range = Mag_geom_scaling_rel(i).range;

                modelFound = true;
                break;
            end
        end
        
        if ~modelFound
            error('Model not found in the structure.');
        end
        
        % Pace et al. (2002) coefficients
        switch kinematicType
            case 'N'
                pea02Coeffs = Mag_geom_scaling_rel(11).coefficients(1, :); % Normal
            case 'R'
                pea02Coeffs = Mag_geom_scaling_rel(11).coefficients(2, :); % Reverse
            case 'SS'
                pea02Coeffs = Mag_geom_scaling_rel(11).coefficients(3, :); % Strike-Slip
            case 'All'
                pea02Coeffs = Mag_geom_scaling_rel(11).coefficients(4, :); % All Dip
            otherwise
                error('Kinematic type not recognized.');
        end
        pea02_Sigma = Mag_geom_scaling_rel(11).sigma;
    end
    

end











    
    