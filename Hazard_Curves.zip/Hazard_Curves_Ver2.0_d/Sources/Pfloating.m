%% Floating of the ruptures
% in this section the lengths of the surface ruptures are calculated 
% based on the scaling relations with the Mw (srl) in the case of a 
% magnitude distribution (e.g. truncated GR distribution). 
% Each rupture is then translated along the overall length of the fault. 

% We then evaluate: 
% a) P_pos = the probability that a rupture of length srl 
% affects the evaluation point, x; 
% b) P_float = conditional probability of exceedence calculated on 
% the basis of the revalued x/L points for the individual srl ruptures 
% and considering all possible location of these ruptures.

function [P_float, srl_case, rates_riv, x_over_L_riv, Dist_riv, dist_starting_point, dist_ending_point, warnings_Mw_srl] = Pfloating(kinematicType, srl_ScR, floating_bin, Length, xL_value, Mcase, M_0, displacement_levels, P_exceedance_full, Dist_value, rates, P_D_model, p_Displ, Displ_type, x_axis_displacement, D_perc,P_exceedance_old)


%% PRINCIPAL RUPTURE

[srl_case, warnings_Mw_srl] = getScalingCoefficients_displ(srl_ScR, Mcase, M_0, kinematicType);
bin_xl = floating_bin;
x_n4 = Length * xL_value; % in km
num_x_n = length(x_n4);  

P_pos_t = zeros(length(Mcase), num_x_n);  % temporary matrix for P_pos
P_pos = zeros(length(Mcase), num_x_n);  % Probability of having ruptures of that length (as function of Mw) at the evaluation site, x
x_over_L_riv = cell(length(Mcase), 1);  % x/L revalued on rupture length
rates = rates';
rates_riv = zeros(length(rates), 1);


%% &&
% Initialize P_float as a cell array with dimensions based on Mcase and xL_value
P_float = cell(length(Mcase), length(xL_value));


%% Only for P exceedance model = TEA13, it is necessary to evaluate srl, 
%% because the authors provides a different fault scaling law if srl<10 km

%% Evaluating the conditional probability of exceedance (P3p) in case Ll<10 km
% it is evaluated only when choosing TEA13 as model for the estimation of P_exceedance

if strcmp(P_D_model, 'TEA13')
    if Displ_type == 1 % If AD
        D_models = D_AD_models();
    elseif Displ_type == 2 % If MD
        D_models = D_MD_models();
    end

    a_gamma_b = D_models(4).a;
    b_gamma_b = D_models(4).b;
    chosen_function_b = D_models(4).function;
    scenario_tea13_b = cdf(chosen_function_b, D_perc, a_gamma_b, b_gamma_b);
    n=1; P2 = []; P3 = []; P_exceedance_full_b = [];

    for m = 1: size(p_Displ,1) % M
        for g = 1:size(scenario_tea13_b,1) % x/l


            for i =1:length(p_Displ(m,:)) % probability of having a specific AD value as function of M
                D_assoluto =  x_axis_displacement(i) .* D_perc;

                for h = 1:length(displacement_levels)
                    P_non_exceedance = find(D_assoluto < displacement_levels(h),1,"last"); % Explore the Probability of Non-Exceedance
                    if isempty(P_non_exceedance)
                        P_non_exceedance=1;
                    end

                    P2(i,h) =  (1-scenario_tea13_b(g,P_non_exceedance)); % P of exceedance = 1 - P non-exceedance

                end
                P3(i,:) = p_Displ(m,i) .* P2(i,:);
            end

            P_exceedance_full_b(n,:) = sum(P3,1); % the first 100 rows
            % (corresponding to the 100 values ​​of x/L) refer to the first magnitude
            % of Mcase, the second 100 to the second value of Mcase etc., while the
            % number of columns depends on the length of displacement_levels

            n=n+1;
        end
    end
end



%% FLOATING
for mag_idx = 1:length(Mcase)
    srl = srl_case(mag_idx);  % Length of the current rupture (Mw)

    % Preparing counter of rows to explore P_exceedance_full
    row_start = (mag_idx - 1) * num_x_n + 1;
    row_end = mag_idx * num_x_n;

    if srl < Length
        % Number of positions along the fault trace to make the rupture translate
        start_positions = 0:bin_xl:(Length - srl);
        num_positions = length(start_positions);  % Number of valid translations,
        % where the segment is completely within the fault

        % Preallocate temporary matrix for probability exceedance
        % first_x_over_L_riv = NaN(1, num_x_n);
        x_over_L_riv{mag_idx} = NaN(num_positions, num_x_n); % Preallocate with NaN only for the number of translations
        temp_matrix = zeros(num_positions, length(displacement_levels), num_x_n);

        % Loop over translation increments
        for loc_idx = 1:num_positions
            start_segment = start_positions(loc_idx);
            end_segment = start_segment + srl;

            if end_segment <= Length
                % Loop over evaluation points
                for point_idx = 1:num_x_n
                    if x_n4(point_idx) >= start_segment && x_n4(point_idx) <= end_segment
                        dist_from_start = x_n4(point_idx) - start_segment;
                        dist_from_end = end_segment - x_n4(point_idx);
                        min_dist = min(dist_from_start, dist_from_end);
                        % If the current evaluation point is located at the 
                        % termination of the rupture, we assign x/L =
                        % 0.005, where, in this case, x = distance of the
                        % evaluation point from the nearest end of the
                        % rupture, and L = length of the rupture (srl)
                        % for the other cases, the calculation takes into
                        % account the symmetry of the x/L normalization 
                        % Calculate x/L normalization
                        dist_starting_point{mag_idx,1} = start_positions';
                        dist_ending_point{mag_idx,1} = start_positions'+srl;
                        x_over_L_value = min_dist / srl;
                        x_over_L_value = max(x_over_L_value, 0.005);  % Ensure minimum value
                        x_over_L_riv{mag_idx}(loc_idx, point_idx) = x_over_L_value;
                       
                        P_pos_t(mag_idx, point_idx) = P_pos_t(mag_idx, point_idx) + 1;  % Sum of the ruptures affecting the evaluation point

                        % Then, we could recalculate the Conditional Prob
                        % of exceedance considering the new x/L values.
                        % Find closest x/L value
                        [~, idx_closest] = min(abs(xL_value - x_over_L_value));
                        
                        if strcmp(P_D_model, 'TEA13')
                            if idx_closest >= 1 && idx_closest <= length(xL_value)
                                if srl < 10
                                    temp_matrix(loc_idx, :, point_idx) = P_exceedance_full_b(mag_idx,:);
                                else
                                    P_exc_row = P_exceedance_full(row_start + (idx_closest - 1), :);
                                    temp_matrix(loc_idx, :, point_idx) = P_exc_row;
                                end
                            end
                        else
                            if idx_closest >= 1 && idx_closest <= length(xL_value)
                                P_exc_row = P_exceedance_full(row_start + (idx_closest - 1), :);
                                temp_matrix(loc_idx, :, point_idx) = P_exc_row;
                            end
                        end
                    end
                end
            end
        end

        % Populate the cell array for each xL_value
        for col_idx = 1:length(xL_value)
            P_float{mag_idx, col_idx} = temp_matrix(:, :, col_idx);
        end
        rates_riv(mag_idx) = rates(mag_idx) / num_positions;

    else
        % If rupture length exceeds fault length
        % Populate with a single configuration: 
        % the x/L points are considered equal to those of the fault, 
        % because there is only a rupture that does not translate. 
        % Consequently, the P_pos is also 1 at all points
        x_over_L_riv{mag_idx} = xL_value';
        dist_starting_point{mag_idx,1} = 0;
        dist_ending_point{mag_idx,1} = Length;

        num_positions = 1;
        P_pos_t(mag_idx, :) = ones(1, num_x_n);
        rates_riv(mag_idx) = rates(mag_idx);
        for col_idx = 1:length(xL_value)
            % P_float{mag_idx, col_idx} = repmat(P_exceedance_full(row_start:row_end, :), [1, 1, num_x_n]);
            % P_float{mag_idx, col_idx} = P_exceedance_full((row_start+col_idx-1), :);
            P_float{mag_idx, col_idx} = P_exceedance_old(row_start + (col_idx - 1), :);
        end
    end
    % P_pos = Number of the rupture of that length affecting the evaluation
    % points / total number of possible rupture of that length traslating
    % along the fault (rupture configurations)    
      P_pos(mag_idx, :) = P_pos_t(mag_idx, :) / num_positions;
end

%% &&


%% DISTRIBUTED RUPTURES
Dist_riv = cell(length(Mcase), 1);  % Distances revalued on rupture length

if Dist_value > 0 % off-fault case
for mag_idx = 1:length(Mcase)
    srl = srl_case(mag_idx);  % L of the current rupture (Mw)
    
    num_r_n = length(Dist_value);

    if srl < Length
        % Number of positions along the fault trace to make the
        % rupture translate
        start_positions = 0:bin_xl:(Length - srl);
        num_positions = length(start_positions);

        for loc_idx = 1:num_positions
            % Defining the start and end of the current rupture for this translation
            start_segment = start_positions(loc_idx);
            end_segment = start_segment + srl;
            % check if the x/L input value is included within the rupture
            for point_idx = 1:num_x_n
                for dist_idx = 1:num_r_n
                    if x_n4(point_idx) >= start_segment && x_n4(point_idx) <= end_segment
                        Dist_riv{mag_idx, point_idx}(loc_idx, :) = Dist_value';
                    else
                        % if not, we calculate the minimum distance from the
                        % nearest rupture end point
                        dist_from_start = abs(x_n4(point_idx) - start_segment);
                        dist_from_end = abs(x_n4(point_idx) - end_segment);
                        r_fp = min(dist_from_start, dist_from_end); % (Fault parallel distance): 
                        % Distance along the principal fault trace of the segment rupture tips from the evaluation point
                        r_revaluated(loc_idx, dist_idx) = sqrt(r_fp.^2 + Dist_value(dist_idx).^2); % Pythagora's Theorem 
                        % Considering a right triangle, the two legs are 
                        % the Fault parallel distance (r_fp) and the Fault 
                        % normal distance (Dist_value, which is evaluated 
                        % from the nearest point on the PF that represents 
                        % the evaluation point). So, the revaluated distance 
                        % can be calculated as the hypotenuse. 
                        Dist_riv{mag_idx, point_idx}(loc_idx, dist_idx) = r_revaluated(loc_idx, dist_idx);
                    end
                end
            end
        end

    else
        % If the rupture length is greater than the fault, consider the
        % distance as Dist_value for all points
        for point_idx = 1:num_x_n
            Dist_riv{mag_idx, point_idx} = repmat(Dist_value, num_x_n, 1);
        end
    end
end

else
    for mm = 1:length(Mcase)
        for xx = 1:length(xL_value)
            Dist_riv{mm, xx} = Dist_value;
        end
    end
end



%%

function [srl_case, warnings_Mw_srl] = getScalingCoefficients_displ(srl_ScR, Mcase, M_0, kinematicType)

warnings_Mw_srl = struct('id', {}, 'message', {}, 'values', {});

srl_Mw_scaling_rel = Mw_srl_regressions();

% Looking for the input Scaling Relation
modelFound = false;
srl_case = zeros(size(Mcase)); 

for i = 1:length(srl_Mw_scaling_rel)
    if strcmp(srl_Mw_scaling_rel(i).name, srl_ScR)
        if strcmp(srl_ScR, 'Leo14-S') 
            M0_lim = 10.^(9.15+2.27.*log(65000));
            for j = 1:length(M_0)
                if M_0(j) <= M0_lim
                    selectedModel = srl_Mw_scaling_rel(6);
                else
                    selectedModel = srl_Mw_scaling_rel(7);
                end

                srl_ScR_Coeffs = selectedModel.coefficients;
                srl_case(j) = (round(10.^((log10(M_0(j))-srl_ScR_Coeffs(1))./srl_ScR_Coeffs(2)),1))./1000;

                srl_Range = selectedModel.range;
                    if ~isnan(srl_Range(1)) && (srl_case(j) * 1000 < srl_Range(1))
                        warning_id = 'MATLAB:InvalidMwsrl';
                        warning_msg = sprintf('Surface rupture length = %.1f km (related to Mw = %.1f) is below the valid range of the selected model (%.1f km). The results will be an extrapolation.', srl_case(j), Mcase(j), srl_Range(1) / 1000);
                        disp(warning_msg)
                        warnings_Mw_srl(end+1) = struct('id', warning_id, ...
                            'message', warning_msg, ...
                            'values', []);
                    end
                    if ~isnan(srl_Range(2)) && (srl_case(j) * 1000 > srl_Range(2))
                        warning_id = 'MATLAB:InvalidMwsrl';
                        warning_msg = sprintf('Surface rupture length = %.1f km (related to Mw = %.1f) is below the valid range of the selected model (%.1f km). The results will be an extrapolation.', srl_case(j), Mcase(j), srl_Range(2) / 1000);
                        disp(warning_msg)
                        warnings_Mw_srl(end+1) = struct('id', warning_id, ...
                            'message', warning_msg, ...
                            'values', []);

                    end
            end
            modelFound = true;
            break;

        else
            selectedModel = srl_Mw_scaling_rel(i);
            srl_ScR_Coeffs = selectedModel.coefficients;
            srl_Sigma = selectedModel.sigma;
            srl_Range = selectedModel.range;
            if any(strcmp(srl_ScR, {'L14-D', 'L14-S'}))
                srl_case = (round(10.^((log10(M_0)-srl_ScR_Coeffs(1))./srl_ScR_Coeffs(2)),1))./1000;
                % Reliability of the size range
                for h = 1:length(srl_case)
                    if ~isnan(srl_Range(1)) && (srl_case(h) * 1000 < srl_Range(1))
                        warning_id = 'MATLAB:InvalidSizesrl';
                        warning_msg = sprintf('Surface rupture length = %.1f km (related to Mw = %.1f) is below the valid range of the selected model (%.1f km). The results will be an extrapolation.', srl_case(h), Mcase(h), srl_Range(1) / 1000);
                        disp(warning_msg)
                        warnings_Mw_srl(end+1) = struct('id', warning_id, ...
                            'message', warning_msg, ...
                            'values', []);
                    end
                    if ~isnan(srl_Range(2)) && (srl_case(h) * 1000 > srl_Range(2))
                        warning_id = 'MATLAB:InvalidSizesrl';
                        warning_msg = sprintf('Surface rupture length = %.1f km (related to Mw = %.1f) is below the valid range of the selected model (%.1f km). The results will be an extrapolation.', srl_case(h), Mcase(h), srl_Range(2) / 1000);
                        disp(warning_msg)
                        warnings_Mw_srl(end+1) = struct('id', warning_id, ...
                            'message', warning_msg, ...
                            'values', []);
                    end
                end
                % Reliability of model kinematics
                if strcmp(srl_ScR, 'L14-D')
                    if ~strcmp(kinematicType, 'R') && ~strcmp(kinematicType, 'N')
                        warning_id = 'MATLAB:InvalidKin';
                        warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen srl_ScR.');
                        disp(warning_msg)
                        warnings_Mw_srl(end+1) = struct('id', warning_id, ...
                            'message', warning_msg, ...
                            'values', []);
                    end
                else
                    if ~strcmp(kinematicType, "SS")
                        warning_id = 'MATLAB:InvalidKin';
                        warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen srl_ScR.');
                        disp(warning_msg)
                        warnings_Mw_srl(end+1) = struct('id', warning_id, ...
                            'message', warning_msg, ...
                            'values', []);
                    end
                end
            else
                srl_case = round(10.^(srl_ScR_Coeffs(1) + srl_ScR_Coeffs(2) .* Mcase), 1);
                for j = 1:length(Mcase)
                    if Mcase(j) < srl_Range(1) || (~isnan(srl_Range(2)) && Mcase(j) > srl_Range(2))
                        warning_id = 'MATLAB:InvalidMwsrl';
                        warning_msg = sprintf('Mw = %.1f exceeds the valid range of the selected model (%.1f - %.1f). The results will be an extrapolation.', Mcase(j), srl_Range(1), srl_Range(2));
                        disp(warning_msg)
                        warnings_Mw_srl(end+1) = struct('id', warning_id, ...
                            'message', warning_msg, ...
                            'values', []);

                    end
                end
                if ~strcmp(kinematicType, selectedModel.kinematics)
                    warning_id = 'MATLAB:InvalidKin';
                    warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen srl_ScR.');
                    disp(warning_msg)
                    warnings_Mw_srl(end+1) = struct('id', warning_id, ...
                        'message', warning_msg, ...
                        'values', []);
                end
            end
            modelFound = true;
            
            break;

        end
    end
end


if ~modelFound
    error('Model not found in the structure.');
end

end

    
end