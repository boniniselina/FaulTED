%% %%%%%%%%%%  Probability surface rupture at a specific  %%%%%%%%%% %%
%% %%%%%%%%%%    site location for distributed ruptures   %%%%%%%%%% %%

%% BRIEF DESCRIPTION
% This term represents the conditional probability that surface (or
% near-surface) displacement occurs on a feature at location k due to
% an earthquake occurring on some other source. The regressions have been
% evaluated using z grid squares (usually 500 m)
% The general equation for the probability is (Wells & Coppersmith, 1993)
%                 P_slip_DR = exp(f_x) ./ (1 + exp(f_x))
% where f(x) equations vary from an author to another. Four functional
% forms could be recognized:
%           FUNCTIONAL FORM 1
%           f(x) = c1 + (C2 + C3*m + C4*h)*ln(r+C5)
%               where h = 1 if HW and h = 0 if FW
%           FUNCTIONAL FORM 2
%           f(x) = c1 + (C2 + C3*m + C4*h)*ln(r+C5)+tz
%               where h = 1 if HW and h = 0 if FW
%               tz is  a random variate
%           FUNCTIONAL FORM 3
%           f(x) = C1 + C2*ln(r+C3)
%           FUNCTIONAL FORM 4
%           f(x) = exp(C1* ln(r*1000)+C2)

% The list of the models currently supported by this routine is reported
% below:
% NORMAL FAULT
% [1] Youngs et al. (2003) - YEA03
%        functional form 1 [Eq. 7] & functional form 2 [Eq. 8]
%        the code will provide an average between the two equations
%        z = 500 m
% [2] Ferrario and Livio (2021) - FL21
%       (a) for regular scenario,
%       (b) for conservative scenario coefficients [Table 2]
%        functional form 3
%        z = 500 m
% STRIKE-SLIP
% [3] Petersen et al. (2011) - PEA11
%       (a) for z = 25 m
%       (b) for z = 50 m
%       (c) for z = 100 m
%       (d) for z = 150 m
%       (e) for z = 200 m coefficients
% Note that the power function does not extrapolate well near fault
% (near field), leading to very high probability values.
% Probability is interpolated in near field using p0, p1, p2, r1, and r2
% coefficients [Table 5].
% STRIKE-SLIP / REVERSE
% [4] Takao et al. (2013) - TEA13
%        functional form 1
%        z = 500 m
% [5] Takao et al. (2014) - TEA14
%       (a) for z = 50 m
%       (b) for z = 100 m
%       (c) for z = 250 m
%       (d) for z = 500 m
%        functional form 3
% There is no difference in evaluating the probability on the HW or on
% the FW for models 3-5.
% For models 4-5, coefficients revisited in Takao et al. (2016) are
% reported
% REVERSE
% [6] Moss et al. (2022) - MEA22
%   This model differs from the others. [Equation 5.5 in GIRS 2022]
%                           P(d>0) = exp(-a*r+b)
% Coefficients from [Table 5.3]

%%
function [P_slip_DR, warnings_Pslip_DR_AT, model_mag_range_DR, model_dist_range_DR] = P_rupt_site_DR(Dist_riv, Wall_type, Mcase, Pslip_DR_m, Dist_value, kinematicType, FaultName, folderPath)

warnings_Pslip_DR_AT = struct('id', {}, 'message', {}, 'values', {});
% Distances:
% Distances in km
for i = 1:numel(Dist_riv)
    max_values(i) = max(Dist_riv{i}(:));
end
max_dist = max(max_values);
r = 0.01:0.01:max_dist;

%%                              [1] YEA03
if strcmp(Pslip_DR_m, 'YEA03')
    % model info
    model_kinematics_DR = 'N';
    model_mag_range_DR = [5.5 7.4];
    model_dist_range_DR  = 15; % in km
    Pdsr_case = zeros(length(Mcase), length(r));
    Pdsrb_case = zeros(length(Mcase), length(r));
    % coefficients
    %         C1     C2     C3     C4    C5
    c_eq7 = [2.06, -4.62, 0.118, 0.682, 3.32];
    c_eq8 = [3.27, -8.28, 0.577, 0.629, 4.14, 0.611];

    if strcmp(Wall_type, 'FW')
        c_eq7(4) = 0;
        c_eq8(4) = 0;
    end
    % Eq. 7 - logistic regression
    for oo=1:length(Mcase)
        for f=1:length(r)
            fdsrHW_case=c_eq7(1)+(c_eq7(2)+c_eq7(3)*Mcase(oo)+c_eq7(4)).*log(r(f)+c_eq7(5));
            Pdsr_case(oo,f)=exp(fdsrHW_case)./(1+exp(fdsrHW_case));
        end
    end
    % Eq. 8 - with average random effect
    for oo=1:length(Mcase)
        for f=1:length(r)
            fdsrHWb_case=c_eq8(1)+(c_eq8(2)+c_eq8(3)*Mcase(oo)+c_eq8(4)).*log(r(f)+c_eq8(5));
            Pdsrb_case(oo,f)=exp(fdsrHWb_case)./(1+exp(fdsrHWb_case));
        end
    end


    %%                              [3] FL21
elseif any(strcmp(Pslip_DR_m, {'FL21_a', 'FL21_b'}))
    % model info
    model_kinematics_DR = 'N';
    model_mag_range_DR = [6.0 7.5];
    model_dist_range_DR  = 20; % in km
    if strcmp(Pslip_DR_m,'FL21_a')
        model_scenario_name = 'Regular Scenario';
        % coefficients
        %           |          Hw          |         FW          |
        %              C1       C2     C3     C1     C2      C3
        coeff_DR = [-2.254, -1.175, 1e-5, -3.459, -1.903, 1.008e-5];
    elseif strcmp(Pslip_DR_m,'FL21_b')
        model_scenario_name = 'Conservative Scenario';
        % coefficients
        %           |          Hw          |         FW          |
        %              C1       C2     C3     C1     C2      C3
        coeff_DR = [-1.888, -0.8802, 1.009e-5, -2.505, -1.181, 1.006e-5];
    end
    if strcmp(Wall_type, 'HW')
        % HANGING WALL
        fdsrHW_regcase=coeff_DR(1)+(coeff_DR(2).*log(r+coeff_DR(3)));
        P_slip_DR_full=exp(fdsrHW_regcase)./(1+exp(fdsrHW_regcase));
    elseif strcmp(Wall_type, 'FW')
        % FOOTWALL
        fdsrFW_regcase=coeff_DR(4)+(coeff_DR(5).*log(r+coeff_DR(6)));
        P_slip_DR_full=exp(fdsrFW_regcase)./(1+exp(fdsrFW_regcase));
    end


    %%                              [3] PEA11
elseif any(strcmp(Pslip_DR_m, {'PEA11_a', 'PEA11_b', 'PEA11_c', 'PEA11_d', 'PEA11_e'}))
    % model info
    model_kinematics_DR = 'SS';
    model_mag_range_DR = [6.5 7.6];
    model_dist_range_DR  = 2; % in km
    % Coefficients
    % Table 5 of Petersen et al (2011)
    if strcmp(Pslip_DR_m,'PEA11_a') % z = 25 m
        %              a       b     sigma
        coeff_DR = [-1.147, 2.1046, 1.2508];
        %                p0(%)   p1(%)   p2(%) r1(m) r2(m)
        coeff_interp = [74.541, 7.8690, 2.0108, 100, 200];

    elseif strcmp(Pslip_DR_m,'PEA11_b') % z = 50 m
        %              a       b     sigma
        coeff_DR = [-0.900, 0.9866, 1.1470];
        %                p0(%)   p1(%)   p2(%) r1(m) r2(m)
        coeff_interp = [87.162, 4.8206, 2.6177, 100, 200];

    elseif strcmp(Pslip_DR_m,'PEA11_c') % z = 100 m
        %              a       b     sigma
        coeff_DR = [-1.0114, 2.5572, 1.0917];
        %                p0(%)   p1(%)   p2(%) r1(m) r2(m)
        coeff_interp = [90.173, 18.523, 6.6354, 100, 200];

    elseif strcmp(Pslip_DR_m,'PEA11_d') % z = 150 m
        %              a       b     sigma
        coeff_DR = [-1.0934, 3.5526, 1.0188];
        %                p0(%)   p1(%)   p2(%) r1(m) r2(m)
        coeff_interp = [87.394, 19.592, 7.0477, 150, 300];

    elseif strcmp(Pslip_DR_m,'PEA11_e') % z = 200 m
        %              a       b     sigma
        coeff_DR = [-1.1538, 4.2342, 1.0177];
        %                p0(%)   p1(%)   p2(%) r1(m) r2(m)
        coeff_interp = [92.483, 18.975, 7.4709, 200, 400];
    end

    r_points = [10, coeff_interp(4), coeff_interp(5)];
    p_values = [coeff_interp(1)/100, coeff_interp(2)/100, coeff_interp(3)/100];
    r = r * 1000;
    for j = 1:length(r)
        if r(j) == 0
            P_slip_DR_full(j) = 1;
        elseif r(j) <= coeff_interp(5)
            P_slip_DR_full_int(j) = interp1(r_points, log(p_values), r(j));
            P_slip_DR_full(j) = exp(P_slip_DR_full_int(j));
        elseif r(j) > coeff_interp(5) %&& r(j) <= model_dist_max_DR*1000
            P_slip_DR_full(j) = exp(coeff_DR(1)*log(r(j)) + coeff_DR(2)); % r in m
            % elseif r(j) > model_dist_max_DR*1000
            %     P_slip_DR_full(j) = 0;
        end
    end
    r = r/1000;


    %%                              [4] TEA13
elseif strcmp(Pslip_DR_m, 'TEA13')
    % model info
    model_kinematics_DR = 'R-SS';
    model_mag_range_DR = [5.7 7.4];
    model_dist_range_DR  = 25; % in km
    % Coefficients
    %             C1      C2      C3    C4
    coeff_DR = [-3.839, -3.886, 0.350, 0.2];
    for ff=1:length(Mcase)
        for f=1:length(r)
            fdsr_case=coeff_DR(1)+(coeff_DR(2)+coeff_DR(3)*Mcase(ff)).*log(r(f)+coeff_DR(4));
            P_slip_DR_full(ff,f)=exp(fdsr_case)./(1+exp(fdsr_case));
        end
    end
    %%                              [5] TEA14
elseif any(strcmp(Pslip_DR_m, {'TEA14_a', 'TEA14_b', 'TEA14_c', 'TEA14_d'}))
    model_kinematics_DR = 'R-SS';
    model_mag_range_DR = [5.8 7.4];
    model_dist_range_DR  = 25; % in km
    % Coefficients
    if strcmp(Pslip_DR_m, 'TEA14_a') % 50 m
        %             C1      C2      C3
        coeff_DR = [-6.988, -1.410, 0.2];

    elseif strcmp(Pslip_DR_m, 'TEA14_b') % 100 m
        %             C1      C2     C3
        coeff_DR = [-6.135, -1.427, 0.2];

    elseif strcmp(Pslip_DR_m, 'TEA14_c') % 250 m
        %             C1      C2     C3
        coeff_DR = [-4.903, -1.459, 0.2];

    elseif strcmp(Pslip_DR_m, 'TEA14_d') % 500 m
        %             C1      C2     C3
        coeff_DR = [-3.859, -1.499, 0.2];
    end
    fdsr_case=coeff_DR(1)+(coeff_DR(2).*log(r+coeff_DR(3)));
    P_slip_DR_full=exp(fdsr_case)./(1+exp(fdsr_case));


    %%                              [6] MEA22
elseif strcmp(Pslip_DR_m, 'MEA22')
    % model info
    model_kinematics_DR = 'R';
    model_mag_range_DR = [6.0 7.9];
    model_dist_range_DR = 3.5; % in km

    % coefficients for the 85th percentile envelope
    %         a    b
    pd0_c = [2.2, 0.5; % Hw
        2.4, 0.4]; % Fw
    if strcmp(Wall_type, 'HW')
        % P(d>0)
        pd0HW = exp(-pd0_c(1,1) .* r + pd0_c(1,2)); % r in km
        pd0HW(pd0HW > 1.0) = 1.0;
        for h = 1:length(Mcase)
            for i = 1:length(r)
                P_slip_DR_full(h,i) = pd0HW(i);
            end
        end
    elseif strcmp(Wall_type, 'FW')
        % P(d>0)
        pd0FW = exp(-pd0_c(2,1) .* r + pd0_c(2,2)); % r in km
        pd0FW(pd0FW > 1.0) = 1.0;
        for h = 1:length(Mcase)
            for i = 1:length(r)
                P_slip_DR_full(h,i) = pd0FW(i);
            end
        end
    end

end


%% Check of the validity of the chosen model

% Reliability of the model kinematics
if any(strcmp(Pslip_DR_m, {'TEA13', 'TEA14_a', 'TEA14_b', 'TEA14_c', 'TEA14_d'}))
    if ~any(strcmp(kinematicType, {'R', 'SS'}))
        warning_id = 'MATLAB:InvalidKin';
        warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen P_DR_model.');
        disp(warning_msg)
        warnings_Pslip_DR_AT(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', []);
    end
else
    if ~strcmp(kinematicType, model_kinematics_DR)
        warning_id = 'MATLAB:InvalidKin';
        warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen P_DR_model.');
        disp(warning_msg)
        warnings_Pslip_DR_AT(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', []);
    end
end

% Reliability of the magnitude range
for mm = 1:length(Mcase)
    if Mcase(mm) < model_mag_range_DR(1) || Mcase(mm) > model_mag_range_DR(2)
        warning_id = 'MATLAB:InvalidMw';
        warning_msg = sprintf('The Mw = %.1f exceeds the valid range of the selected model (%.1f - %.1f). P(d>d0) will be an extrapolation.', Mcase(mm), model_mag_range_DR(1), model_mag_range_DR(2));
        disp(warning_msg)
        warnings_Pslip_DR_AT(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', Mcase(mm));
    end
end


%% Evaluation of the site-specific probabilities for DR from input data
P_slip_DR = cell(size(Dist_riv));

% Site_specific P_slip_DR
for oo = 1:size(Dist_riv, 1) % for each Mcase
    for idx_xL = 1:size(Dist_riv, 2) % for each xL_value
        current_dist = Dist_riv{oo, idx_xL};
        n_combinations = size(current_dist, 1); % counting the possible
        % combinations in the location of the floating rupture (which is
        % function of the Mw). In case of no floating, just 1 rupture
        % including the entire fault trace is considered

        P_slip_DR_temp = zeros(n_combinations, length(Dist_value));

        for row_idx = 1:n_combinations % for each combination
            % if the distances exceed model_dist_max_DR,
            % the P_slip_DR must be considered as an
            % extrapolation

            valid_indices = current_dist(row_idx, :) <= model_dist_range_DR;
            if any(~valid_indices)
                invalid_distances = current_dist(row_idx, ~valid_indices);
                P_slip_DR_temp(row_idx, ~valid_indices) = 0;

                % Reliability of the max distance
                warning_id = 'MATLAB:DistanceExceeds';
                warning_msg = sprintf(['Rivaluated distance = [%s] km exceeds the valid range of the selected model (up to %.1f km from PF). ' ...
                    'P(d>d0) will be an extrapolation.'], num2str(invalid_distances, '%.1f '), model_dist_range_DR);
                disp(warning_msg)
                warnings_Pslip_DR_AT(end+1) = struct('id', warning_id, ...
                    'message', warning_msg, ...
                    'values', invalid_distances);
            end

            idx_r = arrayfun(@(val) find(abs(r - val) == min(abs(r - val)), 1), current_dist(row_idx, :));

            for dist_idx = 1:size(current_dist,2)
                if strcmp(Pslip_DR_m, 'YEA03')
                    P_slip_DR_temp(row_idx, dist_idx) = ...
                        0.5 * Pdsr_case(oo, idx_r(dist_idx)) + 0.5 * Pdsrb_case(oo, idx_r(dist_idx));
                else
                    P_slip_DR_temp(row_idx, dist_idx) = P_slip_DR_full(idx_r);
                end

            end
            P_slip_DR{oo, idx_xL} = P_slip_DR_temp;
        end

        P_slip_DR{oo, idx_xL} = P_slip_DR_temp;
    end
end


%% Plot figures

figure()
hold on
if strcmp(Pslip_DR_m, 'YEA03')
    h1 = plot(r, Pdsr_case', '-k', 'LineWidth', 1);
    h2 = plot(r, Pdsrb_case', '--k', 'LineWidth', 1.5);
    h3 = xline(Dist_value, 'Color', [0.65 0.65 0.65], 'LineWidth', 3.5);
    legend([h1(1), h2(1), h3(1)], {'Equation 7', 'Equation 8', 'Site location'})
else
    h1 = plot(r, P_slip_DR_full', '-k', 'LineWidth', 1.5);
    h2 = xline(Dist_value, 'Color', [0.65 0.65 0.65], 'LineWidth', 3.5);
    if any(strcmp(Pslip_DR_m, {'FL21_a', 'FL21_b'}))
        legend([h1(1), h2(1)], { model_scenario_name, 'Site location'})
    elseif any(strcmp(Pslip_DR_m, {'PEA11_a', 'PEA11_b', 'PEA11_c', 'PEA11_d', 'PEA11_e'}))
        legend([h1(1), h2(1)], { '50^{th} percentile', 'Site location'})
    elseif any(strcmp(Pslip_DR_m, {'TEA13', 'TEA14_a', 'TEA14_b', 'TEA14_c', 'TEA14_d'}))
        legend([h1(1), h2(1)], {'90^{th} percentile', 'Site location'})
    elseif strcmp(Pslip_DR_m, 'MEA22')
        legend([h1(1), h2(1)], {'85^{th} percentile', 'Site location'})
    end
end
ylim([0.001 1])
if max_dist > model_dist_range_DR
    xlim([0 model_dist_range_DR])
else
end
set(gca,'Yscale','log')
xlabel('Distance (km)')
ylabel('Probability of Distributed Surface Ruptures')
title([Pslip_DR_m ' - ' Wall_type])
legend('show')
hold off

saveas(gcf, fullfile(folderPath, ['Probability_rupture_at_site_DR_' FaultName '.fig']));

end