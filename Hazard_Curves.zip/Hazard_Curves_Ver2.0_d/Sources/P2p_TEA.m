%% P2p from Takao et al. (2013)
% The length of the surface earthquake fault does not necessarily
% corresponds to that of the earthquake source fault.
% The authors investigated the ratio between these two lengths, finding
% a relationship between this ratio and Mw formulated by four
% tri-linear models. The occurrence probability of each model is assumed
% to be the same (0.25).

% If a principal fault occurs, the probability P2p of fault displacement
% at position x can be calculated considering:
%%% a) nf: Number of source fault configurations relative to the fault zone
%          (length of active fault which is estimated by Takemura, 1998
%           equations with respect to the fault length we selected as input)
%%% b) lp: Number of main fault segment alignments for each source fault
%          alignment (surface rupture segments legths)
%%% c) I(Slip|xn, Ll): The function is set to 1 if the lth main fault
%          segment (length Ll) includes the evaluation point xn (fault
%          displacement occurs), and is set to 0 if it does not (no fault
%          displacement occurs).

% Please refers to the authors for a complete explication of the method.
% Be careful because the models have been generated analyzing JAPANESE
% EARTHQUAKES ONLY. Therefore, the regressions may not be suitable out of
% this geographic area!


function [P_2p,P_3p,configurations,nf,Ll_cases,lp_tot,lp_p] = P2p_TEA(Length, Mcase, xL_value, FaultName, folderPath, magnitudes, displacement_levels, P_exceedance_full, Displ_type, x_axis_displacement, D_perc, p_Displ,P_D_model)

% evaluation point (in this case, each point along the PF)
L = floor(Length); % it represents the total length of the domain in which
% the fault source length derived from Takemura (1998) equation will be traslated
x_n =  xL_value .* L; % in km
num_x_n = length(x_n);

RLD = zeros(size(Mcase));         % Fault source length [km]
nf = zeros(size(Mcase));          % number of configurations for each Mcase
configurations = cell(size(Mcase));      % configurations

% Scaling law from Takemura (1998)
for w = 1:length(Mcase)
    if Mcase(w) > 6.8
        RLD(w) = round(10.^(0.6.*Mcase(w) - 2.97));
    else
        RLD(w) = round(10.^(0.4.*Mcase(w) - 1.38));
    end

    if RLD(w) >= L
        nf(w) = 1;
        configurations{w} = [0, L]; % just one configuration
    else
        start_pos = 0:(L - RLD(w)); % segment beginning
        % end_pos   = start_pos + RLD(w); % segment ending

        nf(w) = numel(start_pos);
        confs = cell(nf(w),1);
        for k = 1:nf(w)
            confs{k} = start_pos(k):1:(start_pos(k) + RLD(w));
        end

        % each row corresponds to a configuration array (padding with NaN if needed)
        maxLen = RLD(w) + 1; % row length
        mat = nan(nf(w), maxLen);
        for k = 1:nf(w)
            vec = confs{k};
            mat(k,1:numel(vec)) = vec;
        end
        configurations{w} = mat;
    end

end


% P_2p = zeros(length(x_n), length(Mcase));


%% Definition of the four tri-linear models from Takao et al. (2013)
f1 = zeros(size(magnitudes));
f2 = zeros(size(magnitudes));
f3 = zeros(size(magnitudes));
f4 = zeros(size(magnitudes));

% F1
for i = 1:length(magnitudes)
    if magnitudes(i) <= 6.8
        f1(i) = 5;
    elseif magnitudes(i) > 6.8 && magnitudes(i) <= 7.5
        f1(i) = 135.71 * magnitudes(i) - 917.86;
    else
        f1(i) = 100;
    end
end

% F2
for i = 1:length(magnitudes)
    if magnitudes(i) <= 6.5
        f2(i) = 20;
    elseif magnitudes(i) > 6.5 && magnitudes(i) <= 7.2
        f2(i) = 114.29 * magnitudes(i) - 722.86;
    else
        f2(i) = 100;
    end
end

% F3
for i = 1:length(magnitudes)
    if magnitudes(i) <= 6.2
        f3(i) = 35;
    elseif magnitudes(i) > 6.2 && magnitudes(i) <= 6.9
        f3(i) = 92.86 * magnitudes(i) - 540.71;
    else
        f3(i) = 100;
    end
end

% F4
for i = 1:length(magnitudes)
    if magnitudes(i) <= 5.9
        f4(i) = 50;
    elseif magnitudes(i) > 5.9 && magnitudes(i) <= 6.6
        f4(i) = 71.43 * magnitudes(i) - 371.43;
    else
        f4(i) = 100;
    end
end

Ls_Lm = [f1; f2; f3; f4];

%% Estimation of the segments length as function of Mcase interpoling the four
%% tri-linear models
Ls_Lm_case = interp1(magnitudes, Ls_Lm', Mcase);

figure()
plot(magnitudes, Ls_Lm', '--k')
hold on
plot(Mcase, Ls_Lm_case, 'ko', 'MarkerFaceColor', [0.65 0.65 0.65], 'LineWidth', 1.5)
xlim([5 8]);
ylim([0 100]);
ylabel('Ls/Lm (%)'); xlabel('Magnitude (Mw)');
title('Ratio of fault segments length to the source fault length')
hold off

saveas(gcf, fullfile(folderPath, ['Ls_Lm_Mw_Takao' FaultName '.fig']));


Ll_cases = L * Ls_Lm_case / 100;  % 4 values of segment lengths
% lp_tot = zeros(1, length(Ll_cases));
% lp_p = zeros(nf, length(lp_tot), length(x_n));


%% Evaluating the conditional probability of exceedance (P3p) in case Ll<10 km
% it is evaluated only when choosing TEA13 as model for the estimation of P_exceedance

if strcmp(P_D_model, 'TEA13')
    if Displ_type == 1 % If AD
        D_models = D_AD_models();
    elseif Displ_type == 2 % If MD
        D_models = D_MD_models();
    end

    a_gamma_b = D_models(4).a;
    b_gamma_b = D_models(4).b;
    chosen_function_b = D_models(4).function;
    scenario_tea13_b = cdf(chosen_function_b, D_perc, a_gamma_b, b_gamma_b);
    n=1; P2 = []; P3 = []; P_exceedance_full_b = [];

    for m = 1: size(p_Displ,1) % M
        for g = 1:size(scenario_tea13_b,1) % x/l


            for i =1:length(p_Displ(m,:)) % probability of having a specific AD value as function of M
                D_assoluto =  x_axis_displacement(i) .* D_perc;

                for h = 1:length(displacement_levels)
                    P_non_exceedance = find(D_assoluto < displacement_levels(h),1,"last"); % Explore the Probability of Non-Exceedance
                    if isempty(P_non_exceedance)
                        P_non_exceedance=1;
                    end

                    P2(i,h) =  (1-scenario_tea13_b(g,P_non_exceedance)); % P of exceedance = 1 - P non-exceedance

                end
                P3(i,:) = p_Displ(m,i) .* P2(i,:);
            end

            P_exceedance_full_b(n,:) = sum(P3,1); % the first 100 rows
            % (corresponding to the 100 values ​​of x/L) refer to the first magnitude
            % of Mcase, the second 100 to the second value of Mcase etc., while the
            % number of columns depends on the length of displacement_levels

            n=n+1;
        end
    end
end

%% Estimating P2p and P3p
num_scenarios = size(Ll_cases, 1);

lp_tot = zeros(num_scenarios, size(Ll_cases, 2));
lp_p = cell(num_scenarios,1);
x_over_L_riv = cell(length(Mcase), 4);  % x/L revalued on rupture length
P_3p_temp = cell(length(Mcase), 4, length(xL_value)); % conditional probability of exceedance from Takao et al., 2013


%% Estimating P2p and P3p
num_scenarios = size(Ll_cases, 1);

lp_tot = zeros(num_scenarios, size(Ll_cases, 2));
lp_p = cell(num_scenarios,1);
x_over_L_riv = cell(length(Mcase), size(Ll_cases, 2));  % x/L revalued on rupture length
P_3p_temp = cell(length(Mcase), size(Ll_cases, 2), num_x_n); % conditional probability of exceedance (Takao et al., 2013)

for scenario_idx = 1:num_scenarios

    Ll_case_scenario = Ll_cases(scenario_idx, :);
    lp_p{scenario_idx} = zeros(nf(scenario_idx), size(Ll_cases, 2), length(x_n));
    % Preallocate with NaN only for the number of translations
    x_over_L_riv{scenario_idx, 4} = NaN(nf(scenario_idx), num_x_n);

    % Preparing counter of rows to explore P_exceedance_full
    row_start = (scenario_idx - 1) * num_x_n + 1;
    row_end   = scenario_idx * num_x_n;

    for case_idx = 1:length(Ll_case_scenario)

        Ll = Ll_case_scenario(case_idx);  % Ll of the current segment
        if Ll > L
            Ll = L;
        end

        % Number of positions along the fault trace to make the rupture translate
        % start_positions = 0:1:nf(scenario_idx);
        % num_positions = length(start_positions);  % Number of valid translations,
        % where the segment is completely within the fault
        num_positions = floor(length(nf(scenario_idx)) - Ll);
        temp_matrix = NaN(nf(scenario_idx), num_positions, length(displacement_levels), num_x_n);

        % loop sulle configurazioni della faglia
        for config_idx = 1:nf(scenario_idx)

            conf_row = configurations{scenario_idx}(config_idx, :);
            conf_row = conf_row(~isnan(conf_row));
            conf_start = conf_row(1);
            conf_end   = conf_row(end);

            max_start_pos = conf_end - Ll; % max possible locations for the segment

            % num_positions = floor(max_start_pos) - conf_start;
            % temp_matrix = NaN(nf(scenario_idx), num_positions, length(displacement_levels), num_x_n);

            if max_start_pos < conf_start
                lp = 1;
            else
                lp = max_start_pos - conf_start + 1;
            end
            lp_tot(scenario_idx, case_idx) = lp;

            for loc_idx = 1:num_x_n

                for i = 0:(lp-1)
                    start_segment = conf_start + i;
                    end_segment   = start_segment + Ll;

                    dist_from_start = x_n(loc_idx) - start_segment;
                    dist_from_end   = end_segment - x_n(loc_idx);
                    min_dist = min(dist_from_start, dist_from_end);

                    if start_segment <= x_n(loc_idx) && end_segment >= x_n(loc_idx)

                        lp_p{scenario_idx}(config_idx,case_idx, loc_idx) = ...
                            lp_p{scenario_idx}(config_idx,case_idx, loc_idx) + 1;

                        if strcmp(P_D_model, 'TEA13')
                            x_over_L_value = min_dist / Ll;
                            x_over_L_value = max(x_over_L_value, 0.005);  % valore minimo

                            x_over_L_riv{scenario_idx,case_idx}(config_idx, loc_idx) = x_over_L_value;

                            if Ll < 10
                                temp_matrix(config_idx, i+1, :, loc_idx) = P_exceedance_full_b(scenario_idx,:);
                            else
                                [~, idx_closest] = min(abs(xL_value - x_over_L_value));
                                if idx_closest >= 1 && idx_closest <= length(xL_value)
                                    P_exc_row = P_exceedance_full(row_start + (idx_closest - 1), :);
                                    temp_matrix(config_idx, i+1, :, loc_idx) = P_exc_row;
                                end
                            end
                        end
                    else
                        if strcmp(P_D_model, 'TEA13')

                            % x_over_L_value = min_dist / Ll;
                            % if x_over_L_value < 0.005
                            x_over_L_value = NaN;
                            x_over_L_riv{scenario_idx,case_idx}(config_idx, loc_idx) = x_over_L_value;

                            % end
                            if isnan(x_over_L_value)
                                temp_matrix(config_idx,i+1, :, loc_idx) = NaN;
                            end
                        end
                    end
                end % end i-loop
                if strcmp(P_D_model, 'TEA13')
                    P_3p_temp{scenario_idx, case_idx, loc_idx} = temp_matrix(:,:,:, loc_idx);
                end
            end % end loc_idx-loop
        end % end config_idx-loop

        % for col_idx = 1:length(xL_value)
        % end

    end % end case_idx-loop
end % end scenario_idx-loop



% Assessment of the P2p
P_2p = zeros(length(Mcase),length(x_n));

for scenario_idx = 1:num_scenarios
    for loc_idx = 1:length(x_n)
        for n = 1:nf(scenario_idx)
            internal_sum = sum(lp_p{scenario_idx}(n, :, loc_idx) ./ lp_tot(scenario_idx, :));
            P_2p(scenario_idx,loc_idx) = P_2p(scenario_idx,loc_idx) + (1 / nf(scenario_idx)) * (internal_sum * 0.25);
        end
    end
end


% Assessment of the P3p
P_3p = cell(length(Mcase), num_x_n);

if strcmp(P_D_model, 'TEA13')
    for scenario_idx = 1:length(Mcase)
        for loc_idx = 1:num_x_n

            % accumulatore per i 4 casi di Ll
            sum_over_cases = [];

            for case_idx = 1:size(Ll_cases, 2)
                temp_matrix = P_3p_temp{scenario_idx, case_idx, loc_idx};

                if isempty(temp_matrix)
                    continue;
                end

                % Metto a 0 i NaN
                temp_matrix(isnan(temp_matrix)) = 0;

                % ---- 1a somma: su tutte le traslazioni valide ----
                % (num_configurazioni x 50), divisa per lp_tot
                sum_over_transl = squeeze(sum(temp_matrix, 2)) ./ lp_tot(scenario_idx, case_idx);

                % Accumulo il contributo di questo caso di Ll
                if isempty(sum_over_cases)
                    sum_over_cases = sum_over_transl;
                else
                    sum_over_cases = sum_over_cases + sum_over_transl;
                end
            end

            % ---- 2a somma: su tutte le configurazioni ----
            % Ora faccio la media dividendo per nf(scenario_idx)
            if length(scenario_idx)>1
                P_3p{scenario_idx, loc_idx} = ((1 / nf(scenario_idx)) * (sum(sum_over_cases, 1)* 0.25))';
            else
                P_3p{scenario_idx, loc_idx} = ((1 / nf(scenario_idx)) * (sum_over_cases * 0.25))';
            end
        end
    end
end


end