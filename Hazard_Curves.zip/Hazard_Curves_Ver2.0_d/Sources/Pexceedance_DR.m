%% %%%  Conditional probability of exceedance Pkn(d>d_0|m,r,Slip)  %%% %% 
%% %%%                  for distributed ruptures                   %%% %%

% Currently, the routine supports the following models:
% - Youngs et al. (2003) - YEA03
% - Petersen et al. (2011) [log(D) approach] - PEA11
% - Takao et al. (2013) - TEA13
% - Takao et al. (2014) - TEA14
% - Moss et al. (2022) [from GIRS-2022-05_REV_2024] - MEA22

% All these models are stored within Pexceedance_DR_model. Only PEA11 and
% PEA23 are an exception, as they relies on different approaches. 
% Please, refers to the original papers for more details. 
% For TEA models, 
% updated coefficients from Takao et al. (2016) are used.

% Here a brief description of the supported models is reported:

%%                 'YEA03' - 'TEA13' - 'TEA14' - 'MEA22'
%   The authors propose to fit the distribution of possible 
%   displacements that may occur on a distributed rupture (in the 
%   range of the 85th to 95th percentile of the distribution for 
%   Largest d/MD for YEA03, 90th for TEA13; 90th for d/AD for TEA13 and TEA14) 
%   with a gamma distribution. It is based on the equation:
%              Largest d/MD (or AD) = coeff1 * exp(-coeff2 * r)
%   The shape parameters, a and b at a given 
%   distance from the principal rupture are stored within Pexceedance_DR_model. 
%   Then, for YEA03, TEA13 and TEA14 the conditional probability is 
%   evaluated by convolving this with the log-normal distribution of the MD
%   on the PF. For MEA22, on the other hand, this ratio is used to scale
%   the PF hazard curve (see the original code in Appendix C of
%   GIRS-2022-05_REV_2024). 

%%                               'PEA11'
%   the authors derive the following power function: 
%             i)      ln(d) = 1.4016Mw-0.1671ln(r)-6.79971
%             ii)        ln(d/AD) = -0.1826ln(r)-1.5471
%   where d is in cm and r is in m. The standard deviations of are 1.1193 
%   and 1.1388 in ln unit, respectively. 
%   Only the first function is here implemented.
%   They employ the log-normal distribution, the standard deviation of which 
%   is 1.1388 in ln unit, to express the uncertainty of d/AD since they 
%   used the power function for the distance attenuation equation. No numerical 
%   convolution is needed. 

%%

function [P_exceedance_DR, warnings_DR_AT, Pexc_model_mag_range_DR, Pexc_model_dist_range_DR,P_exc_model_coefficients_DR] = Pexceedance_DR(x_axis_displacement, displacement_levels, Dist_riv, p_Displ, D_perc, d_truncation, Pexc_DR_m, Wall_type, Mcase, Dist_value, kinematicType, FaultName, folderPath)

warnings_DR_AT = struct('id', {}, 'message', {}, 'values', {});

% Distances:
% Distances in km
for i = 1:numel(Dist_riv)
    max_values(i) = max(Dist_riv{i}(:)); 
end
max_dist = max(max_values);
r = 0.01:0.01:max_dist;

%%                     'YEA03' - 'TEA13' - 'TEA14'                    %%
if any(strcmp(Pexc_DR_m, {'YEA03_a', 'YEA03_b','TEA13_a', 'TEA13_b', 'TEA14', 'MEA22_a', 'MEA22_b'}))  
        Pexc_DR_models = Pexceedance_DR_models();
[Pexc_Index] = getP_excCoefficients(Pexc_DR_models, Pexc_DR_m); % find the chosen model

% model info
Pexc_model_kinematics_DR = Pexc_DR_models(Pexc_Index).kinematics;
Pexc_model_mag_range_DR = Pexc_DR_models(Pexc_Index).range;
Pexc_model_dist_range_DR  = Pexc_DR_models(Pexc_Index).maxdist; % in km
Pexc_model_percentiles_coeff = Pexc_DR_models(Pexc_Index).percentiles_coeff; % [a b]
Pexc_model_dtype = Pexc_DR_models(Pexc_Index).dtype; 

if any(strcmp(Pexc_DR_m, {'YEA03_a','YEA03_b','MEA22_a','MEA22_b'}))
    if strcmp(Wall_type, 'HW')
        P_exc_model_coefficients_DR = Pexc_DR_models(Pexc_Index).coefficients(1,:);
    elseif strcmp(Wall_type, 'FW')
        P_exc_model_coefficients_DR = Pexc_DR_models(Pexc_Index).coefficients(2,:);
    end
elseif any(strcmp(Pexc_DR_m, {'TEA13_a', 'TEA13_b', 'TEA14'}))
    P_exc_model_coefficients_DR = Pexc_DR_models(Pexc_Index).coefficients;
end 


    if any(strcmp(Pexc_DR_m, {'YEA03_a', 'YEA03_b'})) 

        D_Mw_scaling_rel = Mw_MD_regressions();
        idx = find(strcmp({D_Mw_scaling_rel.name}, 'WC94-N'));
        selected_relation = D_Mw_scaling_rel(idx);
        coefficients = selected_relation.coefficients;
        sigma_max = selected_relation.sigma;
        D_relation_max = coefficients(1) + coefficients(2).*Mcase;
        for i = 1:length(Mcase)
            if ~isempty(d_truncation) && ~isnan(d_truncation)
                pd_max (i) = makedist('Normal','mu',D_relation_max(i),'sigma',sigma_max);
                pd_trunc_max (i)= truncate(pd_max(i),(D_relation_max(i))-(d_truncation*sigma_max),(D_relation_max(i))+(d_truncation*sigma_max));
                p_Displ_max(i,:) = pdf(pd_trunc_max(i),log10(x_axis_displacement));
                p_Displ_max(i,:) = p_Displ_max(i,:)./sum(p_Displ_max(i,:));
            else
                p_Displ_max(i,:) = pdf("normal",log10(x_axis_displacement),D_relation_max(i),sigma_max);
                p_Displ_max(i,:) = p_Displ_max(i,:)./sum(p_Displ_max(i,:));
            end
        end
    elseif any(strcmp(Pexc_DR_m, {'TEA13_a', 'TEA13_b', 'TEA14'}))  
        p_Displ_max = p_Displ;
    end

    % Evaluation of the [Largest d]/[MD] ratio distribution as a
    % function of the distance from the PF

    % Distribution for the Hanging Wall
    Ddr = P_exc_model_coefficients_DR(1)*exp(P_exc_model_coefficients_DR(2).*r);
    
    if any(strcmp(Pexc_DR_m, {'YEA03_a', 'YEA03_b', 'TEA13_a', 'TEA13_b', 'TEA14'}))
        for i = 1:length(Ddr)
            a_scenario = Pexc_model_percentiles_coeff(1);
            b_scenario = Ddr(i)/Pexc_model_percentiles_coeff(2);
            scenario_DR(i,:) = cdf("Gamma",D_perc,a_scenario,b_scenario);
        end

        n=1; P9=[]; P10 =[]; P_exceedance_DR_full = [];
        for m = 1: size(p_Displ_max,1)
            for g = 1:size(scenario_DR,1)

                for i =1:length(p_Displ_max(m,:)) % for each probability of having a certain MD as a function of M

                    D_AD_assoluto =  x_axis_displacement(i) .* D_perc;

                    for j = 1:length(displacement_levels)
                        P_non_exceedance_DR = find(D_AD_assoluto < displacement_levels(j),1,"last");
                        if isempty(P_non_exceedance_DR)
                            P_non_exceedance_DR=1;
                        end
                        P9(i,j) =  (1-scenario_DR(g,P_non_exceedance_DR));

                    end
                    P10(i,:) = p_Displ_max(m,i) .* P9(i,:);
                end

                P_exceedance_DR_full(n,:) = sum(P10,1);
                n=n+1;
            end
        end
    end

%%                               'PEA11'                                %%
elseif strcmp(Pexc_DR_m,'PEA11')
    Pexc_model_kinematics_DR = 'SS';
    Pexc_model_mag_range_DR = [6.5 7.6];
    Pexc_model_dist_range_DR  = 2; % in km
    Pexc_model_dtype = 'AD';
    P_exc_model_coefficients_DR = [];

    r = r*1000; % here is in m
    displ_sigma = 1.1193;
    for m = 1:length(Mcase)
        for j = 1:length(r)
            displ_scenario(m,j) = log(exp(1.4016.*Mcase(m)-0.1671.*log(r(j))-6.79971)/100); % d in cm ---> m, r in m
        end
    end

    Ddr = displ_scenario;
    sqrt2 = sqrt(2);
    index_3 = 1;
    for m = 1:length(Mcase)
        for j = 1:length(r)
            for i = 1:length(displacement_levels)
                temp1 = (displ_scenario(m, j) - log(displacement_levels(i))) / (displ_sigma * sqrt2); % PDF
                P_exceedance_DR_full(index_3, i) = (erf(temp1) + 1) / 2; % CDF
            end
            index_3 = index_3 + 1;
        end
    end
    r = r/1000;

end

%% Check of the validity of the chosen model

% Reliability of the model kinematics
if any(strcmp(Pexc_DR_m, {'TEA13_a', 'TEA13_b', 'TEA14'}))
    if ~any(strcmp(kinematicType, {'R', 'SS'}))
        warning_id = 'MATLAB:InvalidKin';
        warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen Pexceedance_DR_model.');
        disp(warning_msg)
        warnings_DR_AT(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', []);
    end
else
    if ~strcmp(kinematicType, Pexc_model_kinematics_DR)
        warning_id = 'MATLAB:InvalidKin';
        warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen Pexceedance_DR_model.');
        disp(warning_msg)
        warnings_DR_AT(end+1) = struct('id', warning_id, ...
            'message', warning_msg, ...
            'values', []);
    end
end

% Reliability of the magnitude range
for mm = 1:length(Mcase)
    if Mcase(mm) < Pexc_model_mag_range_DR(1) || Mcase(mm) > Pexc_model_mag_range_DR(2) 
        warning_id = 'MATLAB:InvalidMw';
        warning_msg = sprintf('The Mw = %.1f exceeds the valid range of the selected model (%.1f - %.1f). P(d>d0) will be an extrapolation.', Mcase(mm), Pexc_model_mag_range_DR(1), Pexc_model_mag_range_DR(2));
        disp(warning_msg)
        warnings_DR_AT(end+1) = struct('id', warning_id, ...
                                 'message', warning_msg, ...
                                 'values', Mcase(mm));
    end
end


%% Evaluation of the site-specific probabilities for DR from input data

if any(strcmp(Pexc_DR_m, {'MEA22_a','MEA22_b'}))
    P_exceedance_DR = Ddr;
else
    P_exceedance_DR = cell(size(Dist_riv));

    clear oo; clear idx_xL; clear row_idx; clear dist_idx;

    % Site_specific P_exceedance_DR
    for oo = 1:size(Dist_riv, 1) % for each Mcase
        for idx_xL = 1:size(Dist_riv, 2) % for each xL_value
            current_dist = Dist_riv{oo, idx_xL};
            n_combinations = size(current_dist, 1); % counting the possible
            % combinations in the location of the floating rupture (which is
            % function of the Mw). In case of no floating, just 1 rupture
            % including the entire fault trace is considered

            P_exceedance_DR_temp = zeros(n_combinations, length(Dist_value), length(displacement_levels));

            for row_idx = 1:n_combinations % for each combination
                % if the distances exceed model_dist_max_DR,
                % P_exceedance_DR must be considered as an extrapolation

                valid_indices = current_dist(row_idx, :) <= Pexc_model_dist_range_DR;
                if any(~valid_indices)
                    invalid_distances = current_dist(row_idx, ~valid_indices);
                    P_exceedance_DR_temp(row_idx, ~valid_indices, :) = 0;

                    % Reliability of the max distance
                    warning_id = 'MATLAB:DistanceExceeds';
                    warning_msg = sprintf(['Rivaluated distance = [%s] km exceeds the valid range of the selected model (up to %.1f km from PF). ' ...
                        'P(d>d0) will be an extrapolation.'], num2str(invalid_distances, '%.1f '), Pexc_model_dist_range_DR);
                    disp(warning_msg)
                    warnings_DR_AT(end+1) = struct('id', warning_id, ...
                        'message', warning_msg, ...
                        'values', invalid_distances);
                end

                idx_r = arrayfun(@(val) find(abs(r - val) == min(abs(r - val)), 1), current_dist(row_idx, :));

                for dist_idx = 1:size(current_dist,2)
                    % P_exceedance_DR_temp(row_idx, dist_idx, :) = P_exceedance_DR_full(idx_r(dist_idx), :);
                    correct_idx = (oo - 1) * length(r) + idx_r(dist_idx);
                    P_exceedance_DR_temp(row_idx, dist_idx, :) = P_exceedance_DR_full(correct_idx, :);

                end

            end

            P_exceedance_DR{oo, idx_xL} = P_exceedance_DR_temp;
        end
    end
end

%% Plot figures

figure()
hold on
h4 = plot(r, Ddr', '-k', 'LineWidth', 1.5);
h5 = xline(Dist_value, 'Color', [0.65 0.65 0.65], 'LineWidth', 3.5);
if any(strcmp(Pexc_DR_m, {'YEA03_a', 'YEA03_b'}))
    legend([h4(1), h5(1)], {'From 85 to 95^{th} percentile', 'Site location'})
elseif any(strcmp(Pexc_DR_m, {'TEA13_a', 'TEA13_b', 'TEA14'}))
    legend([h4(1), h5(1)], {'90^{th} percentile', 'Site location'})
elseif any(strcmp(Pexc_DR_m, {'MEA22_a', 'MEA22_b'}))
    legend([h4(1), h5(1)], {'85^{th} percentile', 'Site location'})
elseif strcmp(Pexc_DR_m,'PEA11')   
    legend([h4(1), h5(1)], {'50^{th} percentile', 'Site location'})
end

if max_dist > Pexc_model_dist_range_DR
    xlim([0 Pexc_model_dist_range_DR])
else
end

xlabel('Distance (km)')
ylabel(['Largest D_{distributed} / ' Pexc_model_dtype '_{principal}'])
title([Pexc_DR_m ' - ' Wall_type])
legend('show')
hold off

saveas(gcf, fullfile(folderPath, ['P_exceedance_DR_' FaultName '.fig']));

%%
function [Pexc_Index] = getP_excCoefficients(Pexc_DR_models, Pexc_DR_m) % find the chosen model
    
    Pexc_Index = [];

    for h = 1:length(Pexc_DR_models)
        if strcmp(Pexc_DR_models(h).name, Pexc_DR_m)
            Pexc_Index = h;
            return; 
        end
    end

    if isempty(Pexc_Index)
        error('Model not found. Please, insert a valid name for the Conditional Probability of exceedance for DR');
    end
end

%%
end