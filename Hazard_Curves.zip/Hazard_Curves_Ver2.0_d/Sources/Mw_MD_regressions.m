%% Available scaling relations between Mw and MD

% Here we define a structure including all the scaling relations available
% in the scientific literature specifically between Mw and Maximum
% Displacement (MD), generally evaluated with the following equation:
                            % log(D) = a+b*Mw

% The main authors are listed below, while the corresponding model number 
% is reported within ():

%% Wells & Coppersmith (1994) - WC94
% the authors provide regressions for the whole dataset (all slip type - 1)
% and also for single kinematics type, subdividing the earthquakes into
% normal (2), reverse (3) and strike-slip faults (6). 
% Be careful because the regression for reverse faults is not
% statistically consistent.

%% Moss et al. (2022) - MEA22
% the authors focus only on reverse faulting (4).

%% Takao et al. (2013) - TEA13
% the authors analyze jointly both reverse and strike-slip faults in the 
% Japan. Be careful because this regression may not be suitable out of this 
% geographic area (5).

%%
function D_Mw_scaling_rel = Mw_MD_regressions()
D_Mw_scaling_rel = struct(); % initializing the structure for Mw-MD scaling relations

D_Mw_scaling_rel(1).name = 'WC94-A';
D_Mw_scaling_rel(1).kinematics = 'All';
D_Mw_scaling_rel(1).coefficients = [-5.46 0.82]; % [a b]
D_Mw_scaling_rel(1).sigma = 0.42;
D_Mw_scaling_rel(1).range = [5.2 8.1];

D_Mw_scaling_rel(2).name = 'WC94-N';
D_Mw_scaling_rel(2).kinematics = 'N';
D_Mw_scaling_rel(2).coefficients = [-5.9 0.89];
D_Mw_scaling_rel(2).sigma = 0.38;
D_Mw_scaling_rel(2).range = [5.2 7.3];

D_Mw_scaling_rel(3).name = 'WC94-R'; % Warning! not statistically consistent
D_Mw_scaling_rel(3).kinematics = 'R';
D_Mw_scaling_rel(3).coefficients = [-1.84 0.29];
D_Mw_scaling_rel(3).sigma = 0.42;
D_Mw_scaling_rel(3).range = [5.4 7.4];

D_Mw_scaling_rel(4).name = 'MEA22';
D_Mw_scaling_rel(4).kinematics = 'R';
D_Mw_scaling_rel(4).coefficients = [-2.50 0.415];
D_Mw_scaling_rel(4).sigma = 0.2;
D_Mw_scaling_rel(4).range = [4.7 8.02];

D_Mw_scaling_rel(5).name = 'TEA13';
D_Mw_scaling_rel(5).kinematics = 'R-SS';
D_Mw_scaling_rel(5).coefficients = [-5.16 0.82];
D_Mw_scaling_rel(5).sigma = 0.148;
D_Mw_scaling_rel(5).range = [5.8 7.4];

D_Mw_scaling_rel(6).name = 'WC94-S';
D_Mw_scaling_rel(6).kinematics = 'SS';
D_Mw_scaling_rel(6).coefficients = [-7.03 1.03];
D_Mw_scaling_rel(6).sigma = 0.42;
D_Mw_scaling_rel(6).range = [5.6 8.1];


% Save the structure 
% save('MD_Mw_scaling_rel.mat', "D_Mw_scaling_rel", '-mat')

end