%% Conditional Probability of Surface Rupture Pslip(m|r) for Principal Faulting
% It is the first term of the attenuation law representing the 
% empirical approach to compute the conditional probability that the 
% rupture will reach the surface. The probability of a positive outcome 
% (the occurrence of principal surface rupture given the occurrence of 
% the earthquake) is given by the expression documented by 
% Wells & Coppersmith (1993)
%                 P_slip = exp(f_x) ./ (1 + exp(f_x))
% where f_x = a + b .* Mw

function [P_case, P_slip_coeff, model_range, warnings_Pslip] = PSlip(magnitudes, Mcase, P_slip_m, kinematicType, FaultName, folderPath)

warnings_Pslip = struct('id', {}, 'message', {}, 'values', {});

Pslip_models = P_slip_models();

[Pslip_Index] = getP_slipCoefficients(Pslip_models, P_slip_m); % find the chosen model

% Plot only Pslip models referring to 'All slip types' or the specific
% Kinematics, in order to avoid crowded graph

% Interpolating the chosen model with magnitude scenario(s)
P_slip_coeff = Pslip_models(Pslip_Index).coefficients;
P_slip_name = Pslip_models(Pslip_Index).name;
f_x_Pslip_selected = P_slip_coeff(1) + P_slip_coeff(2) .* Mcase;
if any(strcmp(P_slip_name, {'MEA13-R_a', 'MEA13-R_b','MEA13-S_a','MEA13-S_b'}))
    P_case = 1 ./ (1 + exp(-f_x_Pslip_selected));
else 
    P_case = exp(f_x_Pslip_selected) ./ (1 + exp(f_x_Pslip_selected));
end 
% Validity range for the selected model
model_range = Pslip_models(Pslip_Index).range;
% Reliability of the magnitude range
if any(Mcase < model_range(1)) || any(Mcase > model_range(2))
    warning_id = 'MATLAB:InvalidMw';
    warning_msg = sprintf('Some tested Mw values for the Probability of surface rupture ​​are outside the valid range of the selected model (%.1f - %.1f). The results will be an extrapolation.', model_range(1), model_range(2));
    disp(warning_msg)
    warnings_Pslip(end+1) = struct('id', warning_id, ...
        'message', warning_msg, ...
        'values', []);
end
% Reliability of the model kinematics
if ~contains(Pslip_models(Pslip_Index).kinematics, kinematicType) & ~strcmp(Pslip_models(Pslip_Index).kinematics, 'All')
    warning_id = 'MATLAB:InvalidKin';
    warning_msg = sprintf('The Kinematics of the fault is not consistent with the chosen P_slip_m.');
    disp(warning_msg)
    warnings_Pslip(end+1) = struct('id', warning_id, ...
        'message', warning_msg, ...
        'values', []);
end

Filtred_Models = []; 
for i = 1:length(Pslip_models)
    if strcmp(Pslip_models(i).kinematics, 'All') || contains(Pslip_models(i).kinematics, kinematicType)
        Filtred_Models = [Filtred_Models, i]; 
    end
end

% Plot
figure();
hold on;
for i = 1:length(Filtred_Models)
    c1 = Pslip_models(Filtred_Models(i)).coefficients(1);
    c2 = Pslip_models(Filtred_Models(i)).coefficients(2);
    current_name = Pslip_models(Filtred_Models(i)).name;
    f_x_Pslip = c1 + c2 .* magnitudes;
    if any(strcmp(current_name, {'MEA22_a', 'MEA22_b'}))
        P_slip = 1 ./ (1 + exp(-f_x_Pslip));
    else
        P_slip = exp(f_x_Pslip) ./ (1 + exp(f_x_Pslip));
    end
    plot(magnitudes, P_slip, 'Color', Pslip_models(Filtred_Models(i)).color, 'LineStyle', Pslip_models(Filtred_Models(i)).style, 'LineWidth', 2, 'DisplayName', Pslip_models(Filtred_Models(i)).name); 
end

plot(Mcase, P_case, 'ko', 'MarkerFaceColor', [0.65 0.65 0.65], 'LineWidth', 2, 'DisplayName', 'Mw scenario(s)');
xline(model_range(1), '-', 'Color', [0.50 0.50 0.50], 'LineWidth', 1.5, 'HandleVisibility', 'off');
xline(model_range(2), '-', 'Color', [0.50 0.50 0.50], 'LineWidth', 1.5, 'DisplayName', 'Model validity range', 'HandleVisibility', 'off');

ylabel('Conditional Probability of Slip - Principal Fault')
xlabel('Magnitude')
xlim([min(magnitudes),max(magnitudes)])
ylim([0 1])
legend ('show', 'location', 'best');
grid on;
hold off;

saveas(gcf, fullfile(folderPath, ['Probability_of_Slip_' FaultName '.fig']));


%% 
function [Pslip_Index] = getP_slipCoefficients(Pslip_models, P_slip_m)
    
    Pslip_Index = [];

    for j = 1:length(Pslip_models)
        if strcmp(Pslip_models(j).name, P_slip_m)
            Pslip_Index = j;
            return; 
        end
    end

    if isempty(Pslip_Index)
        error('Model not found. Please, insert a valid name for the Probability of surface rupture');
    end
end
%%

end